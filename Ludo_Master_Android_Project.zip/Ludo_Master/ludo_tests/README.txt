Run on a PC (no Android needed):
g++ -std=c++17 -O2 -I../app/src/main/cpp logic_test.cpp ../app/src/main/cpp/Ludo.cpp -o logic_test && ./logic_test
g++ -std=c++17 -O2 -I../app/src/main/cpp snap_test.cpp ../app/src/main/cpp/Ludo.cpp -o snap_test && ./snap_test
