// KILL TRAP: after a capture, moving the capturing token on the very next move undoes the capture
//  - victims stand again on the cell where they were captured, the moving token is back in its yard
//  - the move of any other token makes the capture permanent
//  - only the very next move counts
#include "Ludo.h"
#include <cstdio>
#include <vector>
using namespace std;

int main() {
    long captures = 0, penalties = 0, kept = 0, games = 0, unfinished = 0, aiPenalties = 0, aiCaptures = 0;
    // ---- part 1: a "human" test driver that deliberately repeats the capturing token whenever it can
    for (int lock = 0; lock <= 1; lock++)
    for (int two = 0; two <= 1; two++)
    for (int np = 2; np <= 4; np++)
    for (int seed = 1; seed <= 80; seed++) {
        LRules r; r.capturePenalty = true; r.captureBonus = true; r.sixReroll = true; r.twoDice = two; r.captureLock = lock; r.tokens = 4; r.blocksSafe = seed % 2;
        bool human[4] = {true, true, true, true};
        Ludo g; g.newGame(np, human, 1, r, seed * 6151u);
        vector<LEvent> ev; long steps = 0; unsigned rs = seed * 2654435761u;
        int prev[4][4]; bool prevUnl[4];
        for (int p = 0; p < 4; p++) { for (int t = 0; t < 4; t++) prev[p][t] = g.st().pos[p][t]; prevUnl[p] = g.st().unlocked[p]; }
        struct Vic { int p, t, rel; };
        vector<Vic> lastVictims; int lastCapturer = -1, lastTok = -1; bool unlBefore[4] = {false, false, false, false};
        while (g.phase() != LPhase::OVER && steps < 3000000) {
            ev.clear(); g.update(0.05f, ev); steps++;
            const LState &s = g.st();
            vector<Vic> thisVictims; int capTok = -1, capBy = -1;
            for (auto &e : ev) {
                if (e.type == LE_CAPTURE) { thisVictims.push_back({e.player, e.tok, prev[e.player][e.tok]}); capBy = e.value; captures++; }
                if (e.type == LE_PENALTY) {
                    penalties++;
                    // the victims of the last capture stand where they were, the mover is in its yard
                    for (auto &v : lastVictims) if (s.pos[v.p][v.t] != v.rel) { printf("FAIL: victim %d/%d not restored (%d != %d)\n", v.p, v.t, s.pos[v.p][v.t], v.rel); return 1; }
                    if (s.pos[e.player][e.tok] != -1) { printf("FAIL: penalised token not in the yard\n"); return 1; }
                    if (e.player != lastCapturer || e.tok != lastTok) { printf("FAIL: penalty for the wrong token\n"); return 1; }
                    for (int q = 0; q < 4; q++) if (s.unlocked[q] != unlBefore[q]) { printf("FAIL: unlocked state not restored for %d\n", q); return 1; }
                    lastVictims.clear(); lastCapturer = -1;
                }
            }
            if (!thisVictims.empty()) {
                lastVictims = thisVictims; lastCapturer = capBy;
                lastTok = -1; for (int t = 0; t < 4; t++) if (s.pos[capBy][t] != prev[capBy][t] && s.pos[capBy][t] >= 0) lastTok = t;
                for (int q = 0; q < 4; q++) unlBefore[q] = prevUnl[q];
                (void) capTok;
            }
            for (int p = 0; p < 4; p++) { for (int t = 0; t < 4; t++) prev[p][t] = s.pos[p][t]; prevUnl[p] = s.unlocked[p]; }
            // drive the humans
            if (g.phase() == LPhase::ROLL_WAIT) g.roll(ev);
            else if (g.phase() == LPhase::CHOOSE && !g.autoPicking()) {
                uint32_t m = g.legalMask(); int pick = -1;
                if (s.armN > 0 && s.armPlayer == g.turn() && (m >> s.armTok & 1u) && (steps % 3 != 0)) pick = s.armTok;     // usually the trap, sometimes not
                if (pick < 0) { rs = rs * 1664525u + 1013904223u; int k = (rs >> 16) % 4; for (int i = 0; i < 4; i++) { int t = (k + i) % 4; if (m >> t & 1u) { pick = t; break; } } }
                if (pick >= 0) g.choose(pick, ev);
            }
        }
        games++;
        if (g.phase() != LPhase::OVER) { unfinished++; printf("UNFINISHED lock=%d two=%d np=%d seed=%d\n", lock, two, np, seed); }
    }
    printf("driver games %ld unfinished %ld | captures %ld, undone by the trap %ld\n", games, unfinished, captures, penalties);
    if (penalties == 0) { printf("FAIL: trap never happened\n"); return 1; }
    // ---- part 2: computers should avoid the trap (only a forced move can trigger it)
    for (int skill = 0; skill <= 3; skill++) {
        long cap = 0, pen = 0, g2 = 0;
        for (int np = 2; np <= 4; np++) for (int seed = 1; seed <= 80; seed++) {
            LRules r; r.capturePenalty = true; r.sixReroll = true; r.tokens = 4;
            bool human[4] = {false, false, false, false};
            Ludo g; g.newGame(np, human, skill, r, seed * 7757u);
            vector<LEvent> ev; long st = 0;
            while (g.phase() != LPhase::OVER && st < 3000000) { ev.clear(); g.update(0.05f, ev); st++; for (auto &e : ev) { if (e.type == LE_CAPTURE) cap++; if (e.type == LE_PENALTY) pen++; } }
            g2++;
        }
        printf("computer skill %d: captures %ld, trapped %ld\n", skill, cap, pen);
        if (skill == 3) { aiPenalties = pen; aiCaptures = cap; }
    }
    (void) kept;
    return (unfinished || aiPenalties * 20 > aiCaptures) ? 3 : 0;
}
