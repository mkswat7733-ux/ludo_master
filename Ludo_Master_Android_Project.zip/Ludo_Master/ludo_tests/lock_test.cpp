// Tests for the HARD rules: padlock (capture before entering home), re-lock, hard mode, 1 / 2 / 4 tokens.
#include "Ludo.h"
#include <cstdio>
#include <vector>
using namespace std;

int main() {
    // 1) a locked player can never enter the home column, an unlocked one can
    {
        LState s{}; s.rules.captureLock = true; s.rules.tokens = 4;
        for (int p = 0; p < 4; p++) { s.active[p] = true; for (int t = 0; t < 4; t++) s.pos[p][t] = -1; }
        s.pos[0][0] = 48;
        if (!ldLegal(s, 0, 0, 2)) { printf("FAIL: 48+2=50 must be allowed\n"); return 1; }
        if (ldLegal(s, 0, 0, 3))  { printf("FAIL: locked token went past cell 50\n"); return 1; }
        s.pos[0][0] = 50;
        for (int r = 1; r <= 6; r++) if (ldLegal(s, 0, 0, r)) { printf("FAIL: locked token moves from 50\n"); return 1; }
        s.unlocked[0] = true;
        if (!ldLegal(s, 0, 0, 5)) { printf("FAIL: unlocked token must enter the column\n"); return 1; }
        printf("lock legality OK\n");
    }
    // 2) capturing unlocks, losing every token locks again
    {
        LState s{}; s.rules.captureLock = true; s.rules.tokens = 2; s.rules.blocksSafe = true;
        for (int p = 0; p < 4; p++) { s.active[p] = (p == 0 || p == 2); for (int t = 0; t < 4; t++) s.pos[p][t] = -1; }
        s.unlocked[2] = true;                         // yellow is unlocked, has one token on the board
        s.pos[2][0] = 20;
        int a = ldLoopIndex(2, 20);                    // a loop cell that is not safe?
        int rel0 = -1;
        for (int r = 1; r <= 50; r++) if (!ldSafeIndex(ldLoopIndex(0, r)) && ldLoopIndex(0, r) == a) rel0 = r;
        if (rel0 < 0) { for (int r = 1; r <= 50; r++) { int idx = ldLoopIndex(0, r); if (!ldSafeIndex(idx)) { rel0 = r; a = idx; break; } } for (int r = 0; r <= 50; r++) if (ldLoopIndex(2, r) == a) { s.pos[2][0] = r; break; } }
        s.pos[0][0] = rel0 - 3;
        LMoveResult m = ldApply(s, 0, 0, 3);
        if (m.nCap != 1 || !m.unlock || !s.unlocked[0]) { printf("FAIL: capture did not unlock (nCap %d)\n", m.nCap); return 1; }
        if (s.unlocked[2] || !(m.relockMask & 4)) { printf("FAIL: victim with no tokens left stayed unlocked\n"); return 1; }
        printf("unlock / relock OK\n");
    }
    // 3) full games with the hard rules, every token count, computer only: must always finish, and nobody
    //    may ever sit in the home column without having captured at least once while locked
    int games = 0, unfinished = 0, relocks = 0, unlocks = 0, deadlockBreaks = 0;
    for (int tokens : {1, 2, 4})
        for (int np = 2; np <= 4; np++)
            for (int seed = 1; seed <= 120; seed++) {
                LRules r; r.captureLock = true; r.hardMode = true; r.tokens = tokens; r.fullRanks = seed % 3 == 0;
                bool human[4] = {false, false, false, false};
                Ludo g; g.newGame(np, human, seed % 4, r, seed * 7919u);
                vector<LEvent> ev; long steps = 0; bool everUnlocked[4] = {false, false, false, false}, everEver[4] = {false, false, false, false};
                while (g.phase() != LPhase::OVER && steps < 3000000) {
                    ev.clear(); g.update(0.05f, ev); steps++;
                    for (auto &e : ev) {
                        if (e.type == LE_UNLOCK) { unlocks++; if (e.aux) deadlockBreaks++; everUnlocked[e.player] = true; everEver[e.player] = true; }
                        if (e.type == LE_RELOCK) { relocks++; everUnlocked[e.player] = false; }
                        if (e.type == LE_CAPTURE) { everUnlocked[e.value] = true; everEver[e.value] = true; }
                    }
                    const LState &s = g.st();
                    for (int p = 0; p < 4; p++) if (s.active[p]) for (int t = 0; t < tokens; t++)
                        if (((s.pos[p][t] > 50 && s.pos[p][t] < LD_HOME && !everUnlocked[p]) || (s.pos[p][t] == LD_HOME && !everEver[p]))) { printf("FAIL: player %d entered home while locked (tokens %d np %d seed %d)\n", p, tokens, np, seed); return 1; }
                }
                games++;
                if (g.phase() != LPhase::OVER) { unfinished++; printf("UNFINISHED tokens=%d np=%d seed=%d\n", tokens, np, seed); }
            }
    printf("hard games %d  unfinished %d  unlocks %d  relocks %d  deadlock-breaker used %d\n", games, unfinished, unlocks, relocks, deadlockBreaks);
    return unfinished ? 3 : 0;
}
