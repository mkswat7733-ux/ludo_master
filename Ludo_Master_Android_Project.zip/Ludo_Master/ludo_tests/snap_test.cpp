#include "Ludo.h"
#include <cstdio>
int main(){
  int bad=0, n=0;
  for(int seed=1; seed<=200; seed++){
    bool human[4]={false,false,false,false}; LRules r; r.fullRanks=(seed%2==0);
    Ludo a; a.newGame(2+seed%3,human,seed%4,r,seed*31u+7);
    std::vector<LEvent> ev; int steps=0;
    // run until some ROLL_WAIT after ~200 steps, then snapshot
    while(a.phase()!=LPhase::OVER && steps<100000){ ev.clear(); a.update(0.05f,ev); steps++; if(steps>200+seed && a.phase()==LPhase::ROLL_WAIT) break; }
    if(a.phase()==LPhase::OVER) continue;
    std::string snap=a.snapshot(0); Ludo b; int ui=-1; if(!b.restore(snap,ui)||ui!=0){ printf("restore failed\n"); return 1; }
    for(int i=0;i<400000 && (a.phase()!=LPhase::OVER||b.phase()!=LPhase::OVER);i++){ ev.clear(); a.update(0.05f,ev); ev.clear(); b.update(0.05f,ev); }
    n++; bool same=a.winner()==b.winner(); for(int p=0;p<4;p++) if(a.rankOf(p)!=b.rankOf(p)||a.captures(p)!=b.captures(p)) same=false;
    if(!same) bad++;
  }
  printf("snapshot/restore replays identical: %d/%d\n", n-bad, n);
  Ludo c; int u; printf("garbage rejected: %d\n", int(!c.restore("xx",u)));
  return bad;
}
