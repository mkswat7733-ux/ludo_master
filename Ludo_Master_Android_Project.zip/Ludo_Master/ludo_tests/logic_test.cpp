#include "Ludo.h"
#include <cstdio>
#include <cassert>
#include <map>
using namespace std;

static bool check(const LState& s, const char* where){
  // invariants
  for(int p=0;p<4;p++){
    if(!s.active[p]) continue;
    for(int t=0;t<s.rules.tokens;t++){
      int r=s.pos[p][t];
      if(r<-1||r>56){ printf("BAD pos %d at %s\n",r,where); return false; }
    }
  }
  // no two different colours on same unsafe loop cell unless block rule/safe
  for(int a=0;a<LD_LOOP;a++){
    int colours=0; int cnt[4]={0};
    for(int p=0;p<4;p++){ if(!s.active[p]) continue; for(int t=0;t<s.rules.tokens;t++) if(ldLoopIndex(p,s.pos[p][t])==a) cnt[p]++; }
    for(int p=0;p<4;p++) if(cnt[p]) colours++;
    if(colours>1 && !ldSafeIndex(a)){
      // allowed only if some colour holds a block (>=2) with blocksSafe
      bool blk=false; for(int p=0;p<4;p++) if(cnt[p]>=2) blk=true;
      if(!s.rules.blocksSafe){ printf("BAD: mixed colours on unsafe cell %d at %s blocksSafe=%d\n",a,where,(int)s.rules.blocksSafe); for(int p=0;p<4;p++) printf(" p%d cnt %d\n",p,cnt[p]); return false; }
    }
  }
  return true;
}

int main(){
  // board geometry sanity: loop cells unique, 52, adjacent
  for(int i=0;i<LD_LOOP;i++){
    int c,r,c2,r2; ldLoopCell(i,c,r); ldLoopCell(i+1,c2,r2);
    int d=abs(c-c2)+abs(r-r2); bool diag=(abs(c-c2)==1&&abs(r-r2)==1); if(d!=1 && !diag){ printf("loop not adjacent at %d (%d,%d)->(%d,%d)\n",i,c,r,c2,r2); return 1; }
    for(int j=i+1;j<LD_LOOP;j++){ int cc,rr; ldLoopCell(j,cc,rr); if(cc==c&&rr==r){printf("dup cell\n");return 1;} }
  }
  // start cells & safe stars positions
  const char* nm[4]={"RED","GREEN","YELLOW","BLUE"};
  for(int p=0;p<4;p++){ int c,r; ldLoopCell(ldStartIndex(p),c,r); printf("%s start cell (%d,%d)\n",nm[p],c,r); }
  for(int i=0;i<LD_LOOP;i++) if(ldSafeIndex(i)){ int c,r; ldLoopCell(i,c,r); printf("safe idx %d -> (%d,%d)\n",i,c,r);}  
  // path continuity per colour: rel 50 cell adjacent to first home cell
  for(int p=0;p<4;p++){ int c,r,c2,r2; ldLoopCell(ldLoopIndex(p,50),c,r); ldHomeCell(p,0,c2,r2); int d=abs(c-c2)+abs(r-r2); printf("%s: last loop (%d,%d) -> home0 (%d,%d) dist %d\n",nm[p],c,r,c2,r2,d); if(d!=1) return 1;}

  map<int,int> wins; int games=0; long totalTurns=0; int maxTurns=0; int unfinished=0;
  for(int cfg=0; cfg<4; cfg++){
    for(int seed=1; seed<=300; seed++){
      for(int np=2; np<=4; np++){
        LRules rules; rules.fullRanks = (seed%3==0); rules.tokens = (seed%5==0)?2:4; rules.sixToStart=(seed%7!=0); rules.blocksSafe=(seed%4!=0); rules.captureBonus=(seed%2==0); rules.threeSixes=(seed%6!=0);
        bool human[4]={false,false,false,false};
        Ludo g; g.newGame(np,human,cfg,rules,seed*7919u+cfg);
        vector<LEvent> ev; int steps=0; int turns=0; 
        while(g.phase()!=LPhase::OVER && steps<2000000){
          ev.clear(); g.update(0.05f,ev); steps++;
          for(auto&e:ev){ if(e.type==LE_TURN) turns++; }
          if(!check(g.st(),"loop")) return 2;
        }
        if(g.phase()!=LPhase::OVER){ unfinished++; printf("UNFINISHED np=%d seed=%d cfg=%d\n",np,seed,cfg); continue; }
        games++; totalTurns+=turns; maxTurns=max(maxTurns,turns);
        wins[g.winner()+10*cfg]++;
        // ranking sanity
        int seen[5]={0}; for(int p=0;p<4;p++) if(g.st().active[p]){ int r=g.rankOf(p); if(r<1||r>np||seen[r]){printf("BAD rank\n");return 3;} seen[r]=1; }
      }
    }
  }
  printf("games %d unfinished %d avgTurns %.1f maxTurns %d\n",games,unfinished,(double)totalTurns/games,maxTurns);
  // skill strength test: master vs three easies (seat 0 master, others easy)? Use custom loop: need per-seat skill -> emulate with 2 players alternating skill via separate games not supported.
  return 0;
}
