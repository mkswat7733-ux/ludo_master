// Tests for SIX = REROLL and TWO DICE
//  - SIX = REROLL (one die): a 6 never moves a token, it only gives another roll by the same player
//  - TWO DICE: a token leaves the yard only when one of the two dice shows a 6
//  - the third six in a row: nothing happens, the next player rolls
//  - two dice: at most two moves per roll, first die first, nothing is played with a 6
#include "Ludo.h"
#include <cstdio>
#include <vector>
using namespace std;

int main() {
    long entries = 0, rolls = 0, sixes = 0, sixAgain = 0, threeSix = 0, games = 0, unfinished = 0, moves = 0, twoMoveRolls = 0;
    for (int two = 0; two <= 1; two++)
    for (int lock = 0; lock <= 1; lock++)
    for (int tokens : {1, 2, 4})
    for (int np = 2; np <= 4; np++)
    for (int seed = 1; seed <= 60; seed++) {
        LRules r; r.sixReroll = true; r.sixToStart = true /* must be ignored */; r.twoDice = two; r.captureLock = lock; r.tokens = tokens;
        r.threeSixes = true; r.captureBonus = seed % 2; r.fullRanks = seed % 3 == 0;
        bool human[4] = {false, false, false, false};
        Ludo g; g.newGame(np, human, seed % 4, r, seed * 104729u);
        if (!two && g.rules().sixToStart) { printf("FAIL: sixToStart must be off with sixReroll\n"); return 1; }
        if (two && (!g.rules().sixToStart || g.rules().sixReroll)) { printf("FAIL: two dice must force six to start and no reroll rule\n"); return 1; }
        int d1 = 0, d2 = 0;
        vector<LEvent> ev; long steps = 0;
        int prevPos[4][4]; for (int p = 0; p < 4; p++) for (int t = 0; t < 4; t++) prevPos[p][t] = g.st().pos[p][t];
        int rollPlayer = -1, rollSixes = 0, movesThisRoll = 0, lastSixPlayer = -1; bool lastWasSix3 = false; int sixesInRow = 0;
        while (g.phase() != LPhase::OVER && steps < 4000000) {
            ev.clear(); g.update(0.05f, ev); steps++;
            const LState &s = g.st();
            // moves since the last step
            for (int p = 0; p < 4; p++) for (int t = 0; t < 4; t++) {
                int a = prevPos[p][t], b = s.pos[p][t];
                if (!two && a != b && b >= 0 && a >= 0 && b - a == 6) { printf("FAIL: token moved by 6 (tokens %d np %d seed %d two %d)\n", tokens, np, seed, two); return 1; }
                if (a != b && b > a && p == g.turn()) { moves++; movesThisRoll++; }
                if (two && a == -1 && b == 0 && p == g.turn()) { entries++; if (d1 != 6 && d2 != 6) { printf("FAIL: token came out without a 6 (%d,%d) tokens %d np %d seed %d\n", d1, d2, tokens, np, seed); return 1; } }
                prevPos[p][t] = b;
            }
            for (auto &e : ev) {
                if (e.type == LE_ROLL_START) { rolls++; rollPlayer = e.player; movesThisRoll = 0; }
                if (e.type == LE_ROLL_DONE) {
                    d1 = e.value; d2 = e.tok;
                    int six = (e.value == 6) + (two && e.tok == 6);
                    sixes += six; rollSixes = six;
                    sixesInRow = six ? sixesInRow + six : 0;
                    lastSixPlayer = six ? e.player : -1;
                }
                if (e.type == LE_THREE_SIXES) { threeSix++; lastWasSix3 = true; }
                if (e.type == LE_TURN) {
                    if (movesThisRoll > (two ? 2 : 1)) { printf("FAIL: %d moves in one roll\n", movesThisRoll); return 1; }
                    if (movesThisRoll == 2) twoMoveRolls++;
                    if (lastSixPlayer >= 0 && !lastWasSix3) {
                        // a roll with a 6 (and no lost turn): the same player must roll again
                        if (e.player != lastSixPlayer && !g.st().done[lastSixPlayer]) { printf("FAIL: after a 6 the turn left player %d\n", lastSixPlayer); return 1; }
                        sixAgain++;
                    }
                    if (lastWasSix3 && e.player == lastSixPlayer && np > 1 && !g.st().done[lastSixPlayer] && e.aux) { printf("FAIL: third six did not pass the turn\n"); return 1; }
                    lastWasSix3 = false; lastSixPlayer = -1; movesThisRoll = 0;
                }
            }
        }
        games++;
        if (g.phase() != LPhase::OVER) { unfinished++; printf("UNFINISHED two=%d lock=%d tokens=%d np=%d seed=%d\n", two, lock, tokens, np, seed); }
    }
    printf("two-dice token entries (all on a 6): %ld\n", entries);
    printf("games %d unfinished %ld | rolls %ld sixes %ld (rolled again %ld, third-six turns lost %ld) | moves %ld, rolls with 2 moves %ld\n",
           (int) games, unfinished, rolls, sixes, sixAgain, threeSix, moves, twoMoveRolls);
    return unfinished ? 3 : 0;
}
