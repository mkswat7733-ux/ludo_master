/**
 * Carrom Master - FREE withdraw backend (Google Apps Script + Google Sheet + your Gmail).
 *
 * What it does
 *  1. The app sends a withdraw request here.
 *  2. You get an e-mail (from your own Gmail) with APPROVE / REJECT buttons.
 *  3. You pay the player manually on Easypaisa, then press APPROVE (a confirm page opens, press YES).
 *  4. The app asks for the status and finalises the player's balance.
 *  Every request is stored as a row in the "Requests" sheet (your permanent record).
 *
 * Setup: see SETUP_URDU.txt (about 5 minutes, no server, no cost).
 */

// ======================= EDIT THESE TWO LINES =======================
var API_KEY = 'CHANGE_ME_API_KEY';          // same value as API_KEY in ServerConfig.kt (any long random text)
var ADMIN_SECRET = 'CHANGE_ME_ADMIN_SECRET'; // another long random text, signs the Approve / Reject links
// Optional: leave '' to use the Google account that deploys the script
var OWNER_EMAIL = '';
// =====================================================================

var MIN_PKR = 200, MAX_PKR = 1000;
var SHEET_NAME = 'Requests';
var HEAD = ['id', 'createdAt', 'deviceId', 'name', 'phone', 'amount', 'status', 'decidedAt', 'stats'];

// ------------------------------------------------------------------ helpers
function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
function html_(title, body) {
  var page = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<style>body{font-family:Arial,sans-serif;background:#0b1220;color:#eaf2ff;margin:0;padding:20px}' +
    '.c{max-width:520px;margin:24px auto;background:#14213d;border-radius:14px;padding:22px}td{padding:5px 12px 5px 0}' +
    'a.b{display:inline-block;color:#fff;font-weight:bold;text-decoration:none;border-radius:10px;padding:14px 24px;margin-top:10px}' +
    'table.l{border-collapse:collapse;width:100%}table.l td,table.l th{border-bottom:1px solid #26365a;padding:6px;text-align:left;font-size:13px}</style>' +
    '</head><body><div class="c">' + body + '</div></body></html>';
  return HtmlService.createHtmlOutput(page).setTitle(title).addMetaTag('viewport', 'width=device-width, initial-scale=1');
}
function esc_(s) {
  return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; });
}
function sheet_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SHEET_NAME) || ss.insertSheet(SHEET_NAME);
  if (sh.getLastRow() === 0) sh.appendRow(HEAD);
  return sh;
}
function rows_(sh) {
  var v = sh.getDataRange().getValues(), out = [];
  for (var i = 1; i < v.length; i++) {
    out.push({ row: i + 1, id: String(v[i][0]), createdAt: String(v[i][1]), deviceId: String(v[i][2]), name: String(v[i][3]),
      phone: String(v[i][4]), amount: Number(v[i][5]), status: String(v[i][6]), decidedAt: String(v[i][7]), stats: String(v[i][8]) });
  }
  return out;
}
function hex_(bytes) {
  return bytes.map(function (b) { return ('0' + (b & 0xff).toString(16)).slice(-2); }).join('');
}
function sign_(id, act) {
  return hex_(Utilities.computeHmacSha256Signature(id + ':' + act, ADMIN_SECRET));
}
function owner_() { return OWNER_EMAIL || Session.getEffectiveUser().getEmail(); }
function baseUrl_() { return ScriptApp.getService().getUrl(); }
function link_(id, act) { return baseUrl_() + '?action=confirm&id=' + encodeURIComponent(id) + '&act=' + act + '&sig=' + sign_(id, act); }

function mail_(r, stats) {
  var s = stats || {};
  function row(k, v) { return '<tr><td style="padding:6px 14px;color:#667">' + k + '</td><td style="padding:6px 14px"><b>' + esc_(v === undefined ? '-' : v) + '</b></td></tr>'; }
  var body = '<div style="font-family:Arial,sans-serif;max-width:560px"><h2 style="margin:0 0 8px">New withdraw request</h2>' +
    '<p style="color:#445">Pay the amount manually to the Easypaisa account below, <u>then</u> press APPROVE.</p>' +
    '<table style="border-collapse:collapse;background:#f4f6fb">' +
    row('Request ID', r.id) + row('Amount', 'PKR ' + r.amount) + row('Name', r.name) + row('Easypaisa number', r.phone) +
    row('Requested at', r.createdAt) + row('Device ID', r.deviceId) +
    row('Level reached', s.level) + row('Matches played', s.played) + row('Matches won', s.wins) + row('Level losses', s.levelLosses) +
    row('Total won (PKR)', s.totalWonPkr) + row('Total lost (PKR)', s.totalLostPkr) + row('Balance before request (PKR)', s.balancePkr) +
    '</table><p style="margin:22px 0">' +
    '<a href="' + link_(r.id, 'approve') + '" style="background:#16a34a;color:#fff;padding:14px 22px;border-radius:8px;text-decoration:none;font-weight:bold">APPROVE - I HAVE PAID</a>&nbsp; ' +
    '<a href="' + link_(r.id, 'reject') + '" style="background:#dc2626;color:#fff;padding:14px 22px;border-radius:8px;text-decoration:none;font-weight:bold">REJECT</a></p>' +
    '<p style="color:#889;font-size:12px">Approve: the amount stays deducted from the player. Reject: it is returned to the player.</p></div>';
  MailApp.sendEmail({
    to: owner_(),
    subject: 'Withdraw request ' + r.id + ' - PKR ' + r.amount + ' - ' + r.name,
    htmlBody: body,
    body: 'Withdraw ' + r.id + ' PKR ' + r.amount + ' ' + r.name + ' ' + r.phone + '\nApprove: ' + link_(r.id, 'approve') + '\nReject: ' + link_(r.id, 'reject'),
    name: 'Carrom Master'
  });
}

// ------------------------------------------------------------------ POST: new withdraw request
function doPost(e) {
  var b;
  try { b = JSON.parse(e.postData.contents); } catch (err) { return json_({ ok: false, error: 'Bad request.' }); }
  if (!b || b.key !== API_KEY) return json_({ ok: false, error: 'Unauthorized.' });
  var deviceId = String(b.deviceId || ''), name = String(b.name || '').trim().replace(/\s+/g, ' ');
  var phone = String(b.phone || '').trim(), amount = Number(b.amount);
  if (!/^[a-f0-9]{16,64}$/.test(deviceId)) return json_({ ok: false, error: 'Invalid device.' });
  if (name.length < 3 || name.length > 40) return json_({ ok: false, error: 'Enter your full name.' });
  if (!/^03\d{9}$/.test(phone)) return json_({ ok: false, error: 'Easypaisa number must look like 03XXXXXXXXX.' });
  if (amount !== Math.floor(amount) || amount < MIN_PKR) return json_({ ok: false, error: 'Minimum withdraw is ' + MIN_PKR + ' PKR.' });
  if (amount > MAX_PKR) return json_({ ok: false, error: 'Maximum withdraw is ' + MAX_PKR + ' PKR.' });

  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var sh = sheet_(), all = rows_(sh);
    for (var i = 0; i < all.length; i++)
      if (all[i].deviceId === deviceId && all[i].status === 'pending') return json_({ ok: false, error: 'You already have a pending request.' });
    var stats = {}, keys = ['played', 'wins', 'levelLosses', 'level', 'coins', 'totalWonPkr', 'totalLostPkr', 'balancePkr'];
    if (b.stats && typeof b.stats === 'object') keys.forEach(function (k) { if (b.stats[k] !== undefined) stats[k] = String(b.stats[k]).slice(0, 20); });
    var r = {
      id: 'WD-' + new Date().getTime().toString(36).toUpperCase() + Math.floor(Math.random() * 1296).toString(36).toUpperCase(),
      createdAt: new Date().toISOString(), deviceId: deviceId, name: name, phone: phone, amount: amount
    };
    sh.appendRow([r.id, "'" + r.createdAt, deviceId, name, "'" + phone, amount, 'pending', '', JSON.stringify(stats)]);
    var rowNo = sh.getLastRow();
    try {
      mail_(r, stats);
    } catch (err) {
      sh.deleteRow(rowNo);   // never leave the player waiting for a mail that was not sent
      return json_({ ok: false, error: 'Could not notify the owner right now. Please try again later.' });
    }
    return json_({ ok: true, id: r.id });
  } finally {
    lock.releaseLock();
  }
}

// ------------------------------------------------------------------ GET: status / confirm / apply / list
function doGet(e) {
  var p = (e && e.parameter) || {};
  if (p.action === 'status') {
    if (p.key !== API_KEY) return json_({ ok: false, error: 'Unauthorized.' });
    var mine = rows_(sheet_()).filter(function (r) { return r.deviceId === String(p.deviceId || ''); });
    var last = mine[mine.length - 1];
    return json_({ ok: true, request: last ? { id: last.id, status: last.status, amount: last.amount } : null });
  }
  if (p.action === 'confirm' || p.action === 'apply') return confirmOrApply_(p);
  if (p.action === 'list') {
    if (p.key !== ADMIN_SECRET) return html_('Forbidden', '<h2>Forbidden</h2>');
    var all = rows_(sheet_()), paid = 0, tr = '';
    all.slice().reverse().forEach(function (r) {
      if (r.status === 'paid') paid += r.amount;
      tr += '<tr><td>' + esc_(r.id) + '</td><td>' + esc_(r.createdAt.slice(0, 16).replace('T', ' ')) + '</td><td>' + esc_(r.name) + '</td><td>' + esc_(r.phone) + '</td><td>' + r.amount + '</td><td>' + esc_(r.status) + '</td></tr>';
    });
    return html_('Requests', '<h2>All requests</h2><p>Total paid: <b>PKR ' + paid + '</b></p><table class="l"><tr><th>ID</th><th>Time</th><th>Name</th><th>Easypaisa</th><th>PKR</th><th>Status</th></tr>' + tr + '</table>');
  }
  return html_('Carrom Master', '<h2>Carrom Master withdraw backend is running.</h2>');
}

function confirmOrApply_(p) {
  var id = String(p.id || ''), act = String(p.act || '');
  if ((act !== 'approve' && act !== 'reject') || String(p.sig || '') !== sign_(id, act)) return html_('Invalid', '<h2>Invalid or expired link</h2>');
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var sh = sheet_(), r = rows_(sh).filter(function (x) { return x.id === id; })[0];
    if (!r) return html_('Not found', '<h2>Request not found</h2>');
    if (r.status !== 'pending') return html_('Done', '<h2>Already ' + esc_(r.status) + '</h2><p>' + esc_(r.id) + ' - PKR ' + r.amount + '</p>');
    var approve = act === 'approve';
    if (p.action === 'confirm') {
      // opening the e-mail link changes nothing, a second click on the page below is needed (mail scanners cannot do that)
      var go = baseUrl_() + '?action=apply&id=' + encodeURIComponent(id) + '&act=' + act + '&sig=' + sign_(id, act);
      return html_('Confirm', '<h2>' + (approve ? 'Approve' : 'Reject') + ' request?</h2>' +
        '<table><tr><td>ID</td><td><b>' + esc_(r.id) + '</b></td></tr><tr><td>Amount</td><td><b>PKR ' + r.amount + '</b></td></tr>' +
        '<tr><td>Name</td><td><b>' + esc_(r.name) + '</b></td></tr><tr><td>Easypaisa</td><td><b>' + esc_(r.phone) + '</b></td></tr></table>' +
        '<p style="color:#9fb3d9">' + (approve ? 'Press only after you have paid this amount.' : 'The amount will be returned to the player.') + '</p>' +
        '<a class="b" target="_top" style="background:' + (approve ? '#16a34a' : '#dc2626') + '" href="' + go + '">' + (approve ? 'YES, APPROVE' : 'YES, REJECT') + '</a>');
    }
    sh.getRange(r.row, 7).setValue(approve ? 'paid' : 'rejected');
    sh.getRange(r.row, 8).setValue("'" + new Date().toISOString());
    return html_('Done', '<h2>' + (approve ? 'Approved' : 'Rejected') + '</h2><p>' + esc_(r.id) + ' - PKR ' + r.amount + ' - ' + esc_(r.name) +
      '</p><p style="color:#9fb3d9">The player\'s app updates the next time it checks.</p>');
  } finally {
    lock.releaseLock();
  }
}

// ------------------------------------------------------------------ run these from the editor
/** Run once after pasting the code: creates the sheet and asks Google for permissions (Sheets + Gmail). */
function setup() {
  sheet_();
  MailApp.sendEmail(owner_(), 'Carrom Master backend is ready', 'Setup finished. Now deploy as a Web app (see SETUP_URDU.txt).');
}
/** Sends a fake request e-mail to yourself so you can see how it looks. */
function testRequest() {
  var out = doPost({ postData: { contents: JSON.stringify({ key: API_KEY, deviceId: 'abcdef0123456789abcdef0123456789', name: 'Test Player', phone: '03001234567', amount: 300,
    stats: { level: 12, played: 40, wins: 25, totalWonPkr: '310', totalLostPkr: '10', balancePkr: '300' } }) } });
  Logger.log(out.getContent());
}
