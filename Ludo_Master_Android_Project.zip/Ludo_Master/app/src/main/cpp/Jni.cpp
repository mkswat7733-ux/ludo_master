// Receives the font atlas that MainActivity.kt rasterises with Android's Canvas / Paint.
#include <android/bitmap.h>
#include <jni.h>
#include <cstring>
#include <string>
#include "Gfx.h"

extern "C" JNIEXPORT void JNICALL
Java_com_webdsoft_myapplication_MainActivity_nativeSetFontAtlas(JNIEnv *env, jobject /*thiz*/, jobject bitmap,
                                                                jfloatArray advances, jint cell, jint cols) {
    AndroidBitmapInfo info;
    if (AndroidBitmap_getInfo(env, bitmap, &info) != ANDROID_BITMAP_RESULT_SUCCESS) return;
    if (info.format != ANDROID_BITMAP_FORMAT_RGBA_8888) return;
    void *pixels = nullptr;
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) != ANDROID_BITMAP_RESULT_SUCCESS || !pixels) return;
    fontAtlasLock();
    FontAtlas &a = fontAtlasStorage();
    a.w = int(info.width); a.h = int(info.height); a.cell = cell; a.cols = cols;
    a.rgba.resize(size_t(a.w) * a.h * 4);
    for (int y = 0; y < a.h; y++)
        memcpy(a.rgba.data() + size_t(y) * a.w * 4, static_cast<uint8_t *>(pixels) + size_t(y) * info.stride, size_t(a.w) * 4);
    env->GetFloatArrayRegion(advances, 0, 96, a.adv);
    fontAtlasUnlock();
    AndroidBitmap_unlockPixels(env, bitmap);
}

#include "NetQueue.h"

// Kotlin -> game: the four friend names typed in the dialog, joined with '|'
extern "C" JNIEXPORT void JNICALL
Java_com_webdsoft_myapplication_MainActivity_nativeNames(JNIEnv *env, jobject, jstring packed) {
    if (!packed) return;
    const char *c = env->GetStringUTFChars(packed, nullptr);
    if (!c) return;
    netPush(std::string(c));
    env->ReleaseStringUTFChars(packed, c);
}
