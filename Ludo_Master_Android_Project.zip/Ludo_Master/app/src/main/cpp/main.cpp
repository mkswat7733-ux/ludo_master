#include <jni.h>
#include <chrono>
#include <memory>
#include <string>

#include <game-activity/GameActivity.h>
#include <game-activity/native_app_glue/android_native_app_glue.h>

#include "AndroidOut.h"
#include "App.h"
#include "Platform.h"
#include "Renderer.h"

namespace {
struct Engine {
    android_app *app = nullptr;
    App game;
    std::unique_ptr<Renderer> renderer;
    bool resumed = false;
};

void handle_cmd(android_app *app, int32_t cmd) {
    auto *e = static_cast<Engine *>(app->userData);
    if (!e) return;
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            e->renderer = std::make_unique<Renderer>(app, &e->game);
            break;
        case APP_CMD_TERM_WINDOW:
            e->renderer.reset();
            break;
        case APP_CMD_RESUME:
            e->resumed = true;
            e->game.onResume();
            break;
        case APP_CMD_PAUSE:
            e->resumed = false;
            e->game.onPause();
            break;
        default: break;
    }
}

bool motion_event_filter(const GameActivityMotionEvent *m) {
    auto cls = m->source & AINPUT_SOURCE_CLASS_MASK;
    return cls == AINPUT_SOURCE_CLASS_POINTER || cls == AINPUT_SOURCE_CLASS_JOYSTICK;
}
}  // namespace

extern "C" {
void android_main(struct android_app *app) {
    Platform::attach(app);
    Engine engine;
    engine.app = app;
    std::string dir = app->activity->internalDataPath ? app->activity->internalDataPath : "";
    engine.game.hapticFn = [](int k) { Platform::haptic(k); };
    engine.game.quitFn = []() { Platform::quit(); };
    engine.game.openNamesFn = [](const std::string &p) { Platform::openNamesForm(p.c_str()); };
    engine.game.init(dir + "/ludo_save.bin");
    app->userData = &engine;
    app->onAppCmd = handle_cmd;
    android_app_set_motion_event_filter(app, motion_event_filter);

    auto last = std::chrono::steady_clock::now();
    while (!app->destroyRequested) {
        bool active = engine.renderer && engine.renderer->ok() && engine.resumed;
        int events;
        android_poll_source *source;
        // block while the app is in the background, poll without waiting while rendering
        int result = ALooper_pollOnce(active ? 0 : -1, nullptr, &events, reinterpret_cast<void **>(&source));
        while (result >= 0 || result == ALOOPER_POLL_CALLBACK) {
            if (result >= 0 && source) source->process(app, source);
            result = ALooper_pollOnce(0, nullptr, &events, reinterpret_cast<void **>(&source));
        }
        if (app->destroyRequested) break;
        auto now = std::chrono::steady_clock::now();
        float dt = std::chrono::duration<float>(now - last).count();
        last = now;
        if (dt > 0.05f) dt = 0.05f;
        if (engine.renderer && engine.renderer->ok() && engine.resumed) {
            engine.renderer->handleInput();
            engine.renderer->frame(dt);
        }
    }
    engine.renderer.reset();
    app->userData = nullptr;
}
}
