// Ludo Master: menu, setup, game board with a 3D tumbling dice and shaded pawns, settings, stats.
// The rules and the computer players live in Ludo.cpp (portable); this file draws and reacts to touches.
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <ctime>
#include "App.h"

namespace {
// ---- colour theme (dark / light), switched at runtime
Col kTeal, kGold, kRed, kPanel, kText, kDim, kBtnTop, kBtnBot, kCardTop, kCardBot, kTrack, kBgTop, kBgBot;
bool gDark = true;
void applyTheme(bool dark) {
    gDark = dark;
    if (dark) {
        kTeal = Col::hex(0x22D3BA); kGold = Col::hex(0xF5B83D); kRed = Col::hex(0xF0516A);
        kPanel = Col::hex(0x0E1A30, 0.92f); kText = Col::hex(0xEAF2FF); kDim = Col::hex(0x8FA3C4);
        kBtnTop = Col::hex(0x2A3E66); kBtnBot = Col::hex(0x1A2A4A);
        kCardTop = Col::hex(0x12203A, 0.97f); kCardBot = Col::hex(0x0B1527, 0.97f);
        kTrack = Col(1, 1, 1, 0.12f); kBgTop = Col(0.06f, 0.11f, 0.21f); kBgBot = Col(0.02f, 0.04f, 0.09f);
    } else {
        kTeal = Col::hex(0x0FB39D); kGold = Col::hex(0xD9920B); kRed = Col::hex(0xE0344F);
        kPanel = Col::hex(0xFFFFFF, 0.95f); kText = Col::hex(0x10203F); kDim = Col::hex(0x5C6E91);
        kBtnTop = Col::hex(0xE4ECF9); kBtnBot = Col::hex(0xC8D7EE);
        kCardTop = Col::hex(0xFFFFFF, 0.98f); kCardBot = Col::hex(0xEAF1FC, 0.98f);
        kTrack = Col(0, 0, 0, 0.10f); kBgTop = Col::hex(0xF2F7FF); kBgBot = Col::hex(0xC5D6EF);
    }
}
}  // namespace

namespace {
const float PI = 3.14159265f;
inline float clampf(float v, float a, float b) { return std::max(a, std::min(b, v)); }
inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }

Col seatCol(int p) { static const uint32_t c[4] = {0xE53E3E, 0x2FAE5F, 0xF2B91F, 0x2F6FED}; return Col::hex(c[p & 3]); }
Col seatDeep(int p) { static const uint32_t c[4] = {0xA82424, 0x1B8444, 0xC48F0A, 0x1C4DB8}; return Col::hex(c[p & 3]); }
const char *colName(int p) { static const char *n[4] = {"RED", "GREEN", "YELLOW", "BLUE"}; return n[p & 3]; }
const char *placeName(int r) { static const char *n[5] = {"-", "1ST", "2ND", "3RD", "4TH"}; return n[std::max(0, std::min(4, r))]; }

struct Rank { const char *name; int from; };
const Rank kRanks[] = {{"ROOKIE", 0}, {"PLAYER", 150}, {"EXPERT", 500}, {"CHAMPION", 1200}, {"GRANDMASTER", 2500}, {"LEGEND", 5000}};
int rankIndex(int xp) { int r = 0; for (int i = 0; i < 6; i++) if (xp >= kRanks[i].from) r = i; return r; }

// ------------------------------------------------------------------------------------ layout
struct Lay { float cs, Lb, by, ph, botY, topY, cardW, barY; };
Lay layoutFor(float ww, float wh) {
    Lay L;
    const float topBar = 120.f, minPh = 240.f;
    L.Lb = std::min(1100.f, std::min(ww - 60.f, wh - topBar - 2.f * minPh - 24.f));
    float free = wh - L.Lb - topBar - 24.f;
    L.ph = std::min(380.f, free / 2.f);
    float slack = wh - (L.Lb + 2.f * L.ph + topBar + 24.f);
    float gap = 12.f + slack * 0.2f, margin = slack * 0.3f;
    float yb = -wh / 2.f + margin;
    L.botY = yb + L.ph / 2.f;
    L.by = yb + L.ph + gap + L.Lb / 2.f;
    L.topY = L.by + L.Lb / 2.f + gap + L.ph / 2.f;
    L.barY = L.topY + L.ph / 2.f + topBar / 2.f + 4.f;
    L.cs = L.Lb / 15.f;
    L.cardW = std::min(L.Lb / 2.f - 8.f, 560.f);
    return L;
}
V2 gridPos(const Lay &L, float gx, float gy) { return {(gx - 7.5f) * L.cs, L.by + (7.5f - gy) * L.cs}; }
V2 cellCenter(const Lay &L, int c, int r) { return gridPos(L, c + 0.5f, r + 0.5f); }
bool isTop(int p) { return p == LC_GREEN || p == LC_YELLOW; }
bool isLeft(int p) { return p == LC_RED || p == LC_GREEN; }
// where a die lands on the board when its player rolls (the centre area, towards the player's own corner)
V2 dieLanding(const Lay &L, int p) { return {(isLeft(p) ? -1.f : 1.f) * L.cs * 1.9f, L.by + (isTop(p) ? 1.f : -1.f) * L.cs * 1.9f}; }

// ------------------------------------------------------------------------------------ tiny 3x3 matrices for the dice
struct M3 { float m[9]; };
struct Vec3 { float x, y, z; };
M3 ident() { return {{1, 0, 0, 0, 1, 0, 0, 0, 1}}; }
M3 mul(const M3 &a, const M3 &b) {
    M3 r;
    for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) r.m[i * 3 + j] = a.m[i * 3] * b.m[j] + a.m[i * 3 + 1] * b.m[3 + j] + a.m[i * 3 + 2] * b.m[6 + j];
    return r;
}
Vec3 apply(const M3 &a, Vec3 v) { return {a.m[0] * v.x + a.m[1] * v.y + a.m[2] * v.z, a.m[3] * v.x + a.m[4] * v.y + a.m[5] * v.z, a.m[6] * v.x + a.m[7] * v.y + a.m[8] * v.z}; }
M3 axisAngle(Vec3 a, float ang) {
    float l = std::sqrt(a.x * a.x + a.y * a.y + a.z * a.z); a = {a.x / l, a.y / l, a.z / l};
    float c = std::cos(ang), s = std::sin(ang), t = 1.f - c;
    return {{t * a.x * a.x + c, t * a.x * a.y - s * a.z, t * a.x * a.z + s * a.y,
             t * a.x * a.y + s * a.z, t * a.y * a.y + c, t * a.y * a.z - s * a.x,
             t * a.x * a.z - s * a.y, t * a.y * a.z + s * a.x, t * a.z * a.z + c}};
}
M3 rotZ(float a) { return axisAngle({0, 0, 1}, a); }

struct Face { Vec3 n, u, v; int val; };
const Face kFaces[6] = {{{0, 0, 1}, {1, 0, 0}, {0, 1, 0}, 1},  {{0, 0, -1}, {1, 0, 0}, {0, -1, 0}, 6},
                        {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}, 3},  {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}, 4},
                        {{0, 1, 0}, {0, 0, 1}, {1, 0, 0}, 2},  {{0, -1, 0}, {0, 0, 1}, {-1, 0, 0}, 5}};
const float kPips[7][6][2] = {{}, {{0, 0}}, {{-.5f, .5f}, {.5f, -.5f}}, {{-.5f, .5f}, {0, 0}, {.5f, -.5f}},
                              {{-.5f, .5f}, {.5f, .5f}, {-.5f, -.5f}, {.5f, -.5f}}, {{-.5f, .5f}, {.5f, .5f}, {-.5f, -.5f}, {.5f, -.5f}, {0, 0}},
                              {{-.5f, .5f}, {-.5f, 0}, {-.5f, -.5f}, {.5f, .5f}, {.5f, 0}, {.5f, -.5f}}};
const int kPipCount[7] = {0, 1, 2, 3, 4, 5, 6};

struct SeedRng {
    uint32_t s;
    float next() { s = s * 1664525u + 1013904223u; return ((s >> 8) & 0xFFFFFF) / float(0x1000000); }
};

// orientation that shows `val` on top, turned by a seed dependent angle
M3 restOrient(int val, uint32_t seed) {
    for (const Face &f : kFaces) if (f.val == val) {
        M3 align = {{f.u.x, f.u.y, f.u.z, f.v.x, f.v.y, f.v.z, f.n.x, f.n.y, f.n.z}};
        (void) seed;
        return align;   // the die lands square to the screen: the number faces the player, no random turn
    }
    return ident();
}
// tumbling orientation: two spins that decay to zero exactly when the roll ends
M3 tumbleOrient(int val, uint32_t seed, float tn) {
    SeedRng r{seed * 2654435761u + 7u};
    M3 fin = restOrient(val, seed);
    r.next();
    auto axis = [&]() { return Vec3{r.next() * 2.f - 1.f, r.next() * 2.f - 1.f, r.next() * 2.f - 1.f + 0.01f}; };
    Vec3 a1 = axis(), a2 = axis();
    float t1 = (2.4f + 1.6f * r.next()) * 2.f * PI * (r.next() < 0.5f ? -1.f : 1.f);
    float t2 = (1.6f + 1.2f * r.next()) * 2.f * PI * (r.next() < 0.5f ? -1.f : 1.f);
    float k = 1.f - clampf(tn, 0.f, 1.f);
    return mul(axisAngle(a1, t1 * k * k), mul(axisAngle(a2, t2 * std::pow(k, 1.5f)), fin));
}

int gDiceStyle = 1;   // 0 = white with black pips, 1 = red with white pips (set from the settings every frame)

void drawDie(Gfx &g, float cx, float cy, float L, const M3 &R0, float alpha, float rest = 0.f) {
    const bool red = gDiceStyle == 1;
    const float D = 6.f, c = 0.20f, ins = 1.f - c;   // c = how much of each edge is rounded off
    // camera: while tumbling it looks from above-front so the cube shows its sides; at rest (rest = 1) the face is almost square on to the screen
    const M3 R = mul(axisAngle({1, 0, 0}, -lerpf(0.45f, 0.17f, rest)), mul(axisAngle({0, 1, 0}, lerpf(0.f, 0.17f, rest)), R0));
    auto proj = [&](Vec3 v) {
        Vec3 w = apply(R, v);
        float k = D / (D - w.z);
        return V2{cx + L * w.x * k, cy + L * w.y * k};
    };
    const Vec3 light = {-0.40f, 0.60f, 0.69f};
    const Col base = red ? Col::hex(0xD81E2B) : Col::hex(0xFBF8EE);
    const Col pipCol = red ? Col::hex(0xFFFFFF, alpha) : Col::hex(0x14141A, alpha);
    auto shade = [&](Vec3 nrm, V2 q) {                  // lit colour for a point of a surface with (rotated) normal nrm
        float diff = std::max(0.f, nrm.x * light.x + nrm.y * light.y + nrm.z * light.z);
        float k = red ? 0.58f + 0.50f * diff : 0.76f + 0.34f * diff;
        float h = clampf((q.y - cy) / (L * 2.2f) + 0.5f, 0.f, 1.f);
        float hk = 0.90f + 0.16f * h;
        return Col(base.r * k * hk, base.g * k * hk, base.b * k * (red ? hk * 0.95f : hk * 1.02f), alpha);
    };
    // rounded edges: 12 bevel strips + 8 corner patches (drawn before the flat faces, which sit on top)
    for (int i = 0; i < 6; i++) for (int j = i + 1; j < 6; j++) {
        const Vec3 &ni = kFaces[i].n, &nj = kFaces[j].n;
        if (std::fabs(ni.x * nj.x + ni.y * nj.y + ni.z * nj.z) > 0.01f) continue;
        Vec3 e = {ni.y * nj.z - ni.z * nj.y, ni.z * nj.x - ni.x * nj.z, ni.x * nj.y - ni.y * nj.x};
        Vec3 nb = apply(R, {(ni.x + nj.x) * 0.7071f, (ni.y + nj.y) * 0.7071f, (ni.z + nj.z) * 0.7071f});
        if (nb.z * D - 1.4142f <= 0.f) continue;
        auto pt = [&](const Vec3 &fa, float ka, const Vec3 &fb, float kb, float se) {
            return Vec3{fa.x * ka + fb.x * kb + e.x * se, fa.y * ka + fb.y * kb + e.y * se, fa.z * ka + fb.z * kb + e.z * se};
        };
        V2 q[4] = {proj(pt(ni, 1.f, nj, ins, -ins)), proj(pt(ni, 1.f, nj, ins, ins)), proj(pt(ni, ins, nj, 1.f, ins)), proj(pt(ni, ins, nj, 1.f, -ins))};
        float xy[8] = {q[0].x, q[0].y, q[1].x, q[1].y, q[2].x, q[2].y, q[3].x, q[3].y};
        Vec3 nA = apply(R, ni), nB = apply(R, nj);
        g.poly(xy, shade(nA, q[0]), shade(nA, q[1]), shade(nB, q[2]), shade(nB, q[3]));
    }
    for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2) for (int sz = -1; sz <= 1; sz += 2) {
        Vec3 nc = apply(R, {sx * 0.5774f, sy * 0.5774f, sz * 0.5774f});
        if (nc.z * D - 1.7321f <= 0.f) continue;
        V2 a1 = proj({float(sx), sy * ins, sz * ins}), a2 = proj({sx * ins, float(sy), sz * ins}), a3 = proj({sx * ins, sy * ins, float(sz)});
        float xy[8] = {a1.x, a1.y, a2.x, a2.y, a3.x, a3.y, a3.x, a3.y};
        Col cc = shade(nc, V2{(a1.x + a2.x + a3.x) / 3.f, (a1.y + a2.y + a3.y) / 3.f});
        g.poly(xy, cc, cc, cc, cc);
    }
    for (const Face &f : kFaces) {
        Vec3 nr = apply(R, f.n);
        if (nr.z * D - 1.f <= 0.02f) continue;
        const float sg[4][2] = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
        float xy[8]; Col cols[4];
        for (int i = 0; i < 4; i++) {
            Vec3 cp = {f.n.x + (f.u.x * sg[i][0] + f.v.x * sg[i][1]) * ins, f.n.y + (f.u.y * sg[i][0] + f.v.y * sg[i][1]) * ins, f.n.z + (f.u.z * sg[i][0] + f.v.z * sg[i][1]) * ins};
            V2 q = proj(cp);
            xy[i * 2] = q.x; xy[i * 2 + 1] = q.y;
            cols[i] = shade(nr, q);
        }
        g.poly(xy, cols[0], cols[1], cols[2], cols[3]);
        // pips as ellipses (the circle on the face seen from the side)
        int n = f.val;
        float rp = n == 1 ? 0.27f : 0.19f;
        Col pc = (n == 1 && !red) ? Col::hex(0xD62828, alpha) : pipCol;
        for (int i = 0; i < kPipCount[n]; i++) {
            float pa = kPips[n][i][0] * 1.20f, pb = kPips[n][i][1] * 1.20f;
            Vec3 cp = {f.n.x + f.u.x * pa + f.v.x * pb, f.n.y + f.u.y * pa + f.v.y * pb, f.n.z + f.u.z * pa + f.v.z * pb};
            V2 p0 = proj(cp);
            V2 pu = proj({cp.x + f.u.x * rp, cp.y + f.u.y * rp, cp.z + f.u.z * rp}) - p0;
            V2 pv = proj({cp.x + f.v.x * rp, cp.y + f.v.y * rp, cp.z + f.v.z * rp}) - p0;
            float A = pu.x * pu.x + pv.x * pv.x, B = pu.x * pu.y + pv.x * pv.y, C = pu.y * pu.y + pv.y * pv.y;
            float m = (A + C) * 0.5f, d = std::sqrt(((A - C) * 0.5f) * ((A - C) * 0.5f) + B * B);
            g.ellipse(p0.x, p0.y, std::sqrt(std::max(0.f, m + d)), std::sqrt(std::max(0.f, m - d)), 0.5f * std::atan2(2.f * B, A - C), pc, 0.f);
        }
    }
    g.glow(cx - L * 0.34f, cy + L * 0.50f, L * 0.80f, Col(1, 1, 1, (red ? 0.30f : 0.24f) * alpha));   // glossy highlight
}

// ------------------------------------------------------------------------------------ pawn (gitti)
void drawPawn(Gfx &g, float x, float y, float r, Col c, float lift, float alpha) {
    float sh = 1.f / (1.f + lift / (r * 2.5f));
    g.ellipse(x + r * 0.28f, y - r * 0.22f, r * 1.05f * sh, r * 0.46f * sh, 0, Col(0, 0, 0, 0.34f * alpha * sh));
    float by = y + lift;
    g.ellipse(x, by + r * 0.02f, r * 1.04f, r * 0.50f, 0, Col(1, 1, 1, 0.62f * alpha));                    // light rim so it stands out on its own colour
    g.ellipse(x, by + r * 0.05f, r * 0.96f, r * 0.45f, 0, c.mul(0.55f).alpha(alpha));
    g.ellipse(x, by + r * 0.20f, r * 0.94f, r * 0.43f, 0, c.alpha(alpha), 0.55f);
    float body[8] = {x - r * 0.64f, by + r * 0.28f, x + r * 0.64f, by + r * 0.28f, x + r * 0.28f, by + r * 1.18f, x - r * 0.28f, by + r * 1.18f};
    g.poly(body, c.mul(0.72f).alpha(alpha), c.mul(0.72f).alpha(alpha), c.mul(1.0f).alpha(alpha), c.mul(1.0f).alpha(alpha));
    float hi[8] = {x - r * 0.46f, by + r * 0.32f, x - r * 0.20f, by + r * 0.32f, x - r * 0.12f, by + r * 1.12f, x - r * 0.24f, by + r * 1.12f};
    g.poly(hi, Col(1, 1, 1, 0.22f * alpha));
    g.ellipse(x, by + r * 1.18f, r * 0.34f, r * 0.12f, 0, c.mul(1.1f).alpha(alpha));
    g.disc(x, by + r * 1.55f, r * 0.62f, c.alpha(alpha), 1.f);
}

void drawStar(Gfx &g, float x, float y, float R, Col c) {
    float px[10], py[10];
    for (int i = 0; i < 10; i++) {
        float a = PI / 2.f + i * PI / 5.f, rr = (i % 2 == 0) ? R : R * 0.42f;
        px[i] = x + std::cos(a) * rr; py[i] = y + std::sin(a) * rr;
    }
    for (int i = 0; i < 5; i++) {
        int a = i * 2, b = i * 2 + 1, c2 = (i * 2 + 2) % 10;
        float xy[8] = {x, y, px[a], py[a], px[b], py[b], px[c2], py[c2]};
        g.poly(xy, c);
    }
}

// padlock icon, s = total height; used for a locked home (HARD rules)
void drawLock(Gfx &g, float x, float y, float s, float alpha) {
    const Col gold = Col::hex(0xF5B83D).alpha(alpha);
    const float by = y - s * 0.16f, bw = s * 0.74f, bh = s * 0.52f;
    g.ring(x, y + s * 0.16f, s * 0.22f, s * 0.085f, Col::hex(0xDADDE6).alpha(alpha));          // shackle
    g.rrect(x, by - s * 0.02f, bw + s * 0.10f, bh + s * 0.10f, Col(0, 0, 0, 0.40f * alpha), Col(0, 0, 0, 0.40f * alpha), 0.25f);   // outline
    g.rrect(x, by, bw, bh, Col::hex(0x2B2F3B).alpha(alpha), Col::hex(0x14161D).alpha(alpha), 0.22f);                               // body
    g.flat(x, by + s * 0.05f, s * 0.075f, gold);                                                // key hole
    g.rect(x, by - s * 0.06f, s * 0.05f, s * 0.14f, gold);
}
}  // namespace

namespace {
V2 slotPos(const Lay &L, int p, int t) {
    float cx, cy; ldYardCenter(p, cx, cy);
    return gridPos(L, cx + (t % 2 ? 1.f : -1.f) * 1.3f, cy + (t < 2 ? -1.f : 1.f) * 1.3f);
}
V2 finPos(const Lay &L, int p, int t, int ntok) {
    static const float dx[4] = {0, -1, 0, 1}, dy[4] = {1, 0, -1, 0};
    float off = (t - (ntok - 1) * 0.5f) * 0.40f;
    return gridPos(L, 7.5f + dx[p] * 0.95f - dy[p] * off, 7.5f + dy[p] * 0.95f + dx[p] * off);
}
V2 relPos(const Lay &L, int p, int rel, int t, int ntok) {
    if (rel < 0) return slotPos(L, p, t);
    if (rel >= LD_HOME) return finPos(L, p, t, ntok);
    int c, r;
    if (rel <= 50) ldLoopCell(ldLoopIndex(p, rel), c, r); else ldHomeCell(p, rel - 51, c, r);
    return cellCenter(L, c, r);
}

// board colour schemes: 0 classic wood, 1 midnight, 2 marble
struct Pal { bool wood; Col frameA, frameB, edge, surfTop, surfBot, cellTop, cellBot, border, yardTop, yardBot, star, dot; };
Pal palette(int theme) {
    switch (theme) {
        case 1: return {false, Col::hex(0x2B3558), Col::hex(0x131A31), Col::hex(0x0A0F1E), Col::hex(0x1B2340), Col::hex(0x131A31),
                        Col::hex(0x2A3558), Col::hex(0x1F2845), Col::hex(0x44527F), Col::hex(0x222C4C), Col::hex(0x182140), Col::hex(0x7F8DBD), Col::hex(0xCFD8F2)};
        case 2: return {false, Col::hex(0xE4DED3), Col::hex(0xB9B1A3), Col::hex(0x8E8678), Col::hex(0xFFFFFF), Col::hex(0xF1F1F5),
                        Col::hex(0xFFFFFF), Col::hex(0xEDEDF2), Col::hex(0xB3B0BC), Col::hex(0xFFFFFF), Col::hex(0xF1F1F6), Col::hex(0xA9A5B5), Col::hex(0x666273)};
        default: return {true, Col(0.56f, 0.33f, 0.15f), Col(0.56f, 0.33f, 0.15f), Col::hex(0x3A2412), Col::hex(0xFFFAEC), Col::hex(0xEFE3C6),
                         Col::hex(0xFFFCF2), Col::hex(0xF1E7CE), Col::hex(0x8F7F5E), Col::hex(0xFFFBF1), Col::hex(0xF2E8D0), Col::hex(0x9B8A66), Col::hex(0xFFFBEF)};
    }
}

// traditional wooden Ludo board: honey wood, thin dark lines, a rosette flower in every yard
void paintWoodenBoard(Gfx &g, const Lay &L) {
    const float cs = L.cs, by = L.by, Lb = L.Lb;
    const Col ink = Col::hex(0x2E1B0B), inkSoft = Col(0.18f, 0.10f, 0.04f, 0.85f);
    auto outline = [&](float cx, float cy, float w, float h, float th, Col c) {
        g.line(cx - w / 2 - th / 2, cy + h / 2, cx + w / 2 + th / 2, cy + h / 2, th, c);
        g.line(cx - w / 2 - th / 2, cy - h / 2, cx + w / 2 + th / 2, cy - h / 2, th, c);
        g.line(cx - w / 2, cy - h / 2 - th / 2, cx - w / 2, cy + h / 2 + th / 2, th, c);
        g.line(cx + w / 2, cy - h / 2 - th / 2, cx + w / 2, cy + h / 2 + th / 2, th, c);
    };
    g.rrect(10.f, by - 16.f, Lb + 96.f, Lb + 96.f, Col(0, 0, 0, 0.38f), Col(0, 0, 0, 0.38f), 0.04f);
    g.wood(0, by, Lb + 84.f, Lb + 84.f, Col(0.46f, 0.27f, 0.12f), 0.04f);          // frame
    g.rrect(0, by, Lb + 22.f, Lb + 22.f, ink, ink, 0.01f);
    g.wood(0, by, Lb + 12.f, Lb + 12.f, Col(0.93f, 0.75f, 0.46f), 0.01f);          // playing surface
    outline(0, by, Lb, Lb, 4.f, inkSoft);
    for (int p = 0; p < 4; p++) {                                                     // yards
        float cx, cy; ldYardCenter(p, cx, cy);
        V2 c = gridPos(L, cx, cy);
        g.rect(c.x, c.y, 6.f * cs, 6.f * cs, Col(1, 0.97f, 0.88f, 0.16f));
        outline(c.x, c.y, 6.f * cs, 6.f * cs, 4.f, inkSoft);
        outline(c.x, c.y, 5.55f * cs, 5.55f * cs, 2.2f, inkSoft);
        outline(c.x, c.y, 4.1f * cs, 4.1f * cs, 2.2f, inkSoft);
        const Col pc = seatCol(p), pd = seatDeep(p);
        for (int k = 0; k < 8; k++) {                                                 // rosette flower
            float a = k * PI / 4.f + PI / 8.f, ca = std::cos(a), sa = std::sin(a);
            auto kite = [&](float sc, Col ci, Col cs2, Col ct) {
                const float r0 = 0.30f * cs * sc, r1 = 1.00f * cs * sc, r2 = 2.05f * cs * sc, w = 0.34f;
                V2 in = {c.x + ca * r0, c.y + sa * r0}, tp = {c.x + ca * r2, c.y + sa * r2};
                V2 s1 = {c.x + std::cos(a + w) * r1, c.y + std::sin(a + w) * r1}, s2 = {c.x + std::cos(a - w) * r1, c.y + std::sin(a - w) * r1};
                float xy[8] = {in.x, in.y, s1.x, s1.y, tp.x, tp.y, s2.x, s2.y};
                g.poly(xy, ci, cs2, ct, cs2);
            };
            kite(1.08f, ink, ink, ink);
            kite(1.f, pd, pc.mul(1.05f), pc.mul(1.18f));
            g.line(c.x + ca * 0.45f * cs, c.y + sa * 0.45f * cs, c.x + ca * 1.7f * cs, c.y + sa * 1.7f * cs, 3.f, Col(1, 1, 1, 0.28f));
        }
        g.flat(c.x, c.y, 0.52f * cs, ink);
        g.flat(c.x, c.y, 0.44f * cs, pc);
        g.flat(c.x - 0.08f * cs, c.y + 0.08f * cs, 0.18f * cs, Col(1, 1, 1, 0.38f));
        for (int t = 0; t < 4; t++) {                                                 // token spots
            V2 sp = slotPos(L, p, t);
            g.flat(sp.x, sp.y, 0.56f * cs, Col(0, 0, 0, 0.18f));
            g.ring(sp.x, sp.y, 0.54f * cs, 4.f, Col(1, 1, 1, 0.80f));
            g.ring(sp.x, sp.y, 0.58f * cs, 2.f, inkSoft);
        }
    }
    for (int i = 0; i < LD_LOOP; i++) {                                               // shared track
        int c, r; ldLoopCell(i, c, r);
        V2 q = cellCenter(L, c, r);
        int owner = -1;
        for (int p = 0; p < 4; p++) if (ldStartIndex(p) == i) owner = p;
        if (owner >= 0) g.rectGrad(q.x, q.y, cs, cs, seatCol(owner).mul(1.08f), seatDeep(owner));
        else g.rect(q.x, q.y, cs, cs, Col(1, 0.98f, 0.90f, 0.20f));
        outline(q.x, q.y, cs, cs, 2.6f, inkSoft);
        if (owner >= 0) drawStar(g, q.x, q.y, cs * 0.30f, Col(1, 1, 1, 0.92f));
        else if (ldSafeIndex(i)) drawStar(g, q.x, q.y, cs * 0.32f, Col(0.22f, 0.12f, 0.04f, 0.78f));
    }
    for (int p = 0; p < 4; p++) for (int k = 0; k < 5; k++) {                         // home columns
        int c, r; ldHomeCell(p, k, c, r);
        V2 q = cellCenter(L, c, r);
        g.rectGrad(q.x, q.y, cs, cs, seatCol(p).mul(1.08f), seatDeep(p));
        outline(q.x, q.y, cs, cs, 2.6f, inkSoft);
    }
    V2 m = gridPos(L, 7.5f, 7.5f);                                                    // centre: four triangles
    const float cor[4][4] = {{6, 9, 9, 9}, {6, 6, 6, 9}, {6, 6, 9, 6}, {9, 6, 9, 9}};
    for (int p = 0; p < 4; p++) {
        V2 a = gridPos(L, cor[p][0], cor[p][1]), b = gridPos(L, cor[p][2], cor[p][3]);
        float xy[8] = {a.x, a.y, b.x, b.y, m.x, m.y, m.x, m.y};
        g.poly(xy, seatDeep(p), seatDeep(p), seatCol(p).mul(1.12f), seatCol(p).mul(1.12f));
        g.line(m.x, m.y, a.x, a.y, 3.5f, inkSoft);
        g.line(a.x, a.y, b.x, b.y, 3.5f, inkSoft);
    }
}

void paintBoard(Gfx &g, const Lay &L, int theme) {
    if (theme == 3) { paintWoodenBoard(g, L); return; }
    const Pal P = palette(theme);
    const float cs = L.cs, by = L.by, Lb = L.Lb;
    g.rrect(10.f, by - 16.f, Lb + 96.f, Lb + 96.f, Col(0, 0, 0, 0.38f), Col(0, 0, 0, 0.38f), 0.06f);
    if (P.wood) g.wood(0, by, Lb + 84.f, Lb + 84.f, P.frameA, 0.07f);
    else {
        g.rrect(0, by, Lb + 84.f, Lb + 84.f, P.frameA, P.frameB, 0.07f);
        g.rrect(0, by, Lb + 70.f, Lb + 70.f, Col(1, 1, 1, 0.10f), Col(0, 0, 0, 0.10f), 0.06f);
    }
    g.rrect(0, by, Lb + 18.f, Lb + 18.f, P.edge, P.edge, 0.03f);
    g.rrect(0, by, Lb + 8.f, Lb + 8.f, P.surfTop, P.surfBot, 0.02f);
    for (int p = 0; p < 4; p++) {                                     // yards
        float cx, cy; ldYardCenter(p, cx, cy);
        V2 c = gridPos(L, cx, cy);
        g.rrect(c.x, c.y, 6.f * cs - 3.f, 6.f * cs - 3.f, seatCol(p), seatDeep(p), 0.10f);
        g.rrect(c.x, c.y, 4.5f * cs, 4.5f * cs, P.yardTop, P.yardBot, 0.17f);
        for (int t = 0; t < 4; t++) {
            V2 s = slotPos(L, p, t);
            g.flat(s.x, s.y, 0.52f * cs, seatCol(p).alpha(0.22f));
            g.ring(s.x, s.y, 0.50f * cs, 4.f, seatCol(p).alpha(0.85f));
        }
    }
    for (int i = 0; i < LD_LOOP; i++) {                               // shared track
        int c, r; ldLoopCell(i, c, r);
        V2 q = cellCenter(L, c, r);
        int owner = -1;
        for (int p = 0; p < 4; p++) if (ldStartIndex(p) == i) owner = p;
        g.rrect(q.x, q.y, cs - 1.f, cs - 1.f, P.border.alpha(0.85f), P.border.alpha(0.85f), 0.16f);
        if (owner >= 0) g.rrect(q.x, q.y, cs - 4.5f, cs - 4.5f, seatCol(owner), seatDeep(owner), 0.16f);
        else g.rrect(q.x, q.y, cs - 4.5f, cs - 4.5f, P.cellTop, P.cellBot, 0.16f);
        if (owner >= 0) drawStar(g, q.x, q.y, cs * 0.30f, Col(1, 1, 1, 0.92f));
        else if (ldSafeIndex(i)) drawStar(g, q.x, q.y, cs * 0.32f, P.star);
    }
    for (int p = 0; p < 4; p++) for (int k = 0; k < 5; k++) {         // home columns
        int c, r; ldHomeCell(p, k, c, r);
        V2 q = cellCenter(L, c, r);
        g.rrect(q.x, q.y, cs - 1.f, cs - 1.f, seatDeep(p).alpha(0.9f), seatDeep(p).alpha(0.9f), 0.16f);
        g.rrect(q.x, q.y, cs - 4.5f, cs - 4.5f, seatCol(p), seatDeep(p), 0.16f);
    }
    V2 m = gridPos(L, 7.5f, 7.5f);                                    // centre: four triangles
    const float cor[4][4] = {{6, 9, 9, 9}, {6, 6, 6, 9}, {6, 6, 9, 6}, {9, 6, 9, 9}};
    for (int p = 0; p < 4; p++) {
        V2 a = gridPos(L, cor[p][0], cor[p][1]), b = gridPos(L, cor[p][2], cor[p][3]);
        float xy[8] = {a.x, a.y, b.x, b.y, m.x, m.y, m.x, m.y};
        g.poly(xy, seatDeep(p), seatDeep(p), seatCol(p).mul(1.12f), seatCol(p).mul(1.12f));
        g.line(m.x, m.y, a.x, a.y, 3.f, Col(1, 1, 1, 0.55f));
    }
    g.flat(m.x, m.y, cs * 0.30f, P.dot);
    g.ring(m.x, m.y, cs * 0.30f, 3.f, P.border);
}
}  // namespace

// ------------------------------------------------------------------------------------ app plumbing
namespace {
void storeRules(LudoSave &sv, const LRules &r) {
    sv.sixToStart = r.sixToStart; sv.captureBonus = r.captureBonus; sv.threeSixes = r.threeSixes;
    sv.blocksSafe = r.blocksSafe; sv.fullRanks = r.fullRanks; sv.quick = r.tokens == 2;
    sv.captureLock = r.captureLock; sv.hardMode = r.hardMode; sv.tokenCount = uint32_t(r.tokens);
    sv.sixReroll = r.sixReroll; sv.twoDice = r.twoDice; sv.capturePenalty = r.capturePenalty;
}
}  // namespace

void App::init(const std::string &saveFile) {
    size_t sl = saveFile.find_last_of('/');
    std::string dir = sl == std::string::npos ? std::string() : saveFile.substr(0, sl + 1);
    lu_.savePath = saveFile;
    lu_.gamePath = dir + "ludo_game.bin";
    lu_.save.load(lu_.savePath);
    const LudoSave &s = lu_.save;
    lu_.players = int(clampf(float(s.players), 2.f, 4.f));
    lu_.mode = s.mode ? 1 : 0;
    lu_.diff = int(clampf(float(s.diff), 0.f, 3.f));
    lu_.rules.sixToStart = s.sixToStart != 0; lu_.rules.captureBonus = s.captureBonus != 0; lu_.rules.threeSixes = s.threeSixes != 0;
    lu_.rules.blocksSafe = s.blocksSafe != 0; lu_.rules.fullRanks = s.fullRanks != 0; lu_.rules.tokens = s.tokensSetting();
    lu_.rules.captureLock = s.captureLock != 0; lu_.rules.hardMode = s.hardMode != 0;
    lu_.rules.sixReroll = s.sixReroll != 0; lu_.rules.twoDice = s.twoDice != 0; lu_.rules.capturePenalty = s.capturePenalty != 0;
    if (lu_.rules.sixReroll) lu_.rules.sixToStart = false;       // a 6 that only gives another roll cannot also bring a token out
    applyTheme(s.dark != 0);
    audio_.setEnabled(s.sound != 0);
    rng_ ^= uint32_t(std::time(nullptr)) * 2654435761u;
    {   // is there a game to continue?
        FILE *f = fopen(lu_.gamePath.c_str(), "rb");
        if (f) {
            std::string data(4096, '\0');
            size_t n = fread(&data[0], 1, data.size(), f);
            fclose(f);
            data.resize(n);
            Ludo probe; int ui = 0;
            lu_.hasSnap = probe.restore(data, ui);
        }
    }
    screen_ = Screen::MENU;
}

void App::onPause() {
    if (screen_ == Screen::GAME && lu_.overT < 0) lu_.paused = true;
    audio_.stop();
}

void App::onBack() {
    switch (screen_) {
        case Screen::MENU: if (quitFn) quitFn(); break;
        case Screen::SETUP: case Screen::STATS: case Screen::SETTINGS: screen_ = Screen::MENU; screenT_ = 0; break;
        case Screen::HOWTO: screen_ = prev_; screenT_ = 0; break;
        case Screen::GAME: ludoBack(); break;
    }
}

void App::ludoBack() {
    if (screen_ == Screen::GAME) {
        if (lu_.overT >= 0) { screen_ = Screen::SETUP; screenT_ = 0; }
        else lu_.paused = !lu_.paused;
    } else { screen_ = Screen::MENU; screenT_ = 0; }
}

void App::toast(const std::string &t, Col c, float dur, float size) {
    if (toasts_.size() >= 3) toasts_.erase(toasts_.begin() + 1);
    toasts_.push_back({t, c, 0.f, dur, size});
}

void App::burst(V2 p, Col c, int n, float speed, bool spark) {
    for (int i = 0; i < n && parts_.size() < 400; i++) {
        float a = rnd() * 6.2831853f, s = speed * (0.35f + 0.65f * rnd());
        float life = (spark ? 0.28f : 0.55f) * (0.6f + 0.6f * rnd());
        parts_.push_back({p, V2{std::cos(a), std::sin(a)} * s, life, life, spark ? 3.5f : 6.f + 5.f * rnd(), c, spark});
    }
}

void App::update(float dt) {
    time_ += dt; screenT_ += dt;
    for (auto &t : toasts_) { if (&t == &toasts_.front()) t.t += dt; }
    if (!toasts_.empty() && toasts_.front().t >= toasts_.front().dur) toasts_.erase(toasts_.begin());
    for (auto &p : parts_) { p.life -= dt; p.p += p.v * dt; p.v = p.v * std::exp(-3.f * dt); }
    parts_.erase(std::remove_if(parts_.begin(), parts_.end(), [](const Particle &p) { return p.life <= 0; }), parts_.end());
    if (audio_.needsRestart()) { audio_.stop(); audio_.start(); audio_.clearRestart(); }
    std::string packed;
    while (netPop(packed)) {                                   // friend names typed in the Kotlin dialog
        size_t pos = 0;
        for (int i = 0; i < 4; i++) {
            size_t e = packed.find('|', pos);
            std::string nm = packed.substr(pos, e == std::string::npos ? std::string::npos : e - pos);
            for (auto &ch : nm) ch = char(std::toupper((unsigned char) ch));
            memset(lu_.save.names[i], 0, sizeof lu_.save.names[i]);
            strncpy(lu_.save.names[i], nm.c_str(), sizeof(lu_.save.names[i]) - 1);
            if (e == std::string::npos) break;
            pos = e + 1;
        }
        persist();
    }
    if (screen_ == Screen::GAME) ludoUpdate(dt);
}

void App::touch(int action_, int pid, float x, float y) {
    auto hitAt = [&](float px, float py) {
        for (int i = int(hits_.size()) - 1; i >= 0; i--) {
            const Hit &h = hits_[i];
            if (std::fabs(px - h.x) <= h.w / 2 && std::fabs(py - h.y) <= h.h / 2) return h.id;
        }
        return -1;
    };
    if (action_ == 0) {
        if (activeId_ != -1) return;
        activeId_ = pid;
        pressed_ = hitAt(x, y);
    } else if (action_ == 1) {
        if (pid != activeId_) return;
        if (pressed_ != -1 && hitAt(x, y) != pressed_) pressed_ = -1;
    } else {
        if (pid != activeId_) return;
        activeId_ = -1;
        int rel = hitAt(x, y);
        int id = pressed_;
        pressed_ = -1;
        if (id != -1 && rel == id && action_ == 2) action(id);
    }
}

void App::draw(Gfx &g) {
    hits_.clear();
    gDiceStyle = lu_.save.diceStyle();
    drawBackground(g);
    switch (screen_) {
        case Screen::MENU: drawMenu(g); break;
        case Screen::SETUP: drawLudoSetup(g); break;
        case Screen::HOWTO: drawLudoHowTo(g); break;
        case Screen::SETTINGS: drawSettings(g); break;
        case Screen::STATS: drawStats(g); break;
        case Screen::GAME: drawLudoGame(g); break;
    }
}

// ------------------------------------------------------------------------------------ ui helpers
bool App::button(Gfx &g, int id, float x, float y, float w, float h, const std::string &label, Col top, Col bot, float textH, bool enabled) {
    bool down = pressed_ == id && enabled;
    float oy = down ? -6.f : 0.f;
    float k = enabled ? (down ? 0.82f : 1.f) : 0.45f;
    g.rrect(x, y - 10.f, w, h, Col(0, 0, 0, 0.35f), Col(0, 0, 0, 0.35f), 0.55f);
    g.rrect(x, y + oy, w, h, top.mul(k), bot.mul(k), 0.55f);
    g.rrect(x, y + oy + h * 0.5f - 16.f, w - 56.f, 7.f, Col(1, 1, 1, 0.22f), Col(1, 1, 1, 0.05f), 1.f);
    bool lightFill = (0.299f * top.r + 0.587f * top.g + 0.114f * top.b) > 0.62f;
    Col tc = lightFill ? Col::hex(0x10203F) : Col(1, 1, 1, 1);
    if (!lightFill) g.text(label, x, y + oy - 2.f, textH, Col(0, 0, 0, 0.35f));
    g.text(label, x, y + oy, textH, enabled ? tc : tc.alpha(0.5f));
    if (enabled) hits_.push_back({id, x, y, w, h});
    return down;
}

void App::tile(Gfx &g, int id, float x, float y, float w, float h, const std::string &label, const std::string &sub, Col top, Col bot) {
    bool down = pressed_ == id;
    float oy = down ? -5.f : 0.f, k = down ? 0.84f : 1.f;
    g.rrect(x, y - 8.f, w, h, Col(0, 0, 0, 0.32f), Col(0, 0, 0, 0.32f), 0.32f);
    g.rrect(x, y + oy, w, h, top.mul(k), bot.mul(k), 0.32f);
    g.rrect(x, y + oy + h * 0.5f - 13.f, w - 50.f, 6.f, Col(1, 1, 1, 0.20f), Col(1, 1, 1, 0.04f), 1.f);
    bool lightFill = (0.299f * top.r + 0.587f * top.g + 0.114f * top.b) > 0.62f;
    Col tc = lightFill ? Col::hex(0x10203F) : Col(1, 1, 1, 1);
    g.text(label, x, y + oy + (sub.empty() ? 0.f : 17.f), 42.f, tc);
    if (!sub.empty()) g.text(sub, x, y + oy - 28.f, 25.f, tc.alpha(0.72f));
    hits_.push_back({id, x, y, w, h});
}

void App::segment(Gfx &g, int idBase, float cy, const std::vector<std::string> &labels, int selected, float totalW) {
    int n = int(labels.size());
    float gap = 18.f, w = (totalW - gap * (n - 1)) / n, x0 = -totalW / 2 + w / 2;
    for (int i = 0; i < n; i++) {
        bool sel = i == selected;
        Col t = sel ? kTeal : kBtnTop, b = sel ? Col::hex(0x14A08C) : kBtnBot;
        button(g, idBase + i, x0 + i * (w + gap), cy, w, 118.f, labels[i], t, b, 42.f);
    }
}

void App::toggleTile(Gfx &g, int id, float x, float y, float w, float h, const std::string &label, bool on) {
    bool down = pressed_ == id;
    float oy = down ? -4.f : 0.f;
    Col sh(0, 0, 0, gDark ? 0.30f : 0.14f);
    g.rrect(x, y - 8.f, w, h, sh, sh, 0.32f);
    g.rrect(x, y + oy, w, h, kCardTop, kCardBot, 0.32f);
    g.text(label, x - w / 2 + 38.f, y + oy, 34.f, kText, Align::LEFT);
    float sx = x + w / 2 - 92.f;
    Col c = on ? kTeal : (gDark ? Col::hex(0x3A4A6A) : Col::hex(0xAAB8D2));
    g.rrect(sx, y + oy, 124.f, 60.f, c, c, 1.f);
    g.flat(sx + (on ? 32.f : -32.f) + 2.f, y + oy - 3.f, 25.f, Col(0, 0, 0, 0.25f));
    g.disc(sx + (on ? 32.f : -32.f), y + oy, 25.f, Col(1, 1, 1, 1), 0.3f);
    hits_.push_back({id, x, y, w, h});
}

void App::drawBackground(Gfx &g) {
    g.rectGrad(0, 0, ww_ + 4, wh_ + 4, kBgTop, kBgBot);
    for (int i = 0; i < 9; i++) {
        float a = time_ * 0.05f + i * 0.9f;
        g.glow(std::sin(a * 1.3f + i) * ww_ * 0.5f, std::cos(a + i * 2.f) * wh_ * 0.5f, 260.f + (i % 3) * 110.f,
               (i % 2 ? kTeal : kGold).alpha(gDark ? 0.07f : 0.12f));
    }
}

// ------------------------------------------------------------------------------------ setup / flow
void App::action(int id) {
    click();
    ludoAction(id);
}

std::string App::ludoName(int p) const {
    if (lu_.mode == 0) return p == LC_RED ? "YOU" : "CPU";
    if (lu_.save.names[p][0]) return lu_.save.names[p];
    return colName(p);
}

void App::saveSnapshot() {
    if (lu_.game.phase() != LPhase::ROLL_WAIT) return;
    std::string d = lu_.game.snapshot(lu_.mode);
    FILE *f = fopen(lu_.gamePath.c_str(), "wb");
    if (!f) return;
    fwrite(d.data(), 1, d.size(), f);
    fclose(f);
    lu_.hasSnap = true;
}

void App::clearSnapshot() {
    remove(lu_.gamePath.c_str());
    lu_.hasSnap = false;
}

void App::ludoStart() {
    LudoSave &sv = lu_.save;
    sv.players = lu_.players; sv.mode = lu_.mode; sv.diff = lu_.diff;
    storeRules(sv, lu_.rules);
    persist();
    bool human[4];
    for (int p = 0; p < 4; p++) human[p] = lu_.mode == 1 || p == LC_RED;
    uint32_t seed = uint32_t(rnd() * 4294967000.f) ^ uint32_t(std::time(nullptr)) ^ 0xA5F1u;
    lu_.game.newGame(lu_.players, human, lu_.diff, lu_.rules, seed | 1u);
    lu_.game.setAutoSingle(sv.autoMove != 0);
    for (int p = 0; p < 4; p++) { lu_.dieVal[p] = 1; lu_.dieVal2[p] = 1; lu_.dieSeed[p] = seed * (p + 3) + 17u * p; lu_.dieSeed2[p] = seed * (p + 9) + 29u * p; }
    lu_.evs.clear(); lu_.flights.clear();
    lu_.paused = false; lu_.statsDone = false; lu_.overT = -1.f; lu_.xpGain = 0; lu_.lastTurn = -1;
    parts_.clear(); toasts_.clear();
    screen_ = Screen::GAME; screenT_ = 0;
    saveSnapshot();
    if (lu_.mode == 0 && lu_.rules.sixToStart && !lu_.rules.hardMode) toast("ROLL A 6 TO START", kGold, 1.8f, 70.f);
}

void App::ludoContinue() {
    FILE *f = fopen(lu_.gamePath.c_str(), "rb");
    if (!f) { lu_.hasSnap = false; return; }
    std::string data(4096, '\0');
    size_t n = fread(&data[0], 1, data.size(), f);
    fclose(f);
    data.resize(n);
    int ui = 0;
    if (!lu_.game.restore(data, ui)) { clearSnapshot(); return; }
    lu_.mode = ui ? 1 : 0; lu_.players = lu_.game.players(); lu_.diff = lu_.game.skill(); lu_.rules = lu_.game.rules();
    lu_.game.setAutoSingle(lu_.save.autoMove != 0);
    for (int p = 0; p < 4; p++) { lu_.dieVal[p] = 1 + (p * 2) % 6; lu_.dieVal2[p] = 1 + (p * 2 + 3) % 6; lu_.dieSeed[p] = 99u * (p + 5); lu_.dieSeed2[p] = 57u * (p + 11); }
    lu_.evs.clear(); lu_.flights.clear();
    lu_.paused = false; lu_.statsDone = false; lu_.overT = -1.f; lu_.xpGain = 0;
    parts_.clear(); toasts_.clear();
    screen_ = Screen::GAME; screenT_ = 0;
}

void App::ludoAction(int id) {
    LudoSave &sv = lu_.save;
    auto setup = [&]() { sv.players = lu_.players; sv.mode = lu_.mode; sv.diff = lu_.diff; storeRules(sv, lu_.rules); persist(); };
    switch (id) {
        // ---- main menu
        case LD_M_CONT: ludoContinue(); break;
        case LD_M_PLAY: screen_ = Screen::SETUP; screenT_ = 0; break;
        case LD_M_QUICK: lu_.mode = 0; ludoStart(); break;
        case LD_M_FRIENDS: lu_.mode = 1; ludoStart(); break;
        case LD_M_STATS: screen_ = Screen::STATS; screenT_ = 0; break;
        case LD_M_HOW: prev_ = screen_; screen_ = Screen::HOWTO; screenT_ = 0; break;
        case LD_M_SET: screen_ = Screen::SETTINGS; screenT_ = 0; break;
        case LD_M_EXIT: if (quitFn) quitFn(); break;
        case LD_M_THEME: case LD_S_DARK: sv.dark ^= 1; applyTheme(sv.dark != 0); persist(); break;
        // ---- settings
        case LD_S_SND: sv.sound ^= 1; audio_.setEnabled(sv.sound != 0); persist(); break;
        case LD_S_HAP: sv.haptics ^= 1; persist(); break;
        case LD_S_HINT: sv.hints ^= 1; persist(); break;
        case LD_S_AUTO: sv.autoMove ^= 1; lu_.game.setAutoSingle(sv.autoMove != 0); persist(); break;
        case LD_S_BOARD: case LD_S_BOARD + 1: case LD_S_BOARD + 2: case LD_S_BOARD + 3: sv.theme = (sv.theme & ~7u) | uint32_t(id - LD_S_BOARD); persist(); break;
        case LD_S_DICE: case LD_S_DICE + 1: sv.theme = (sv.theme & ~(3u << 3)) | (uint32_t(id - LD_S_DICE) << 3); persist(); break;
        case LD_S_NAMES: if (openNamesFn) { std::string s; for (int i = 0; i < 4; i++) { s += sv.names[i]; if (i < 3) s += '|'; } openNamesFn(s); } break;
        // ---- setup
        case LD_P2: case LD_P3: case LD_P4: lu_.players = id - LD_P2 + 2; setup(); break;
        case LD_VS_CPU: lu_.mode = 0; setup(); break;
        case LD_FRIENDS: lu_.mode = 1; setup(); break;
        case LD_D0: case LD_D0 + 1: case LD_D0 + 2: case LD_D0 + 3: lu_.diff = id - LD_D0; setup(); break;
        case LD_T_SIX: lu_.rules.sixToStart = !lu_.rules.sixToStart; if (lu_.rules.sixToStart) lu_.rules.sixReroll = false; setup(); break;
        case LD_T_REROLL: lu_.rules.sixReroll = !lu_.rules.sixReroll; if (lu_.rules.sixReroll) lu_.rules.sixToStart = false; setup(); break;
        case LD_T_TWO: lu_.rules.twoDice = !lu_.rules.twoDice; setup(); break;
        case LD_T_TRAP: lu_.rules.capturePenalty = !lu_.rules.capturePenalty; setup(); break;
        case LD_T_CAP: lu_.rules.captureBonus = !lu_.rules.captureBonus; setup(); break;
        case LD_T_3S: lu_.rules.threeSixes = !lu_.rules.threeSixes; setup(); break;
        case LD_T_BLK: lu_.rules.blocksSafe = !lu_.rules.blocksSafe; setup(); break;
        case LD_T_RANK: lu_.rules.fullRanks = !lu_.rules.fullRanks; setup(); break;
        case LD_T_QUICK: lu_.rules.tokens = lu_.rules.tokens == 4 ? 2 : lu_.rules.tokens == 2 ? 1 : 4; setup(); break;   // 4 -> 2 -> 1 -> 4
        case LD_T_LOCK: lu_.rules.captureLock = !lu_.rules.captureLock; setup(); break;
        case LD_T_HARD: {   // one switch for the whole hard package: home lock, no hints / highlights, 6 = reroll, bonus rolls, 3 sixes
            bool on = !lu_.rules.hardMode;
            lu_.rules.hardMode = on; lu_.rules.captureLock = on; lu_.rules.capturePenalty = on;
            if (on) { lu_.rules.sixReroll = true; lu_.rules.sixToStart = false; lu_.rules.captureBonus = true; lu_.rules.threeSixes = true; }
            setup();
            break;
        }
        case LD_START: case LD_AGAIN: case LD_RESTART: ludoStart(); break;
        case LD_HOW: prev_ = screen_; screen_ = Screen::HOWTO; screenT_ = 0; break;
        case LD_BACK: onBack(); break;
        // ---- in game
        case LD_ROLL: lu_.game.roll(lu_.evs); break;
        case LD_PAUSE: lu_.paused = true; break;
        case LD_RESUME: lu_.paused = false; break;
        case LD_MENU: screen_ = Screen::MENU; screenT_ = 0; lu_.paused = false; break;
        case LD_SETUP: screen_ = Screen::SETUP; screenT_ = 0; lu_.paused = false; break;
        default:
            if (id >= LD_TOK && id < LD_TOK + 4) lu_.game.choose(id - LD_TOK, lu_.evs);
            break;
    }
}

void App::ludoUpdate(float dt) {
    lu_.time += dt;
    if (lu_.paused) return;
    lu_.game.update(dt, lu_.evs);
    ludoEvents();
    for (auto &f : lu_.flights) f.tm += dt;
    lu_.flights.erase(std::remove_if(lu_.flights.begin(), lu_.flights.end(), [](const LudoUi::Flight &f) { return f.tm >= f.dur; }), lu_.flights.end());
    if (lu_.overT >= 0) lu_.overT += dt;
}

void App::ludoEvents() {
    const Lay L = layoutFor(ww_, wh_);
    const Ludo &G = lu_.game;
    std::vector<LEvent> evs;
    evs.swap(lu_.evs);
    for (const LEvent &e : evs) {
        switch (e.type) {
            case LE_ROLL_START:
                lu_.dieVal[e.player] = e.value; lu_.dieSeed[e.player] = uint32_t(e.aux) * 31u + e.player + 1u;
                lu_.dieVal2[e.player] = e.tok > 0 ? e.tok : 1; lu_.dieSeed2[e.player] = uint32_t(e.aux) * 131u + e.player + 7u;
                audio_.play(Snd::CLICK, 0.5f, 1.6f); audio_.play(Snd::WALL, 0.30f, 2.4f);
                break;
            case LE_ROLL_BOUNCE:
                audio_.play(Snd::CLACK, 0.20f + 0.0075f * e.aux, 1.5f - 0.15f * e.value);
                if (e.player >= 0 && e.player < 4 && G.phase() == LPhase::ROLLING && G.rollProgress() > 0.3f) burst(dieLanding(L, e.player), Col(1, 1, 1, 0.9f), 5, 260.f, true);
                break;
            case LE_ROLL_DONE:
                if (e.player >= 0 && e.player < 4) lu_.dieDoneT[e.player] = lu_.time;
                audio_.play(Snd::CLACK, 0.22f, 1.1f);
                if (e.value == 6 || e.tok == 6) { audio_.play(Snd::QUEEN, 0.55f); toast("SIX!", kGold, 1.0f, 100.f); haptic(0); }
                break;
            case LE_HOP: audio_.play(Snd::CLICK, 0.35f, 0.9f + 0.04f * float(e.value % 6)); break;
            case LE_ENTER: audio_.play(Snd::STRIKE, 0.35f, 1.3f); break;
            case LE_CAPTURE: {
                int c, r; ldLoopCell(e.aux, c, r);
                V2 from = cellCenter(L, c, r), to = slotPos(L, e.player, e.tok);
                lu_.flights.push_back({e.player, e.tok, from.x, from.y, to.x, to.y, 0.f, 0.8f});
                burst(from, seatCol(e.player), 22, 520.f, false);
                burst(from, Col(1, 1, 1, 1), 14, 700.f, true);
                audio_.play(Snd::STRIKE, 0.9f, 0.8f); audio_.play(Snd::POCKET, 0.5f, 0.7f);
                haptic(1);
                toast(lu_.mode == 0 && e.value == LC_RED ? "YOU CAPTURED!" : ludoName(e.value) + " CAPTURES!", seatCol(e.value), 1.4f, 78.f);
                break;
            }
            case LE_HOME: {
                V2 m = relPos(L, e.player, LD_HOME, e.tok, G.rules().tokens);
                burst(m, seatCol(e.player), 26, 620.f, false); burst(m, Col(1, 1, 1, 1), 16, 760.f, true);
                audio_.play(Snd::POCKET, 0.8f); audio_.play(Snd::QUEEN, 0.7f);
                toast("HOME!", seatCol(e.player), 1.2f, 96.f); haptic(0);
                break;
            }
            case LE_NO_MOVE: toast("NO MOVE", kDim, 0.9f, 64.f); break;
            case LE_UNLOCK: {
                int c, r; ldHomeCell(e.player, 0, c, r);
                V2 m = cellCenter(L, c, r);
                burst(m, kGold, 18, 480.f, true); burst(m, seatCol(e.player), 14, 380.f, false);
                audio_.play(Snd::QUEEN, 0.6f, 1.2f); haptic(0);
                if (e.aux) toast("NOBODY CAN MOVE - HOMES OPEN", kGold, 1.8f, 54.f);
                else toast(lu_.mode == 0 && e.player == LC_RED ? "YOUR HOME IS UNLOCKED!" : ludoName(e.player) + " HOME UNLOCKED", kGold, 1.5f, 62.f);
                break;
            }
            case LE_PENALTY: {       // KILL TRAP: the capturing token was moved again
                V2 from = relPos(L, e.player, e.value, e.tok, G.rules().tokens), to = slotPos(L, e.player, e.tok);
                lu_.flights.push_back({e.player, e.tok, from.x, from.y, to.x, to.y, 0.f, 0.8f});
                burst(from, kRed, 20, 520.f, false); burst(from, Col(1, 1, 1, 1), 10, 640.f, true);
                audio_.play(Snd::FOUL, 0.6f, 0.8f); audio_.play(Snd::POCKET, 0.4f, 0.6f); haptic(1);
                toast("SAME TOKEN MOVED - CAPTURE UNDONE", kRed, 2.0f, 46.f);
                break;
            }
            case LE_REVIVE: {        // the captured token stands again where it was captured
                V2 m = relPos(L, e.player, e.value, e.tok, G.rules().tokens);
                burst(m, seatCol(e.player), 16, 420.f, true);
                audio_.play(Snd::CLICK, 0.6f, 0.7f);
                break;
            }
            case LE_RELOCK:
                audio_.play(Snd::FOUL, 0.45f, 0.9f);
                toast(lu_.mode == 0 && e.player == LC_RED ? "YOUR HOME IS LOCKED AGAIN" : ludoName(e.player) + " HOME LOCKED AGAIN", kRed, 1.5f, 56.f);
                break;
            case LE_THREE_SIXES: toast("3 SIXES - TURN LOST", kRed, 1.4f, 62.f); audio_.play(Snd::FOUL, 0.5f); break;
            case LE_TURN:
                if (G.human(e.player) && (lu_.mode == 1 || e.aux == 0)) audio_.play(Snd::TURN, 0.5f);
                if (e.aux) toast("ROLL AGAIN", G.human(e.player) ? kTeal : kDim, 0.9f, 60.f);
                saveSnapshot();
                break;
            case LE_PLAYER_DONE:
                toast(ludoName(e.player) + " FINISHED  " + placeName(e.value), seatCol(e.player), 1.8f, 62.f);
                break;
            case LE_OVER: {
                lu_.overT = 0.f;
                ludoFinish();
                clearSnapshot();
                bool win = lu_.mode == 1 || G.rankOf(LC_RED) == 1;
                audio_.play(win ? Snd::WIN : Snd::LOSE); haptic(1);
                for (int i = 0; i < 5; i++) burst(V2{(rnd() - 0.5f) * 800.f, L.by + (rnd() - 0.5f) * 500.f}, seatCol(e.player < 0 ? 0 : e.player), 18, 600.f, false);
                break;
            }
        }
    }
}

void App::ludoFinish() {
    if (lu_.statsDone) return;
    lu_.statsDone = true;
    const Ludo &G = lu_.game;
    LudoSave &s = lu_.save;
    if (lu_.mode == 1) s.friends++;
    else {
        int r = G.rankOf(LC_RED), d = std::max(0, std::min(3, lu_.diff));
        static const int base[4] = {30, 50, 70, 100};
        int gain = r == 1 ? base[d] : r == 2 ? base[d] * 4 / 10 : 10;
        gain += std::min(30, G.captures(LC_RED) * 3);
        s.games++; s.gamesBy[d]++;
        if (r == 1) { s.wins++; s.winsBy[d]++; s.streak++; s.best = std::max(s.best, s.streak); } else s.streak = 0;
        s.captures += G.captures(LC_RED);
        s.xp += gain;
        lu_.xpGain = gain;
    }
    persist();
}

// ------------------------------------------------------------------------------------ the game screen
void App::drawLudoGame(Gfx &g) {
    const Lay L = layoutFor(ww_, wh_);
    const Ludo &G = lu_.game;
    const LState &S = G.st();
    const float cs = L.cs;
    const int ntok = S.rules.tokens;
    const bool over = G.phase() == LPhase::OVER;
    const bool humanTurn = !over && G.human(G.turn()) && !lu_.paused;
    paintBoard(g, L, lu_.save.boardTheme());
    const bool help = !S.rules.hardMode;       // HARD game: no hint star, no glowing / lifted tokens - the player has to think
    for (int p = 0; p < 4; p++) {              // padlock in front of the home column of every locked player
        if (!S.active[p] || S.done[p] || !ldLocked(S, p)) continue;
        int c, r; ldHomeCell(p, 0, c, r);
        V2 m = cellCenter(L, c, r);
        drawLock(g, m.x, m.y + cs * 0.04f, cs * 0.86f, 0.92f + 0.08f * std::sin(lu_.time * 3.f + p));
    }

    // ---- tokens
    struct Tk { int p, t; V2 pos; float sc, lift; bool sel, moving, show; };
    std::vector<Tk> tks;
    auto inFlight = [&](int p, int t) { for (auto &f : lu_.flights) if (f.p == p && f.t == t) return true; return false; };
    // clusters: tokens sharing a cell get smaller and spread out
    int cellCount[64] = {0}, cellSeen[64] = {0};
    auto cellKey = [&](int p, int rel) { return rel < 0 || rel >= LD_HOME ? -1 : rel <= 50 ? ldLoopIndex(p, rel) : 52 + (p * 5 + rel - 51) % 12; };
    for (int p = 0; p < 4; p++) {
        if (!S.active[p]) continue;
        for (int t = 0; t < ntok; t++) {
            if (G.moving() && p == G.turn() && t == G.moveTok()) continue;
            int k = cellKey(p, S.pos[p][t]);
            if (k >= 0 && k < 64) cellCount[k]++;
        }
    }
    uint32_t mask = humanTurn ? G.legalMask() : 0u;
    int hintTok = -1;
    if (mask && lu_.save.hints && help) { uint32_t hr = 7u; hintTok = ldChooseMove(S, G.turn(), G.rollValue(), 3, hr); }
    for (int p = 0; p < 4; p++) {
        if (!S.active[p]) continue;
        for (int t = 0; t < ntok; t++) {
            int rel = S.pos[p][t];
            bool mv = G.moving() && p == G.turn() && t == G.moveTok();
            if (inFlight(p, t)) continue;
            Tk k{p, t, V2(), 1.f, 0.f, p == G.turn() && (mask >> t & 1u) != 0, mv, false};
            k.show = k.sel && help;
            if (mv) {
                float st = G.moveSteps();
                int from = G.moveFrom(), to = G.moveTo();
                if (from < 0) {
                    float f = clampf(st, 0.f, 1.f), e = f * f * (3.f - 2.f * f);
                    V2 a = slotPos(L, p, t), b = relPos(L, p, 0, t, ntok);
                    k.pos = V2{lerpf(a.x, b.x, e), lerpf(a.y, b.y, e)}; k.lift = std::sin(f * PI) * cs * 0.9f;
                } else {
                    int n = std::max(1, to - from);
                    int i = std::min(int(st), n - 1);
                    float f = clampf(st - i, 0.f, 1.f), e = f * f * (3.f - 2.f * f);
                    V2 a = relPos(L, p, from + i, t, ntok), b = relPos(L, p, from + i + 1, t, ntok);
                    k.pos = V2{lerpf(a.x, b.x, e), lerpf(a.y, b.y, e)}; k.lift = std::sin(f * PI) * cs * 0.55f;
                }
                k.sc = 1.08f;
            } else {
                k.pos = relPos(L, p, rel, t, ntok);
                int key = cellKey(p, rel);
                if (rel >= LD_HOME) k.sc = 0.55f;
                if (key >= 0 && key < 64 && cellCount[key] > 1) {
                    int n = cellCount[key], i = cellSeen[key]++;
                    static const float ox2[2] = {-0.2f, 0.2f}, ox3[3] = {-0.3f, 0.f, 0.3f}, ox4[4] = {-0.22f, 0.22f, -0.22f, 0.22f}, oy4[4] = {0.18f, 0.18f, -0.14f, -0.14f};
                    if (n == 2) k.pos.x += ox2[i % 2] * cs, k.sc = 0.82f;
                    else if (n == 3) k.pos.x += ox3[i % 3] * cs, k.pos.y += (i % 3 == 1 ? 0.12f : -0.08f) * cs, k.sc = 0.74f;
                    else k.pos.x += ox4[i % 4] * cs, k.pos.y += oy4[i % 4] * cs, k.sc = 0.68f;
                }
            }
            if (k.show) k.lift += (4.f + 7.f * std::fabs(std::sin(lu_.time * 6.f + t))) * (cs / 73.f);
            tks.push_back(k);
        }
    }
    std::stable_sort(tks.begin(), tks.end(), [](const Tk &a, const Tk &b) { if (a.moving != b.moving) return !a.moving; return a.pos.y > b.pos.y; });
    for (const Tk &k : tks) {
        float r = cs * 0.36f * k.sc;
        if (k.show) {
            g.glow(k.pos.x, k.pos.y + r * 0.5f, r * 3.2f, Col(1, 1, 1, 0.30f + 0.15f * std::sin(lu_.time * 7.f)));
            g.ellipse(k.pos.x, k.pos.y, r * 1.5f, r * 0.7f, 0, seatCol(k.p).alpha(0.55f));
        }
        drawPawn(g, k.pos.x, k.pos.y - r * 0.55f, r, seatCol(k.p), k.lift, 1.f);
        if (k.show) {
            float ay = k.pos.y + r * 3.4f + k.lift + 6.f * std::sin(lu_.time * 8.f);
            float tri[8] = {k.pos.x - r * 0.5f, ay + r * 0.5f, k.pos.x + r * 0.5f, ay + r * 0.5f, k.pos.x, ay - r * 0.3f, k.pos.x, ay - r * 0.3f};
            g.poly(tri, Col(1, 1, 1, 0.95f));
            if (k.t == hintTok) drawStar(g, k.pos.x + r * 1.3f, ay + r * 0.1f, r * 0.6f, kGold);
        }
    }
    for (auto &f : lu_.flights) {                      // captured tokens fly back to their yard
        float u = clampf(f.tm / f.dur, 0.f, 1.f), e = 1.f - (1.f - u) * (1.f - u);
        float x = lerpf(f.fx, f.tx, e), y = lerpf(f.fy, f.ty, e) + std::sin(u * PI) * cs * 2.2f;
        float r = cs * 0.36f;
        g.ellipse(lerpf(f.fx, f.tx, e), lerpf(f.fy, f.ty, e) - r * 0.6f, r * 0.9f, r * 0.4f, 0, Col(0, 0, 0, 0.25f));
        drawPawn(g, x, y - r * 0.55f, r, seatCol(f.p), 0.f, 1.f);
    }
    // HARD: every token of the player on turn can be tapped (no hint which ones are legal); a wrong tap simply does nothing
    const bool anyTap = !help && humanTurn && G.phase() == LPhase::CHOOSE;
    for (const Tk &k : tks) if (k.sel || (anyTap && k.p == G.turn() && S.pos[k.p][k.t] < LD_HOME)) hits_.push_back({LD_TOK + k.t, k.pos.x, k.pos.y + cs * 0.3f, cs * 1.25f, cs * 1.6f});

    // ---- seat cards with the dice trays
    struct DieDraw { float sx, sy, rx, ry, sa, x, y, L; M3 R; float al, rest; };
    std::vector<DieDraw> dieDraws;
    for (int p = 0; p < 4; p++) {
        if (!S.active[p]) continue;
        const bool top = isTop(p), left = isLeft(p);
        const bool active = !over && G.turn() == p;
        const float ang = top ? PI : 0.f, ca = std::cos(ang), sa = std::sin(ang);
        const float cx = (left ? -1.f : 1.f) * (L.cardW / 2.f + 6.f), cy = top ? L.topY : L.botY;
        auto P = [&](float lx, float ly) { return V2{cx + lx * ca - ly * sa, cy + lx * sa + ly * ca}; };
        const float ph = L.ph, W = L.cardW;
        Col sc = seatCol(p);
        if (active) {
            float pulse = 0.55f + 0.25f * std::sin(lu_.time * 5.f);
            g.glow(cx, cy, W * 0.62f, sc.alpha(0.20f * pulse));
            g.rrect(cx, cy, W + 14.f, ph + 14.f, sc.alpha(0.55f + 0.3f * pulse), seatDeep(p).alpha(0.55f + 0.3f * pulse), 0.17f);
        } else g.rrect(cx, cy, W + 8.f, ph + 8.f, sc.alpha(0.35f), seatDeep(p).alpha(0.35f), 0.17f);
        g.rrect(cx, cy, W, ph, kCardTop, kCardBot, 0.15f);
        const float T = std::min(ph - 40.f, 250.f), tl = (left ? -1.f : 1.f) * (top ? -1.f : 1.f);
        const float trayX = tl * (W / 2.f - T / 2.f - 20.f), zoneW = W - T - 54.f, zoneX = -tl * (W / 2.f - zoneW / 2.f - 16.f);
        V2 tc = P(trayX, 0.f);
        g.rrect(tc.x, tc.y, T + 16.f, T + 16.f, Col::hex(0x7A4A24), Col::hex(0x4E2E14), 0.16f);
        g.rrect(tc.x, tc.y, T, T, active ? Col::hex(0x1F7A58) : Col::hex(0x17604A), active ? Col::hex(0x135640) : Col::hex(0x0E3F31), 0.12f);
        g.rrect(tc.x, tc.y + (top ? -1.f : 1.f) * T * 0.46f, T - 24.f, 6.f, Col(1, 1, 1, 0.10f), Col(1, 1, 1, 0.02f), 1.f);
        // die (two of them with TWO DICE): leaves its tray, tumbles and bounces across the board, shows the number, then flies back
        for (int di = 0; di < (S.rules.twoDice ? 2 : 1); di++) {
            auto sm = [](float u) { u = clampf(u, 0.f, 1.f); return u * u * (3.f - 2.f * u); };
            const float dsc = S.rules.twoDice ? 0.78f : 1.f, Ld = T * 0.20f * dsc, big = L.cs * 1.02f * dsc;
            const bool rolling = active && G.phase() == LPhase::ROLLING;
            const float since = lu_.time - lu_.dieDoneT[p];
            const float hold = active ? 1.05f : 0.25f, back = 0.40f;
            const V2 trayP = P(trayX, 0.f), land = dieLanding(L, p);
            float away = 0.f, tn = 1.f;
            if (rolling) { tn = G.rollProgress(); away = 1.f; }
            else if (since >= 0.f && since < hold + back) away = since < hold ? 1.f : 1.f - sm((since - hold) / back);
            M3 R; V2 pos = trayP; float lift = 0.f, Ldr = Ld, al = active || G.phase() == LPhase::OVER || away > 0.f ? 1.f : 0.62f;
            if (rolling) {
                const float h = Ludo::dieHeight(tn), u = clampf(tn / 0.42f, 0.f, 1.f), fl = 1.f - std::pow(1.f - u, 2.2f);
                R = tumbleOrient(di ? G.rollValue2() : G.rollValue(), di ? lu_.dieSeed2[p] : lu_.dieSeed[p], tn);
                pos = {lerpf(trayP.x, land.x, fl) + std::sin(tn * 11.f) * L.cs * 0.55f * (1.f - tn),
                       lerpf(trayP.y, land.y, fl) + std::sin(tn * 8.f + 1.f) * L.cs * 0.40f * (1.f - tn)};
                lift = h * L.cs * 1.9f + std::sin(u * PI) * L.cs * 2.4f;
                Ldr = lerpf(Ld, big, fl) * (1.f + 0.16f * h);
            } else if (away > 0.f) {
                R = restOrient(di ? lu_.dieVal2[p] : lu_.dieVal[p], di ? lu_.dieSeed2[p] : lu_.dieSeed[p]);
                if (since < hold) { pos = land; Ldr = big * (1.f + (active ? 0.04f * std::sin(lu_.time * 5.f) : 0.f)); }
                else {
                    const float u = (since - hold) / back, e = sm(u);
                    pos = {lerpf(land.x, trayP.x, e), lerpf(land.y, trayP.y, e)};
                    lift = std::sin(u * PI) * L.cs * 1.1f; Ldr = lerpf(big, Ld, e);
                }
            } else {
                R = restOrient(di ? lu_.dieVal2[p] : lu_.dieVal[p], di ? lu_.dieSeed2[p] : lu_.dieSeed[p]);
                if (active && G.phase() == LPhase::ROLL_WAIT && G.human(p)) Ldr = Ld * (1.f + 0.07f * std::sin(lu_.time * 4.5f));
            }
            if (S.rules.twoDice) pos.x += (di ? 1.f : -1.f) * Ldr * 1.12f;      // the two dice lie side by side
            const float upv = lerpf(top ? -1.f : 1.f, 1.f, away);
            const float k = 1.f + 1.4f * lift / L.cs;
            DieDraw d;
            d.sx = pos.x + lerpf(10.f, Ldr * 0.28f, away); d.sy = pos.y - upv * lerpf(12.f, 0.f, away) - Ldr * lerpf(0.2f, 0.62f, away);
            d.rx = Ldr * 1.35f * (1.f + 0.35f * lift / L.cs); d.ry = Ldr * lerpf(1.05f, 0.80f, away) * (1.f + 0.35f * lift / L.cs);
            d.sa = 0.32f * al / k; d.x = pos.x; d.y = pos.y + upv * lift; d.L = Ldr; d.R = R; d.al = al;
            d.rest = rolling ? sm((tn - 0.80f) / 0.20f) : 1.f;
            dieDraws.push_back(d);
        }
        // info zone
        V2 pc = P(zoneX, ph * 0.20f);
        drawPawn(g, pc.x, pc.y - ph * 0.07f, ph * 0.105f, sc, 0.f, 1.f);
        if (!S.done[p] && ldLocked(S, p)) { V2 lc = P(zoneX + ph * 0.19f, ph * 0.20f); drawLock(g, lc.x, lc.y, ph * 0.17f, 0.95f); }
        std::string nm = ludoName(p);
        V2 nc = P(zoneX, -ph * 0.07f);
        g.text(nm, nc.x, nc.y, std::min(38.f, ph * 0.12f), kText, Align::CENTER, ang);
        int home = 0; for (int t = 0; t < ntok; t++) if (S.pos[p][t] == LD_HOME) home++;
        V2 dc = P(zoneX, -ph * 0.26f);
        for (int t = 0; t < ntok; t++) {
            V2 q = P(zoneX + (t - (ntok - 1) * 0.5f) * 36.f, -ph * 0.27f);
            if (t < home) g.flat(q.x, q.y, 13.f, sc); else { g.flat(q.x, q.y, 13.f, sc.alpha(0.18f)); g.ring(q.x, q.y, 12.f, 3.f, sc.alpha(0.6f)); }
        }
        (void) dc;
        if (S.done[p] || G.place(p) > 0) {
            V2 bc = P(zoneX, ph * 0.40f - 4.f);
            g.text(placeName(G.place(p)), bc.x, bc.y, 44.f, kGold, Align::CENTER, ang);
        } else if (active) {
            const std::string msg = G.phase() == LPhase::ROLL_WAIT && G.human(p) ? "TAP TO ROLL" : G.phase() == LPhase::CHOOSE && G.human(p) && !G.autoPicking() ? std::string("PICK A TOKEN") + (S.rules.twoDice ? " - MOVE " + std::to_string(G.rollValue()) : std::string()) : G.human(p) ? "" : "THINKING";
            V2 mc = P(zoneX, -ph * 0.42f + 2.f);
            if (!msg.empty()) g.text(msg, mc.x, mc.y, 26.f, sc.mul(1.15f).alpha(0.75f + 0.25f * std::sin(lu_.time * 6.f)), Align::CENTER, ang);
        }
        if (active && G.phase() == LPhase::ROLL_WAIT && G.human(p) && !lu_.paused) hits_.push_back({LD_ROLL, cx, cy, W, ph});
    }

    for (const DieDraw &d : dieDraws) {   // dice last, so a rolling die is on top of the board and the cards
        g.ellipse(d.sx, d.sy, d.rx, d.ry, 0, Col(0, 0, 0, d.sa));
        drawDie(g, d.x, d.y, d.L, d.R, d.al, d.rest);
    }
    // ---- top bar
    {
        float yb = L.barY;
        button(g, LD_PAUSE, 0, yb, 160.f, 84.f, "II", kBtnTop, kBtnBot, 44.f);
        g.text("LUDO MASTER", -ww_ / 2 + 60.f, yb, 32.f, kDim, Align::LEFT);
        static const char *lv[4] = {"EASY", "MEDIUM", "HARD", "MASTER"};
        std::string rt = lu_.mode == 0 ? std::string("VS COMPUTER  ") + lv[std::max(0, std::min(3, G.skill()))] : std::string("FRIENDS");
        g.text(rt, ww_ / 2 - 60.f, yb, 28.f, kGold, Align::RIGHT);
    }
    // ---- particles + toast
    for (auto &q : parts_) {
        float k = q.life / q.max;
        if (q.spark) g.flat(q.p.x, q.p.y, q.size * k + 1.f, q.c.alpha(k)); else g.glow(q.p.x, q.p.y, q.size * 3.f * (0.5f + k), q.c.alpha(0.9f * k));
    }
    if (!toasts_.empty() && !lu_.paused) {
        const Toast &t = toasts_.front();
        float inA = clampf(t.t / 0.15f, 0.f, 1.f), outA = clampf((t.dur - t.t) / 0.3f, 0.f, 1.f), al = std::min(inA, outA);
        float sz = t.size * (1.f + 0.25f * std::max(0.f, 1.f - t.t / 0.2f));
        float tw = g.textWidth(t.text, sz) + 110.f;
        Col pill(0.02f, 0.04f, 0.09f, 0.80f * al);
        g.rrect(0, L.by, tw, sz * 1.7f, pill, pill, 1.f);
        g.text(t.text, 0, L.by - 4.f, sz, Col(0, 0, 0, 0.5f * al));
        g.text(t.text, 0, L.by, sz, t.col.alpha(al));
    }
    drawLudoOverlays(g);
}

void App::drawLudoOverlays(Gfx &g) {
    const Ludo &G = lu_.game;
    const LState &S = G.st();
    if (lu_.paused) {
        g.rect(0, 0, ww_ + 4, wh_ + 4, Col(0, 0, 0, 0.72f));
        g.rrect(0, 0, 900.f, 1000.f, kCardTop, kCardBot, 0.08f);
        g.text("PAUSED", 0, 380.f, 100.f, kText);
        button(g, LD_RESUME, 0, 190.f, 700.f, 130.f, "RESUME", kTeal, Col::hex(0x12997F), 52.f);
        button(g, LD_RESTART, 0, 30.f, 700.f, 130.f, "RESTART", kBtnTop, kBtnBot, 46.f);
        toggleTile(g, LD_S_SND, 0, -130.f, 700.f, 120.f, "SOUND", lu_.save.sound != 0);
        button(g, LD_MENU, 0, -290.f, 700.f, 130.f, "MAIN MENU", kBtnTop, kBtnBot, 46.f);
    }
    if (lu_.overT >= 0 && lu_.overT > 0.9f) {
        float al = clampf((lu_.overT - 0.9f) / 0.4f, 0.f, 1.f);
        g.rect(0, 0, ww_ + 4, wh_ + 4, Col(0, 0, 0, 0.74f * al));
        g.rrect(0, 60.f, 940.f, 1380.f, kCardTop.alpha(al), kCardBot.alpha(al), 0.07f);
        bool win = lu_.mode == 1 || G.rankOf(LC_RED) == 1;
        std::string title = lu_.mode == 1 ? "GAME OVER" : (win ? "YOU WIN!" : "GAME OVER");
        g.text(title, 0, 640.f, 100.f, (win ? kGold : kText).alpha(al));
        int n = G.players(), row = 0;
        for (int r = 1; r <= n; r++) {
            for (int p = 0; p < 4; p++) {
                if (!S.active[p] || G.rankOf(p) != r) continue;
                float y = 470.f - row * 135.f; row++;
                g.rrect(0, y, 820.f, 112.f, seatCol(p).alpha(0.20f * al), seatDeep(p).alpha(0.35f * al), 0.25f);
                g.text(placeName(r), -330.f, y, 50.f, (r == 1 ? kGold : kText).alpha(al));
                drawPawn(g, -190.f, y - 30.f, 30.f, seatCol(p).alpha(al), 0.f, al);
                g.text(ludoName(p) == "YOU" || lu_.mode == 1 ? std::string(colName(p)) + (ludoName(p) == "YOU" ? "  (YOU)" : "") : std::string(colName(p)) + "  (CPU)", -120.f, y + 12.f, 36.f, kText.alpha(al), Align::LEFT);
                g.text(std::to_string(G.captures(p)) + " CAPTURES", -120.f, y - 28.f, 26.f, kDim.alpha(al), Align::LEFT);
            }
        }
        if (lu_.mode == 0) {
            const LudoSave &s = lu_.save;
            int ri = rankIndex(s.xp);
            float y = 470.f - n * 135.f - 20.f;
            g.text("+" + std::to_string(lu_.xpGain) + " XP", 0, y, 60.f, kTeal.alpha(al));
            int from = kRanks[ri].from, to = ri < 5 ? kRanks[ri + 1].from : kRanks[ri].from + 1;
            float frac = ri < 5 ? clampf(float(s.xp - from) / float(to - from), 0.f, 1.f) : 1.f;
            g.text(kRanks[ri].name, 0, y - 70.f, 36.f, kGold.alpha(al));
            g.rrect(0, y - 125.f, 640.f, 26.f, kTrack.alpha(al), kTrack.alpha(al), 1.f);
            if (frac > 0.01f) g.rrect(-320.f + 320.f * frac, y - 125.f, 640.f * frac, 26.f, kTeal.alpha(al), Col::hex(0x12997F, al), 1.f);
        }
        button(g, LD_AGAIN, 0, -440.f, 760.f, 130.f, "PLAY AGAIN", kTeal, Col::hex(0x12997F), 52.f);
        button(g, LD_SETUP, -190.f, -590.f, 360.f, 110.f, "SETUP", kBtnTop, kBtnBot, 40.f);
        button(g, LD_MENU, 190.f, -590.f, 360.f, 110.f, "MENU", kBtnTop, kBtnBot, 40.f);
    }
}


// ------------------------------------------------------------------------------------ setup + how to play
void App::drawLudoSetup(Gfx &g) {
    const LudoSave &sv = lu_.save;
    const float top = wh_ / 2, sp = clampf(wh_ / 2500.f, 0.72f, 1.15f);
    const float pitch = std::max(160.f, 205.f * sp);
    // title with four pawns
    float yt = top - 210.f * sp;
    for (int i = 0; i < 4; i++) {
        float px = (i < 2 ? -1.f : 1.f) * (i % 2 == 0 ? 370.f : 480.f);
        drawPawn(g, px, yt - 50.f, 36.f, seatCol(i < 2 ? 1 - i : i), 6.f + 6.f * std::sin(time_ * 2.2f + i * 1.3f), 1.f);
    }
    g.text("LUDO", 0, yt - 6.f, 170.f * sp, Col(0, 0, 0, gDark ? 0.45f : 0.12f));
    g.text("LUDO", 0, yt, 170.f * sp, kText);
    g.text("M A S T E R", 0, yt - 120.f * sp, 70.f * sp, kGold);
    // rank card
    {
        float y = top - 520.f * sp;
        int ri = rankIndex(sv.xp);
        g.rrect(0, y, 1000.f, 170.f, kCardTop, kCardBot, 0.2f);
        g.text(kRanks[ri].name, -470.f, y + 38.f, 52.f, kGold, Align::LEFT);
        int from = kRanks[ri].from, to = ri < 5 ? kRanks[ri + 1].from : from + 1;
        float frac = ri < 5 ? clampf(float(sv.xp - from) / float(to - from), 0.f, 1.f) : 1.f;
        g.text(std::to_string(sv.xp) + (ri < 5 ? " / " + std::to_string(to) + " XP" : " XP"), -470.f, y - 14.f, 28.f, kDim, Align::LEFT);
        g.rrect(-195.f, y - 54.f, 560.f, 20.f, kTrack, kTrack, 1.f);
        if (frac > 0.02f) g.rrect(-475.f + 280.f * frac + 80.f - 80.f, y - 54.f, 560.f * frac, 20.f, kTeal, Col::hex(0x12997F), 1.f);
        g.text("WINS", 360.f, y + 40.f, 26.f, kDim);
        g.text(std::to_string(sv.wins) + " / " + std::to_string(sv.games), 360.f, y - 8.f, 52.f, kText);
        g.text("CAPTURES " + std::to_string(sv.captures), 360.f, y - 58.f, 24.f, kDim);
    }
    float y0 = top - 700.f * sp;
    g.text("PLAYERS", 0, y0, 30.f, kDim);
    segment(g, LD_P2, y0 - 78.f, {"2", "3", "4"}, lu_.players - 2, 1000.f);
    float y1 = y0 - pitch;
    g.text("OPPONENTS", 0, y1, 30.f, kDim);
    segment(g, LD_VS_CPU, y1 - 78.f, {"VS COMPUTER", "FRIENDS"}, lu_.mode, 1000.f);
    float y2 = y1 - pitch;
    if (lu_.mode == 0) {
        g.text("COMPUTER LEVEL", 0, y2, 30.f, kDim);
        segment(g, LD_D0, y2 - 78.f, {"EASY", "MEDIUM", "HARD", "MASTER"}, lu_.diff, 1000.f);
    } else {
        g.text("FRIENDS SIT AROUND THE PHONE", 0, y2, 30.f, kDim);
        g.rrect(0, y2 - 78.f, 1000.f, 118.f, kCardTop, kCardBot, 0.3f);
        g.text("EVERY PLAYER ROLLS ON THEIR OWN SIDE", 0, y2 - 78.f, 32.f, kText);
    }
    float y3 = y2 - pitch;
    g.text("RULES", 0, y3, 30.f, kDim);
    // 6 rows of rule tiles + START must fit above the bottom buttons: squeeze the rows on short screens
    const float rpMax = ((y3 - 80.f - 85.f - 70.f) - (-wh_ / 2 + 170.f)) / 5.5f;
    const float rp = clampf(std::min(clampf(wh_ / 2667.f * 134.f, 124.f, 134.f), rpMax), 92.f, 134.f), tw = 485.f, th = rp - 12.f, gx = 257.5f;
    toggleTile(g, LD_T_SIX, -gx, y3 - 80.f, tw, th, "SIX TO START", lu_.rules.sixToStart && !lu_.rules.sixReroll);
    toggleTile(g, LD_T_CAP, gx, y3 - 80.f, tw, th, "BONUS ROLL", lu_.rules.captureBonus);
    toggleTile(g, LD_T_3S, -gx, y3 - 80.f - rp, tw, th, "3 SIXES = LOSE", lu_.rules.threeSixes);
    toggleTile(g, LD_T_BLK, gx, y3 - 80.f - rp, tw, th, "SAFE BLOCKS", lu_.rules.blocksSafe);
    toggleTile(g, LD_T_RANK, -gx, y3 - 80.f - 2 * rp, tw, th, "ALL RANKS", lu_.rules.fullRanks);
    toggleTile(g, LD_T_QUICK, gx, y3 - 80.f - 2 * rp, tw, th, lu_.rules.tokens == 1 ? "1 TOKEN" : lu_.rules.tokens == 2 ? "2 TOKENS" : "4 TOKENS", lu_.rules.tokens != 4);
    toggleTile(g, LD_T_HARD, -gx, y3 - 80.f - 3 * rp, tw, th, "HARD GAME", lu_.rules.hardMode);
    toggleTile(g, LD_T_LOCK, gx, y3 - 80.f - 3 * rp, tw, th, "HOME LOCK", lu_.rules.captureLock);
    toggleTile(g, LD_T_TRAP, -gx, y3 - 80.f - 4 * rp, tw, th, "KILL TRAP", lu_.rules.capturePenalty);
    toggleTile(g, LD_T_REROLL, gx, y3 - 80.f - 4 * rp, tw, th, "SIX = REROLL", lu_.rules.sixReroll);
    toggleTile(g, LD_T_TWO, -gx, y3 - 80.f - 5 * rp, tw, th, "TWO DICE", lu_.rules.twoDice);
    float yBot = -wh_ / 2 + 100.f;
    float yStart = y3 - 80.f - 5 * rp - rp / 2 - 85.f;
    button(g, LD_START, 0, yStart, 1000.f, 140.f, "START GAME", Col::hex(0xEF4444), Col::hex(0xB3263F), 58.f);
    button(g, LD_HOW, -257.5f, yBot, 485.f, 100.f, "HOW TO PLAY", kBtnTop, kBtnBot, 36.f);
    button(g, LD_BACK, 257.5f, yBot, 485.f, 100.f, "BACK", kBtnTop, kBtnBot, 38.f);
}

void App::drawLudoHowTo(Gfx &g) {
    const float top = wh_ / 2;
    g.text("LUDO RULES", 0, top - 230.f, 100.f, kText);
    static const char *lines[][2] = {
        {"GOAL", "Bring all your tokens around the board to the centre."},
        {"START", "SIX = REROLL: a 6 moves nothing, you just roll again. Tokens come out on any other number."},
        {"MOVE", "Move one token by the number on the dice, clockwise."},
        {"CAPTURE", "Land on an opponent to send it back to its yard. KILL TRAP: moving that token again undoes it."},
        {"SAFE", "Stars and start squares are safe. Two of your tokens on one square make a safe block."},
        {"HOME", "You need the exact number to reach the centre. Reaching home gives another roll."},
        {"THREE 6", "Three sixes in a row: nothing happens and the turn goes to the next player."},
        {"HARD GAME", "HOME LOCK: capture an opponent first, a padlock blocks your home until then. No hints."},
        {"TWO DICE", "Two dice every turn. Play the first number on one token, then the second on any token."}};
    float y = top - 372.f;
    for (auto &l : lines) {
        g.rrect(0, y, 1040.f, 166.f, kCardTop, kCardBot, 0.14f);
        g.text(l[0], -480.f, y + 50.f, 36.f, kGold, Align::LEFT);
        // wrap the sentence over two lines at a space near the middle
        std::string s = l[1];
        if (std::string(l[0]) == "START" && !lu_.rules.sixReroll) s = "Roll a 6 to bring a token out. A 6 always frees a waiting token first, then you roll again.";
        std::string a = s, b;
        if (s.size() > 46) { size_t cut = s.rfind(' ', 46); if (cut == std::string::npos) cut = 46; a = s.substr(0, cut); b = s.substr(cut + 1); }
        g.text(a, -480.f, y - (b.empty() ? 20.f : 6.f), 31.f, kText, Align::LEFT);
        if (!b.empty()) g.text(b, -480.f, y - 48.f, 31.f, kText, Align::LEFT);
        y -= 184.f;
    }
    button(g, LD_BACK, 0, -wh_ / 2 + 120.f, 800.f, 110.f, "BACK", kTeal, Col::hex(0x12997F), 44.f);
}

// ------------------------------------------------------------------------------------ menu, settings, stats
void App::drawMenu(Gfx &g) {
    const LudoSave &sv = lu_.save;
    const float top = wh_ / 2;
    // ---- top bar: rank chip + theme switch
    float ty = top - 100.f;
    int ri = rankIndex(sv.xp);
    g.rrect(-235.f, ty, 640.f, 90.f, kCardTop, kCardBot, 1.f);
    g.text(kRanks[ri].name, -520.f, ty + 2.f, 36.f, kGold, Align::LEFT);
    g.text(std::to_string(sv.xp) + " XP", 70.f, ty + 2.f, 32.f, kDim, Align::RIGHT);
    bool dn = pressed_ == LD_M_THEME;
    g.flat(480.f, ty - (dn ? 4.f : 0.f), 52.f, kBtnTop);
    g.ring(480.f, ty - (dn ? 4.f : 0.f), 52.f, 3.f, kDim.alpha(0.5f));
    if (gDark) { g.flat(480.f, ty, 22.f, kText); g.flat(493.f, ty + 8.f, 19.f, kBtnTop); }
    else {
        g.flat(480.f, ty, 17.f, kGold);
        for (int i = 0; i < 8; i++) { float a = i * 0.7853982f; g.line(480.f + std::cos(a) * 26.f, ty + std::sin(a) * 26.f, 480.f + std::cos(a) * 36.f, ty + std::sin(a) * 36.f, 5.f, kGold); }
    }
    hits_.push_back({LD_M_THEME, 480.f, ty, 120.f, 120.f});

    // ---- buttons (bottom up)
    float extra = clampf((wh_ - 2200.f) * 0.25f, 0.f, 220.f);
    float y5 = -wh_ / 2 + 150.f + extra, y4 = y5 + 150.f, y3 = y4 + 150.f, yPlay = y3 + 175.f, yCont = yPlay + 165.f;
    const float tw = 485.f, th = 130.f, gx = 257.5f;
    tile(g, LD_M_SET, -gx, y5, tw, th, "SETTINGS", "SOUND, BOARD, HINTS", kBtnTop, kBtnBot);
    tile(g, LD_M_EXIT, gx, y5, tw, th, "EXIT", "", Col::hex(0x475569), Col::hex(0x334155));
    tile(g, LD_M_STATS, -gx, y4, tw, th, "STATS", std::to_string(sv.wins) + " WINS", Col::hex(0x14A89A), Col::hex(0x0E7F74));
    tile(g, LD_M_HOW, gx, y4, tw, th, "HOW TO PLAY", "", kBtnTop, kBtnBot);
    tile(g, LD_M_QUICK, -gx, y3, tw, th, "QUICK MATCH", "VS COMPUTER", kGold, Col::hex(0xD98E1B));
    tile(g, LD_M_FRIENDS, gx, y3, tw, th, "FRIENDS", "2-4 AROUND THE PHONE", Col::hex(0x8B5CF6), Col::hex(0x6D3FD8));
    button(g, LD_M_PLAY, 0, yPlay, 1000.f, 150.f, "PLAY LUDO", Col::hex(0xEF4444), Col::hex(0xB3263F), 58.f);
    if (lu_.hasSnap) button(g, LD_M_CONT, 0, yCont, 1000.f, 130.f, "CONTINUE GAME", kTeal, Col::hex(0x12997F), 50.f);

    // ---- title and the spinning dice emblem
    float yTop = (lu_.hasSnap ? yCont + 65.f : yPlay + 75.f) + 45.f;
    float pop = 1.f + 0.06f * std::max(0.f, 1.f - screenT_ * 3.f);
    g.text("M A S T E R", 0, yTop + 20.f, 62.f, kGold);
    float yTitle = yTop + 135.f;
    g.text("LUDO", 0, yTitle - 6.f, 190.f * pop, Col(0, 0, 0, gDark ? 0.45f : 0.12f));
    g.text("LUDO", 0, yTitle, 190.f * pop, kText);
    float freeTop = top - 170.f, freeBot = yTitle + 105.f;
    float L = clampf((freeTop - freeBot) * 0.17f, 62.f, 120.f);
    float yEmb = clampf(freeBot + (freeTop - freeBot) * 0.5f, freeBot + L * 1.8f, freeTop - L * 1.8f);
    g.glow(0, yEmb, L * 3.6f, kGold.alpha(gDark ? 0.20f : 0.26f));
    float bob = std::sin(time_ * 1.8f) * 10.f;
    g.ellipse(18.f, yEmb - L * 1.55f - bob * 0.3f, L * 1.3f, L * 0.42f, 0, Col(0, 0, 0, 0.30f));
    M3 R = mul(axisAngle({0.35f, 1.f, 0.2f}, time_ * 0.8f), restOrient(5, 3));
    drawDie(g, 0, yEmb + bob, L, R, 1.f);
    for (int i = 0; i < 4; i++) {
        float side = i < 2 ? -1.f : 1.f, far = (i % 2 == 0) ? 0.f : 1.f;
        int col = i == 0 ? LC_RED : i == 1 ? LC_GREEN : i == 2 ? LC_YELLOW : LC_BLUE;
        drawPawn(g, side * (L * 1.95f + 85.f + far * 125.f), yEmb - L * 0.9f - far * 25.f, 38.f, seatCol(col), 8.f + 10.f * std::fabs(std::sin(time_ * 2.f + i * 1.4f)), 1.f);
    }
}

void App::drawSettings(Gfx &g) {
    const LudoSave &sv = lu_.save;
    const float top = wh_ / 2;
    g.text("SETTINGS", 0, top - 200.f, 100.f, kText);
    float y = top - 370.f;
    toggleTile(g, LD_S_SND, 0, y, 1000.f, 104.f, "SOUND", sv.sound != 0); y -= 118.f;
    toggleTile(g, LD_S_HAP, 0, y, 1000.f, 104.f, "VIBRATION", sv.haptics != 0); y -= 118.f;
    toggleTile(g, LD_S_DARK, 0, y, 1000.f, 104.f, "DARK MODE", sv.dark != 0); y -= 118.f;
    toggleTile(g, LD_S_HINT, 0, y, 1000.f, 104.f, "SHOW BEST MOVE", sv.hints != 0); y -= 118.f;
    toggleTile(g, LD_S_AUTO, 0, y, 1000.f, 104.f, "AUTO MOVE (ONE CHOICE)", sv.autoMove != 0); y -= 112.f;
    g.text("BOARD DESIGN", 0, y, 30.f, kDim);
    segment(g, LD_S_BOARD, y - 78.f, {"CLASSIC", "MIDNIGHT", "MARBLE", "WOODEN"}, int(sv.boardTheme()), 1000.f);
    y -= 200.f;
    g.text("DICE DESIGN", 0, y, 30.f, kDim);
    segment(g, LD_S_DICE, y - 78.f, {"WHITE", "RED"}, int(sv.diceStyle()), 1000.f);
    y -= 240.f;
    button(g, LD_S_NAMES, 0, y, 1000.f, 110.f, "FRIEND NAMES", kBtnTop, kBtnBot, 42.f);
    button(g, LD_BACK, 0, -wh_ / 2 + 110.f, 800.f, 110.f, "BACK", kTeal, Col::hex(0x12997F), 44.f);
}

void App::drawStats(Gfx &g) {
    const LudoSave &sv = lu_.save;
    const float top = wh_ / 2;
    g.text("STATS", 0, top - 230.f, 100.f, kText);
    {   // rank card
        float y = top - 430.f;
        int ri = rankIndex(sv.xp);
        g.rrect(0, y, 1000.f, 200.f, kCardTop, kCardBot, 0.2f);
        g.text(kRanks[ri].name, -470.f, y + 45.f, 62.f, kGold, Align::LEFT);
        int from = kRanks[ri].from, to = ri < 5 ? kRanks[ri + 1].from : from + 1;
        float frac = ri < 5 ? clampf(float(sv.xp - from) / float(to - from), 0.f, 1.f) : 1.f;
        g.rrect(0, y - 30.f, 900.f, 22.f, kTrack, kTrack, 1.f);
        if (frac > 0.02f) g.rrect(-450.f + 450.f * frac, y - 30.f, 900.f * frac, 22.f, kTeal, Col::hex(0x12997F), 1.f);
        g.text(ri < 5 ? std::to_string(sv.xp) + " / " + std::to_string(to) + " XP  -  NEXT: " + kRanks[ri + 1].name : std::to_string(sv.xp) + " XP  -  TOP RANK", -450.f, y - 70.f, 26.f, kDim, Align::LEFT);
    }
    int rate = sv.games ? int(100.f * sv.wins / sv.games + 0.5f) : 0;
    struct Cell { std::string v, l; };
    Cell cells[6] = {{std::to_string(sv.games), "GAMES"}, {std::to_string(sv.wins), "WINS"}, {std::to_string(rate) + "%", "WIN RATE"},
                     {std::to_string(sv.captures), "CAPTURES"}, {std::to_string(sv.best), "BEST STREAK"}, {std::to_string(sv.friends), "FRIENDS GAMES"}};
    float y0 = top - 640.f;
    for (int i = 0; i < 6; i++) {
        float x = (i % 2 ? 1.f : -1.f) * 257.5f, y = y0 - (i / 2) * 175.f;
        g.rrect(x, y, 485.f, 150.f, kCardTop, kCardBot, 0.25f);
        g.text(cells[i].v, x, y + 22.f, 66.f, i == 2 ? kTeal : kText);
        g.text(cells[i].l, x, y - 42.f, 26.f, kDim);
    }
    float yl = y0 - 3 * 175.f - 20.f;
    g.text("WINS BY LEVEL", 0, yl, 30.f, kDim);
    static const char *nm[4] = {"EASY", "MEDIUM", "HARD", "MASTER"};
    for (int d = 0; d < 4; d++) {
        float y = yl - 62.f - d * 68.f;
        float fr = sv.gamesBy[d] ? float(sv.winsBy[d]) / float(sv.gamesBy[d]) : 0.f;
        g.text(nm[d], -480.f, y, 32.f, kText, Align::LEFT);
        g.rrect(40.f, y, 560.f, 26.f, kTrack, kTrack, 1.f);
        if (fr > 0.02f) g.rrect(40.f - 280.f + 280.f * fr, y, 560.f * fr, 26.f, kTeal, Col::hex(0x12997F), 1.f);
        g.text(std::to_string(sv.winsBy[d]) + " / " + std::to_string(sv.gamesBy[d]), 480.f, y, 30.f, kDim, Align::RIGHT);
    }
    button(g, LD_BACK, 0, -wh_ / 2 + 100.f, 800.f, 100.f, "BACK", kTeal, Col::hex(0x12997F), 44.f);
}
