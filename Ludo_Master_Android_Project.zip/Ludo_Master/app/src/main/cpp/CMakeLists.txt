cmake_minimum_required(VERSION 3.22.1)

project("myapplication")

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Game library. The name must match System.loadLibrary() in MainActivity.kt and the
# android.app.lib_name entry in AndroidManifest.xml.
add_library(myapplication SHARED
        main.cpp
        AndroidOut.cpp
        Renderer.cpp
        Platform.cpp
        Jni.cpp
        Gfx.cpp
        App.cpp
        Ludo.cpp
        Audio.cpp)

find_package(game-activity REQUIRED CONFIG)

# Keeps the JNI entry point for GameActivity and supports 16 KB memory pages (Google Play requirement)
set(CMAKE_SHARED_LINKER_FLAGS
        "${CMAKE_SHARED_LINKER_FLAGS} -u Java_com_google_androidgamesdk_GameActivity_initializeNativeCode -Wl,-z,max-page-size=16384")

target_compile_options(myapplication PRIVATE -O2)

target_link_libraries(myapplication
        game-activity::game-activity_static
        EGL
        GLESv3
        jnigraphics
        aaudio
        android
        log)
