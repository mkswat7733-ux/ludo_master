#include "Renderer.h"

#include <GLES3/gl3.h>
#include <algorithm>
#include <game-activity/native_app_glue/android_native_app_glue.h>

#include "AndroidOut.h"
#include "App.h"
#include "Gfx.h"

Renderer::Renderer(android_app *app, App *game) : app_(app), game_(game) {
    ok_ = initEgl();
    if (!ok_) return;
    gfx_ = std::make_unique<Gfx>();
    if (!gfx_->init()) { aout << "Gfx init failed" << std::endl; ok_ = false; }
}

Renderer::~Renderer() {
    if (gfx_) { gfx_->shutdown(); gfx_.reset(); }
    if (display_ != EGL_NO_DISPLAY) {
        eglMakeCurrent(display_, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (context_ != EGL_NO_CONTEXT) eglDestroyContext(display_, context_);
        if (surface_ != EGL_NO_SURFACE) eglDestroySurface(display_, surface_);
        eglTerminate(display_);
    }
}

bool Renderer::initEgl() {
    const EGLint attribs[] = {EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
                              EGL_BLUE_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_RED_SIZE, 8, EGL_ALPHA_SIZE, 0,
                              EGL_DEPTH_SIZE, 0, EGL_NONE};
    display_ = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display_ == EGL_NO_DISPLAY || !eglInitialize(display_, nullptr, nullptr)) return false;
    EGLConfig config = nullptr;
    EGLint num = 0;
    if (!eglChooseConfig(display_, attribs, &config, 1, &num) || num < 1) return false;
    surface_ = eglCreateWindowSurface(display_, config, app_->window, nullptr);
    const EGLint ctxAttribs[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    context_ = eglCreateContext(display_, config, nullptr, ctxAttribs);
    if (surface_ == EGL_NO_SURFACE || context_ == EGL_NO_CONTEXT) return false;
    if (!eglMakeCurrent(display_, surface_, surface_, context_)) return false;
    eglSwapInterval(display_, 1);
    aout << "GL renderer: " << glGetString(GL_RENDERER) << std::endl;
    return true;
}

void Renderer::updateArea() {
    EGLint w = 0, h = 0;
    eglQuerySurface(display_, surface_, EGL_WIDTH, &w);
    eglQuerySurface(display_, surface_, EGL_HEIGHT, &h);
    if (w <= 0 || h <= 0) return;
    width_ = w; height_ = h;
    float aspect = float(w) / float(h);
    worldH_ = std::max(1200.f / aspect, 1640.f);
    worldW_ = worldH_ * aspect;
}

void Renderer::frame(float dt) {
    if (!ok_) return;
    updateArea();
    game_->resize(worldW_, worldH_);
    game_->update(dt);
    gfx_->begin(width_, height_, worldW_, worldH_);
    glClearColor(0.02f, 0.04f, 0.09f, 1.f);
    glClear(GL_COLOR_BUFFER_BIT);
    game_->draw(*gfx_);
    gfx_->end();
    if (!eglSwapBuffers(display_, surface_)) {
        EGLint err = eglGetError();
        aout << "eglSwapBuffers failed: " << err << std::endl;
        if (err == EGL_CONTEXT_LOST || err == EGL_BAD_CONTEXT || err == EGL_BAD_SURFACE) ok_ = false;
    }
}

void Renderer::handleInput() {
    auto *buf = android_app_swap_input_buffers(app_);
    if (!buf) return;
    auto toWorld = [&](float px, float py, float &wx, float &wy) {
        wx = (px / float(std::max(1, width_)) - 0.5f) * worldW_;
        wy = (0.5f - py / float(std::max(1, height_))) * worldH_;
    };
    for (uint64_t i = 0; i < buf->motionEventsCount; i++) {
        auto &m = buf->motionEvents[i];
        int action = m.action & AMOTION_EVENT_ACTION_MASK;
        int idx = (m.action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
        float wx, wy;
        switch (action) {
            case AMOTION_EVENT_ACTION_DOWN:
            case AMOTION_EVENT_ACTION_POINTER_DOWN: {
                auto &p = m.pointers[idx];
                toWorld(GameActivityPointerAxes_getX(&p), GameActivityPointerAxes_getY(&p), wx, wy);
                game_->touch(0, p.id, wx, wy);
                break;
            }
            case AMOTION_EVENT_ACTION_MOVE:
                for (uint32_t k = 0; k < m.pointerCount; k++) {
                    auto &p = m.pointers[k];
                    toWorld(GameActivityPointerAxes_getX(&p), GameActivityPointerAxes_getY(&p), wx, wy);
                    game_->touch(1, p.id, wx, wy);
                }
                break;
            case AMOTION_EVENT_ACTION_UP:
            case AMOTION_EVENT_ACTION_POINTER_UP: {
                auto &p = m.pointers[idx];
                toWorld(GameActivityPointerAxes_getX(&p), GameActivityPointerAxes_getY(&p), wx, wy);
                game_->touch(2, p.id, wx, wy);
                break;
            }
            case AMOTION_EVENT_ACTION_CANCEL:
                for (uint32_t k = 0; k < m.pointerCount; k++) game_->touch(3, m.pointers[k].id, 0, 0);
                break;
            default: break;
        }
    }
    android_app_clear_motion_events(buf);
    for (uint64_t i = 0; i < buf->keyEventsCount; i++) {
        auto &k = buf->keyEvents[i];
        if (k.keyCode == AKEYCODE_BACK && k.action == AKEY_EVENT_ACTION_UP) game_->onBack();
    }
    android_app_clear_key_events(buf);
}
