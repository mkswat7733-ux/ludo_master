#include "Audio.h"
#include <algorithm>
#include <cmath>
#ifdef __ANDROID__
#include <aaudio/AAudio.h>
#endif

uint32_t Audio::rnd() { seed_ = seed_ * 1664525u + 1013904223u; return seed_ >> 8; }

void Audio::play(Snd s, float vol, float pitch) {
    if (!enabled_) return;
    uint32_t h = qHead_.load(std::memory_order_relaxed);
    uint32_t t = qTail_.load(std::memory_order_acquire);
    if (h - t >= QN) return;   // queue full: drop
    q_[h % QN] = {s, vol, pitch};
    qHead_.store(h + 1, std::memory_order_release);
}

void Audio::spawn(const Voice &v) {
    for (auto &x : voices_) if (!x.on) { x = v; x.on = true; return; }
    // steal the quietest/oldest voice
    Voice *o = &voices_[0];
    for (auto &x : voices_) if (x.t > o->t) o = &x;
    *o = v; o->on = true;
}

void Audio::trigger(const Trig &t) {
    auto V = [&](float amp, float f0, float f1, float decay, float noise, float dur, float delay = 0, int wave = 0) {
        Voice v; v.amp = amp * t.vol; v.f0 = f0 * t.pitch; v.f1 = f1 * t.pitch; v.decay = decay; v.noise = noise; v.dur = dur; v.delay = delay; v.wave = wave;
        spawn(v);
    };
    switch (t.s) {
        case Snd::CLACK:  V(0.55f, 2300, 2100, 0.050f, 0.55f, 0.25f); V(0.38f, 740, 700, 0.085f, 0.08f, 0.35f); break;
        case Snd::STRIKE: V(0.85f, 1000, 800, 0.075f, 0.5f, 0.3f); V(0.55f, 320, 260, 0.14f, 0.1f, 0.5f); break;
        case Snd::WALL:   V(0.50f, 270, 230, 0.09f, 0.25f, 0.4f); V(0.20f, 1100, 900, 0.03f, 0.7f, 0.15f); break;
        case Snd::POCKET: V(0.60f, 950, 180, 0.17f, 0.f, 0.5f); V(0.30f, 2000, 400, 0.05f, 0.6f, 0.2f, 0.f); V(0.28f, 160, 120, 0.12f, 0.1f, 0.4f, 0.22f); break;
        case Snd::CLICK:  V(0.35f, 1500, 1300, 0.022f, 0.15f, 0.12f); break;
        case Snd::TURN:   V(0.18f, 620, 600, 0.04f, 0.f, 0.2f); break;
        case Snd::FOUL:   V(0.40f, 150, 110, 0.30f, 0.05f, 0.8f, 0, 1); V(0.30f, 158, 118, 0.30f, 0.05f, 0.8f, 0.0f, 1); break;
        case Snd::QUEEN:  V(0.40f, 880, 880, 0.35f, 0, 0.9f); V(0.36f, 1320, 1320, 0.40f, 0, 1.0f, 0.09f); V(0.3f, 1760, 1760, 0.5f, 0, 1.2f, 0.18f); break;
        case Snd::WIN: {
            const float n[5] = {523.25f, 659.25f, 783.99f, 1046.5f, 1318.5f};
            for (int i = 0; i < 5; i++) V(0.38f, n[i], n[i], 0.45f, 0, 1.4f, 0.11f * i);
            break;
        }
        case Snd::LOSE: {
            const float n[3] = {392.f, 329.6f, 261.6f};
            for (int i = 0; i < 3; i++) V(0.36f, n[i], n[i] * 0.99f, 0.4f, 0, 1.2f, 0.2f * i, 1);
            break;
        }
    }
}

void Audio::render(float *out, int frames) {
    // drain trigger queue
    uint32_t t = qTail_.load(std::memory_order_relaxed), h = qHead_.load(std::memory_order_acquire);
    while (t != h) { trigger(q_[t % QN]); t++; }
    qTail_.store(t, std::memory_order_release);
    const float dt = 1.f / sr_;
    const float TWO_PI = 6.2831853f;
    for (int i = 0; i < frames; i++) {
        float mix = 0;
        for (auto &v : voices_) {
            if (!v.on) continue;
            if (v.delay > 0) { v.delay -= dt; continue; }
            float env = std::exp(-v.t / v.decay);
            float att = std::min(1.f, v.t / 0.0012f);
            float k = std::min(1.f, v.t / v.dur);
            float f = v.f0 + (v.f1 - v.f0) * k;
            v.ph += f * dt; v.ph -= std::floor(v.ph);
            float s = std::sin(v.ph * TWO_PI);
            if (v.wave == 1) s = std::max(-0.6f, std::min(0.6f, s * 2.2f)) + 0.25f * std::sin(v.ph * TWO_PI * 3);
            float n = (int(rnd() & 0xFFFF) / 32768.f) - 1.f;
            mix += v.amp * env * att * (s * (1.f - v.noise) + n * v.noise);
            v.t += dt;
            if (env < 0.0015f || v.t > v.dur * 3.f) v.on = false;
        }
        out[i] = std::tanh(mix * 0.7f) * 0.8f;
    }
}

#ifdef __ANDROID__
struct AudioCb {
    static aaudio_data_callback_result_t data(AAudioStream *, void *user, void *buf, int32_t frames) {
        static_cast<Audio *>(user)->render(static_cast<float *>(buf), frames);
        return AAUDIO_CALLBACK_RESULT_CONTINUE;
    }
    static void error(AAudioStream *, void *user, aaudio_result_t) { static_cast<Audio *>(user)->restart_ = true; }
};

bool Audio::start() {
    if (stream_) return true;
    AAudioStreamBuilder *b = nullptr;
    if (AAudio_createStreamBuilder(&b) != AAUDIO_OK) return false;
    AAudioStreamBuilder_setDirection(b, AAUDIO_DIRECTION_OUTPUT);
    AAudioStreamBuilder_setPerformanceMode(b, AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);
    AAudioStreamBuilder_setSharingMode(b, AAUDIO_SHARING_MODE_SHARED);
    AAudioStreamBuilder_setFormat(b, AAUDIO_FORMAT_PCM_FLOAT);
    AAudioStreamBuilder_setChannelCount(b, 1);
    AAudioStreamBuilder_setDataCallback(b, AudioCb::data, this);
    AAudioStreamBuilder_setErrorCallback(b, AudioCb::error, this);
    AAudioStream *s = nullptr;
    aaudio_result_t r = AAudioStreamBuilder_openStream(b, &s);
    AAudioStreamBuilder_delete(b);
    if (r != AAUDIO_OK || !s) return false;
    sr_ = AAudioStream_getSampleRate(s);
    if (sr_ <= 0) sr_ = 48000;
    AAudioStream_setBufferSizeInFrames(s, AAudioStream_getFramesPerBurst(s) * 2);
    if (AAudioStream_requestStart(s) != AAUDIO_OK) { AAudioStream_close(s); return false; }
    stream_ = s;
    restart_ = false;
    return true;
}

void Audio::stop() {
    if (!stream_) return;
    auto *s = static_cast<AAudioStream *>(stream_);
    stream_ = nullptr;
    AAudioStream_requestStop(s);
    AAudioStream_close(s);
}
#else
bool Audio::start() { return true; }
void Audio::stop() {}
#endif
