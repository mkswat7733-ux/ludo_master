#pragma once
// Persistent data and run-time state of the Ludo game (the screens are App methods in App.cpp).
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include "Ludo.h"

enum LudoId {
    LD_P2 = 200, LD_P3, LD_P4, LD_VS_CPU = 205, LD_FRIENDS, LD_D0 = 210,
    LD_T_SIX = 220, LD_T_CAP, LD_T_3S, LD_T_BLK, LD_T_RANK, LD_T_QUICK, LD_T_LOCK, LD_T_HARD,
    LD_START = 230, LD_HOW, LD_BACK, LD_ROLL = 240, LD_PAUSE, LD_RESUME, LD_RESTART, LD_MENU, LD_AGAIN, LD_SETUP,
    LD_TOK = 250,
    LD_M_CONT = 260, LD_M_PLAY, LD_M_QUICK, LD_M_FRIENDS, LD_M_STATS, LD_M_HOW, LD_M_SET, LD_M_EXIT, LD_M_THEME,
    LD_S_SND = 280, LD_S_HAP, LD_S_DARK, LD_S_HINT, LD_S_AUTO, LD_S_NAMES, LD_S_BOARD = 290, LD_S_DICE = 300
};

struct LudoSave {
    uint32_t magic = 0x4C554434;
    uint32_t games = 0, wins = 0, captures = 0, streak = 0, best = 0, friends = 0;
    int32_t xp = 0;
    uint32_t players = 4, mode = 0, diff = 2;
    uint32_t sixToStart = 1, captureBonus = 1, threeSixes = 1, blocksSafe = 1, fullRanks = 0, quick = 0;
    uint32_t sound = 1, haptics = 1, dark = 1, theme = 11 /* bits 0-2 board design, bits 3-4 dice design */, hints = 1, autoMove = 1;
    uint32_t winsBy[4] = {0, 0, 0, 0}, gamesBy[4] = {0, 0, 0, 0};
    char names[4][16] = {{0}, {0}, {0}, {0}};
    // added later (appended so that older save files still load): HARD rules
    uint32_t captureLock = 0, hardMode = 0, tokenCount = 0 /* 0 = old file: use `quick`; otherwise 1, 2 or 4 */;
    int tokensSetting() const { return tokenCount == 1 || tokenCount == 2 || tokenCount == 4 ? int(tokenCount) : (quick ? 2 : 4); }
    int boardTheme() const { return int(theme & 7u); }
    int diceStyle() const { return int((theme >> 3) & 3u); }
    void load(const std::string &path) {
        FILE *f = fopen(path.c_str(), "rb");
        if (!f) return;
        LudoSave t;   // fields that an older (shorter) file does not contain keep their defaults
        const size_t legacy = offsetof(LudoSave, captureLock);
        size_t n = fread(&t, 1, sizeof(t), f);
        if (n >= legacy && t.magic == LudoSave().magic) *this = t;
        fclose(f);
    }
    void store(const std::string &path) const {
        if (path.empty()) return;
        std::string tmp = path + ".tmp";
        FILE *f = fopen(tmp.c_str(), "wb");
        if (!f) return;
        bool ok = fwrite(this, sizeof(*this), 1, f) == 1;
        fclose(f);
        if (ok) rename(tmp.c_str(), path.c_str());
    }
};

struct LudoUi {
    Ludo game;
    LudoSave save;
    std::string savePath, gamePath;
    // setup choices
    int players = 4, mode = 0 /*0 = vs computer, 1 = friends*/, diff = 2;
    LRules rules;
    // running game
    std::vector<LEvent> evs;
    int dieVal[4] = {1, 1, 1, 1};
    uint32_t dieSeed[4] = {11, 23, 37, 51};
    float dieDoneT[4] = {-99.f, -99.f, -99.f, -99.f};   // lu_.time when each die last came to rest (drives the fly-back)
    struct Flight { int p, t; float fx, fy, tx, ty, tm, dur; };
    std::vector<Flight> flights;
    bool paused = false, statsDone = false, hasSnap = false;
    float overT = -1.f, time = 0.f;
    int xpGain = 0, lastTurn = -1;
};
