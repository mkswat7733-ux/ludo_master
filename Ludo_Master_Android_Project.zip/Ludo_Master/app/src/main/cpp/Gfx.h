#pragma once
// Tiny batched 2D renderer (OpenGL ES 3). Everything is drawn procedurally by one shader:
// discs, rings, rounded rectangles, wood grain and text from a font atlas.
#include <GLES3/gl3.h>
#include <cstdint>
#include <string>
#include <vector>

struct Col {
    float r, g, b, a;
    Col(float R = 1, float G = 1, float B = 1, float A = 1) : r(R), g(G), b(B), a(A) {}
    Col alpha(float A) const { return {r, g, b, A}; }
    Col mul(float k) const { return {r * k, g * k, b * k, a}; }
    static Col hex(uint32_t rgb, float a = 1.f) { return {((rgb >> 16) & 255) / 255.f, ((rgb >> 8) & 255) / 255.f, (rgb & 255) / 255.f, a}; }
    static Col mix(Col a, Col b, float t) { return {a.r + (b.r - a.r) * t, a.g + (b.g - a.g) * t, a.b + (b.b - a.b) * t, a.a + (b.a - a.a) * t}; }
};

enum class Align { LEFT, CENTER, RIGHT };

// Font atlas supplied by the Kotlin side (Android Canvas draws ASCII 32..127 into a grid)
struct FontAtlas {
    std::vector<uint8_t> rgba;
    int w = 0, h = 0, cell = 0, cols = 0;
    float adv[96] = {0};
    bool valid() const { return !rgba.empty(); }
};
FontAtlas &fontAtlasStorage();   // shared with the JNI setter (thread safe via lock helpers)
void fontAtlasLock();
void fontAtlasUnlock();

class Gfx {
public:
    bool init();
    void shutdown();
    void begin(int pxW, int pxH, float worldW, float worldH);
    void end();
    float worldW() const { return worldW_; }
    float worldH() const { return worldH_; }

    void rect(float cx, float cy, float w, float h, Col c);
    void rectGrad(float cx, float cy, float w, float h, Col top, Col bottom);
    void rrect(float cx, float cy, float w, float h, Col top, Col bottom, float radius = 0.35f);
    void wood(float cx, float cy, float w, float h, Col base, float radius = 0.06f);
    void disc(float cx, float cy, float r, Col c, float shade = 0.f);     // shaded sphere-like disc
    void flat(float cx, float cy, float r, Col c);                        // flat anti-aliased disc
    void glow(float cx, float cy, float r, Col c);                        // soft radial falloff
    void ring(float cx, float cy, float r, float thickness, Col c);
    // arbitrary convex quad (corners in order) with a colour per corner; a triangle is a quad with a repeated corner
    void poly(const float xy[8], Col c0, Col c1, Col c2, Col c3);
    void poly(const float xy[8], Col c) { poly(xy, c, c, c, c); }
    // shaded ellipse (semi axes rx, ry, rotated by rot radians)
    void ellipse(float cx, float cy, float rx, float ry, float rot, Col c, float shade = 0.f);
    void line(float x0, float y0, float x1, float y1, float thickness, Col c);
    void text(const std::string &s, float x, float y, float h, Col c, Align a = Align::CENTER, float angle = 0.f);
    // uniform scale + offset applied to everything drawn afterwards (used to shrink the board in 4 player mode)
    void setTransform(float s, float tx, float ty) { xs_ = s; xtx_ = tx; xty_ = ty; }
    void resetTransform() { xs_ = 1.f; xtx_ = 0.f; xty_ = 0.f; }
    float textWidth(const std::string &s, float h) const;

private:
    void quad(float cx, float cy, float hw, float hh, Col c0, Col c1, float mode, float p, float rot = 0, float u0 = -1, float v0 = -1, float u1 = 1, float v1 = 1);
    void flush();
    void uploadAtlas();

    struct Vtx { float x, y, u, v, r, g, b, a, mode, p; };
    std::vector<Vtx> verts_;
    GLuint prog_ = 0, vbo_ = 0, vao_ = 0, ebo_ = 0, tex_ = 0;
    GLint uHalf_ = -1, uTex_ = -1;
    float worldW_ = 1200, worldH_ = 2400;
    bool atlasUploaded_ = false;
    float xs_ = 1.f, xtx_ = 0.f, xty_ = 0.f;
    int atlasW_ = 0, atlasH_ = 0, atlasCell_ = 0, atlasCols_ = 0;
    float adv_[96] = {0};
};
