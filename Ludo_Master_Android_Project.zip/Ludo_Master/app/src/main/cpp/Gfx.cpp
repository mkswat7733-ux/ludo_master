#include "Gfx.h"
#include <algorithm>
#include <cmath>
#include <mutex>
#include <cstdio>
#ifdef __ANDROID__
#include <android/log.h>
#endif

static std::mutex gAtlasMutex;
static FontAtlas gAtlas;
FontAtlas &fontAtlasStorage() { return gAtlas; }
void fontAtlasLock() { gAtlasMutex.lock(); }
void fontAtlasUnlock() { gAtlasMutex.unlock(); }

static const char *kVS = R"(#version 300 es
layout(location=0) in vec2 aPos;
layout(location=1) in vec2 aUV;
layout(location=2) in vec4 aCol;
layout(location=3) in vec2 aMP;
uniform vec2 uHalf;
out vec2 vUV; out vec4 vCol; out vec2 vMP;
void main(){ vUV=aUV; vCol=aCol; vMP=aMP; gl_Position=vec4(aPos/uHalf,0.0,1.0); }
)";

static const char *kFS = R"(#version 300 es
precision highp float;
in vec2 vUV; in vec4 vCol; in vec2 vMP;
uniform sampler2D uTex;
out vec4 o;
float hash(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
float vnoise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f);
  return mix(mix(hash(i),hash(i+vec2(1,0)),f.x), mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x), f.y); }
float sdRound(vec2 q, vec2 b, float r){ vec2 d=abs(q)-b+vec2(r); return length(max(d,0.0))+min(max(d.x,d.y),0.0)-r; }
void main(){
  float mode=vMP.x, p=vMP.y;
  vec4 c=vCol;
  if(mode<0.5){                       // solid / gradient
    o=c;
  } else if(mode<1.5){                // shaded disc
    float r=length(vUV); float fw=fwidth(r)*1.2;
    float a=1.0-smoothstep(1.0-fw,1.0,r);
    vec3 col=c.rgb*(1.0+p*(0.2*(1.0-r)-0.14));
    float spec=pow(max(0.0,1.0-length(vUV-vec2(-0.32,0.34))*1.55),2.6)*0.45*p;
    col+=vec3(spec);
    col*=mix(1.0,0.78,smoothstep(0.82,1.0,r)*p);
    o=vec4(col,c.a*a);
  } else if(mode<2.5){                // soft glow
    float r=length(vUV);
    float a=pow(clamp(1.0-r,0.0,1.0),2.0);
    o=vec4(c.rgb,c.a*a);
  } else if(mode<3.5){                // rounded rect (pill)
    vec2 q=vUV*vec2(p,1.0); float rad=(mode-3.0)*2.0;
    float d=sdRound(q,vec2(p,1.0),rad); float fw=fwidth(d)*1.2;
    o=vec4(c.rgb,c.a*(1.0-smoothstep(-fw,fw,d)));
  } else if(mode<4.5){                // ring, p = inner radius fraction
    float r=length(vUV); float fw=fwidth(r)*1.2;
    float a=(1.0-smoothstep(1.0-fw,1.0,r))*smoothstep(p-fw,p,r);
    o=vec4(c.rgb,c.a*a);
  } else if(mode<5.5){                // font atlas
    float a=texture(uTex,vUV).a;
    o=vec4(c.rgb,c.a*a);
  } else if(mode<6.5){                // wood rounded rect
    vec2 q=vUV*vec2(p,1.0); float d=sdRound(q,vec2(p,1.0),(mode-6.0)*2.0); float fw=fwidth(d)*1.2;
    float a=1.0-smoothstep(-fw,fw,d);
    vec2 w=vUV*vec2(p,1.0)*vec2(7.0,2.2);
    float warp=vnoise(w*vec2(0.5,3.0))*2.2;
    float g=0.5+0.5*sin((w.y*9.0+warp*3.0)+vnoise(w*5.0)*2.0);
    float fine=vnoise(vec2(w.x*4.0,w.y*70.0));
    vec3 col=c.rgb*(0.78+0.30*g+0.10*fine);
    col*=0.93+0.1*smoothstep(0.0,-0.25,d);
    o=vec4(col,c.a*a);
  } else {
    o=c;
  }
}
)";

static GLuint compile(GLenum type, const char *src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char buf[1024]; glGetShaderInfoLog(s, 1024, nullptr, buf);
        fprintf(stderr, "shader error: %s\n", buf);
#ifdef __ANDROID__
        __android_log_print(6, "Carrom", "shader error: %s", buf);
#endif
        glDeleteShader(s); return 0;
    }
    return s;
}

bool Gfx::init() {
    GLuint vs = compile(GL_VERTEX_SHADER, kVS), fs = compile(GL_FRAGMENT_SHADER, kFS);
    if (!vs || !fs) return false;
    prog_ = glCreateProgram();
    glAttachShader(prog_, vs); glAttachShader(prog_, fs);
    glLinkProgram(prog_);
    glDeleteShader(vs); glDeleteShader(fs);
    GLint ok = 0; glGetProgramiv(prog_, GL_LINK_STATUS, &ok);
    if (!ok) return false;
    uHalf_ = glGetUniformLocation(prog_, "uHalf");
    uTex_ = glGetUniformLocation(prog_, "uTex");
    glGenVertexArrays(1, &vao_); glGenBuffers(1, &vbo_); glGenBuffers(1, &ebo_);
    glBindVertexArray(vao_);
    glBindBuffer(GL_ARRAY_BUFFER, vbo_);
    const GLsizei stride = sizeof(Vtx);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, stride, (void *) 0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void *) 8);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 4, GL_FLOAT, GL_FALSE, stride, (void *) 16);
    glEnableVertexAttribArray(3); glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, stride, (void *) 32);
    // static index buffer for up to 8192 quads
    std::vector<uint16_t> idx;
    for (int q = 0; q < 8192; q++) { uint16_t b = q * 4; idx.insert(idx.end(), {b, uint16_t(b + 1), uint16_t(b + 2), b, uint16_t(b + 2), uint16_t(b + 3)}); }
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo_);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, idx.size() * 2, idx.data(), GL_STATIC_DRAW);
    glGenTextures(1, &tex_);
    glBindTexture(GL_TEXTURE_2D, tex_);
    uint8_t px[4] = {255, 255, 255, 255};
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, px);
    verts_.reserve(32768);
    atlasUploaded_ = false;
    return true;
}

void Gfx::shutdown() {
    if (prog_) glDeleteProgram(prog_);
    if (vbo_) glDeleteBuffers(1, &vbo_);
    if (ebo_) glDeleteBuffers(1, &ebo_);
    if (vao_) glDeleteVertexArrays(1, &vao_);
    if (tex_) glDeleteTextures(1, &tex_);
    prog_ = vbo_ = ebo_ = vao_ = tex_ = 0;
}

void Gfx::uploadAtlas() {
    fontAtlasLock();
    FontAtlas &a = fontAtlasStorage();
    if (a.valid()) {
        glBindTexture(GL_TEXTURE_2D, tex_);
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, a.w, a.h, 0, GL_RGBA, GL_UNSIGNED_BYTE, a.rgba.data());
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        atlasW_ = a.w; atlasH_ = a.h; atlasCell_ = a.cell; atlasCols_ = a.cols;
        std::copy(a.adv, a.adv + 96, adv_);
        atlasUploaded_ = true;
    }
    fontAtlasUnlock();
}

void Gfx::begin(int pxW, int pxH, float worldW, float worldH) {
    worldW_ = worldW; worldH_ = worldH;
    if (!atlasUploaded_) uploadAtlas();
    glViewport(0, 0, pxW, pxH);
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glUseProgram(prog_);
    glUniform2f(uHalf_, worldW * 0.5f, worldH * 0.5f);
    glUniform1i(uTex_, 0);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, tex_);
    glBindVertexArray(vao_);
    verts_.clear();
}

void Gfx::end() { flush(); }

void Gfx::flush() {
    if (verts_.empty()) return;
    glBindBuffer(GL_ARRAY_BUFFER, vbo_);
    glBufferData(GL_ARRAY_BUFFER, verts_.size() * sizeof(Vtx), verts_.data(), GL_STREAM_DRAW);
    glDrawElements(GL_TRIANGLES, GLsizei(verts_.size() / 4 * 6), GL_UNSIGNED_SHORT, nullptr);
    verts_.clear();
}

void Gfx::quad(float cx, float cy, float hw, float hh, Col c0, Col c1, float mode, float p, float rot,
               float u0, float v0, float u1, float v1) {
    if (verts_.size() + 4 > 8192 * 4) flush();
    cx = cx * xs_ + xtx_; cy = cy * xs_ + xty_; hw *= xs_; hh *= xs_;
    // corners: top-left, top-right, bottom-right, bottom-left (world y is up)
    float xs[4] = {-hw, hw, hw, -hw}, ys[4] = {hh, hh, -hh, -hh};
    float us[4] = {u0, u1, u1, u0}, vs[4] = {v0, v0, v1, v1};
    float cs = std::cos(rot), sn = std::sin(rot);
    for (int i = 0; i < 4; i++) {
        float x = xs[i] * cs - ys[i] * sn, y = xs[i] * sn + ys[i] * cs;
        const Col &c = i < 2 ? c0 : c1;
        verts_.push_back({cx + x, cy + y, us[i], vs[i], c.r, c.g, c.b, c.a, mode, p});
    }
}

void Gfx::rect(float cx, float cy, float w, float h, Col c) { quad(cx, cy, w / 2, h / 2, c, c, 0, 0); }
void Gfx::rectGrad(float cx, float cy, float w, float h, Col t, Col b) { quad(cx, cy, w / 2, h / 2, t, b, 0, 0); }
void Gfx::rrect(float cx, float cy, float w, float h, Col t, Col b, float radius) { quad(cx, cy, w / 2, h / 2, t, b, 3.f + std::min(0.99f, radius) * 0.5f, w / h); }
void Gfx::wood(float cx, float cy, float w, float h, Col base, float radius) { quad(cx, cy, w / 2, h / 2, base, base, 6.f + std::min(0.99f, radius) * 0.5f, w / h); }
void Gfx::disc(float cx, float cy, float r, Col c, float shade) { float e = r + 1.5f, k = e / r; quad(cx, cy, e, e, c, c, 1, shade, 0, -k, -k, k, k); }
void Gfx::flat(float cx, float cy, float r, Col c) { float e = r + 1.5f, k = e / r; quad(cx, cy, e, e, c, c, 1, 0, 0, -k, -k, k, k); }
void Gfx::glow(float cx, float cy, float r, Col c) { quad(cx, cy, r, r, c, c, 2, 0); }
void Gfx::ring(float cx, float cy, float r, float th, Col c) { float o = r + th * 0.5f, e = o + 1.5f, k = e / o; quad(cx, cy, e, e, c, c, 4, (r - th * 0.5f) / o, 0, -k, -k, k, k); }
void Gfx::poly(const float xy[8], Col c0, Col c1, Col c2, Col c3) {
    if (verts_.size() + 4 > 8192 * 4) flush();
    const Col *cs[4] = {&c0, &c1, &c2, &c3};
    for (int i = 0; i < 4; i++) {
        const Col &c = *cs[i];
        verts_.push_back({xy[i * 2] * xs_ + xtx_, xy[i * 2 + 1] * xs_ + xty_, 0, 0, c.r, c.g, c.b, c.a, 0.f, 0.f});
    }
}

void Gfx::ellipse(float cx, float cy, float rx, float ry, float rot, Col c, float shade) {
    rx = std::max(rx, 0.5f); ry = std::max(ry, 0.5f);
    float ex = rx + 1.5f, ey = ry + 1.5f;
    quad(cx, cy, ex, ey, c, c, 1, shade, rot, -ex / rx, -ey / ry, ex / rx, ey / ry);
}

void Gfx::line(float x0, float y0, float x1, float y1, float th, Col c) {
    float dx = x1 - x0, dy = y1 - y0, len = std::sqrt(dx * dx + dy * dy);
    if (len < 0.01f) return;
    quad((x0 + x1) / 2, (y0 + y1) / 2, len / 2, th / 2, c, c, 0, 0, std::atan2(dy, dx));
}

float Gfx::textWidth(const std::string &s, float h) const {
    float sc = h / 60.f, w = 0;
    for (unsigned char ch : s) { int i = (ch >= 32 && ch < 128) ? ch - 32 : 0; w += (adv_[i] > 0 ? adv_[i] : 30.f) * sc; }
    return w;
}

void Gfx::text(const std::string &s, float x, float y, float h, Col c, Align al, float angle) {
    if (!atlasUploaded_) return;
    float sc = h / 60.f;           // atlas text size is ~60px per em
    float w = textWidth(s, h);
    float pen = al == Align::LEFT ? 0.f : al == Align::CENTER ? -w / 2 : -w;
    float cellW = atlasCell_ * sc;
    float ca = std::cos(angle), sa = std::sin(angle);
    for (unsigned char ch : s) {
        int i = (ch >= 32 && ch < 128) ? ch - 32 : 0;
        float adv = (adv_[i] > 0 ? adv_[i] : 30.f) * sc;
        if (ch != ' ') {
            int col = i % atlasCols_, row = i / atlasCols_;
            float u0 = col * atlasCell_ / float(atlasW_), u1 = (col + 1) * atlasCell_ / float(atlasW_);
            float v0 = row * atlasCell_ / float(atlasH_), v1 = (row + 1) * atlasCell_ / float(atlasH_);
            // glyph centre in the text's own frame: along the baseline, cap-height centre sits ~3px above the cell centre
            float lx = pen + adv / 2, ly = -3.f * sc;
            quad(x + lx * ca - ly * sa, y + lx * sa + ly * ca, cellW / 2, cellW / 2, c, c, 5, 0, angle, u0, v0, u1, v1);
        }
        pen += adv;
    }
}
