#pragma once
// Portable Ludo engine: rules, dice, turn flow and the computer players. No Android / OpenGL code,
// so it can be tested on a PC.
//
// Board model: 52 cell loop shared by everybody (clockwise) + 5 private home-column cells per colour + the centre.
// A token position is "rel": -1 = in the yard, 0..50 = on the shared loop (0 = the colour's start cell),
// 51..55 = home column, 56 = finished (centre).
#include <algorithm>
#include <cstdint>
#include <string>
#include <vector>

constexpr int LD_HOME = 56;
constexpr int LD_LOOP = 52;
enum LColor { LC_RED = 0, LC_GREEN = 1, LC_YELLOW = 2, LC_BLUE = 3 };   // bottom-left, top-left, top-right, bottom-right (clockwise)

struct LRules {
    bool sixToStart = true;      // a 6 is needed to bring a token out of the yard
    bool captureBonus = true;    // capturing a token gives another roll
    bool threeSixes = true;      // three sixes in a row: the turn is lost
    bool blocksSafe = true;      // two tokens of one colour on a cell cannot be captured
    bool fullRanks = false;      // keep playing until every place is decided
    int tokens = 4;              // tokens per player (4 classic, 2 quick, 1 duel)
    bool captureLock = false;    // HARD: a player must capture an opponent before any token may enter the home column (padlock)
    bool hardMode = false;       // HARD: no hints, no highlighted / disabled tokens, no auto move for humans
};

struct LState {
    int pos[4][4];
    bool active[4];
    bool done[4];
    bool unlocked[4];            // captureLock: this player has captured and may enter home (lost again when all tokens are captured)
    LRules rules;
};
inline bool ldLocked(const LState &s, int p) { return s.rules.captureLock && !s.unlocked[p]; }

// ---- board helpers
int ldStartIndex(int color);                 // loop index of the start cell
int ldLoopIndex(int color, int rel);         // loop index of a token, -1 when it is not on the shared loop
bool ldSafeIndex(int loopIdx);               // start cells and star cells
void ldLoopCell(int loopIdx, int &col, int &row);        // grid cell (15 x 15, row 0 = top)
void ldHomeCell(int color, int k, int &col, int &row);   // k = 0..4
void ldYardCenter(int color, float &cx, float &cy);      // grid units (0..15)

// ---- rules
bool ldLegal(const LState &s, int p, int tok, int roll);
struct LMoveResult {
    int from = 0, to = 0;
    bool enter = false, home = false;
    int nCap = 0, capP[12], capT[12], capRel[12], capIdx = -1;   // captured tokens (rel = where they were), loop cell index
    bool unlock = false;       // the mover just unlocked its home by capturing
    int relockMask = 0;        // bit q set: player q lost its unlock because all of its tokens were captured
};
LMoveResult ldApply(LState &s, int p, int tok, int roll);
int ldPips(const LState &s, int p);          // steps still needed by all tokens of p
struct LTune {   // weights of the computer players (index = skill)
    float wRisk, wThreat, wBlock, spare1, noise, spare2, capBase, capRel, capBonus, homeBonus, colBonus, enterBase, enterOut, progress, safeLand, safeLeave;
};
extern LTune gLudoTune[4];
int ldChooseMove(const LState &s, int p, int roll, int skill, uint32_t &rng);   // skill 0 easy .. 3 master; -1 when no move

// ---- game flow
enum class LPhase { ROLL_WAIT, ROLLING, CHOOSE, MOVING, SETTLE, OVER };
enum LEvType {
    LE_ROLL_START, LE_ROLL_BOUNCE, LE_ROLL_DONE, LE_HOP, LE_ENTER, LE_CAPTURE, LE_HOME, LE_NO_MOVE,
    LE_THREE_SIXES, LE_TURN, LE_PLAYER_DONE, LE_OVER, LE_UNLOCK, LE_RELOCK
};
struct LEvent { LEvType type; int player = -1, tok = -1, value = 0, aux = 0; };

class Ludo {
public:
    static constexpr float ROLL_T = 1.25f, STEP_T = 0.17f, ENTER_T = 0.45f;
    static float dieHeight(float tn);     // 0..1 progress of the roll -> bounce height (0..1) shared with the renderer

    void newGame(int nPlayers, const bool human[4], int skill, const LRules &rules, uint32_t seed);
    void update(float dt, std::vector<LEvent> &ev);
    bool roll(std::vector<LEvent> &ev);          // current player rolls (UI tap or computer)
    bool choose(int tok, std::vector<LEvent> &ev);   // human picks the token to move

    void setAutoSingle(bool on) { autoSingle_ = on; }      // a human with only one possible move does not have to tap it
    std::string snapshot(int uiMode) const;                 // whole game as bytes (call while ROLL_WAIT)
    bool restore(const std::string &data, int &uiMode);
    const LState &st() const { return s_; }
    LState &debugState() { return s_; }       // tests / previews only
    LPhase phase() const { return phase_; }
    int turn() const { return turn_; }
    bool human(int p) const { return human_[p]; }
    int skill() const { return skill_; }
    int players() const { return nPlayers_; }
    int rollValue() const { return value_; }
    float rollProgress() const { return phase_ == LPhase::ROLLING ? std::min(1.f, t_ / ROLL_T) : 1.f; }
    uint32_t legalMask() const { return phase_ == LPhase::CHOOSE ? mask_ : 0u; }
    bool autoPicking() const { return phase_ == LPhase::CHOOSE && autoPick_; }
    int sixes() const { return sixes_; }
    // move animation
    bool moving() const { return phase_ == LPhase::MOVING; }
    int moveTok() const { return mvTok_; }
    int moveFrom() const { return mvFrom_; }
    int moveTo() const { return mvTo_; }
    float moveSteps() const;                       // hop steps done so far (fractional)
    int place(int p) const { return place_[p]; }   // 1 = first ... 0 = not finished
    int captures(int p) const { return caps_[p]; }
    int rankOf(int p) const { return rank_[p]; }   // final ranking (valid when OVER)
    int winner() const { return winner_; }
    const LRules &rules() const { return s_.rules; }
    int nextActive(int p) const;

private:
    void startRoll(std::vector<LEvent> &ev);
    void finishRoll(std::vector<LEvent> &ev);
    void beginMove(int tok, std::vector<LEvent> &ev);
    void endMove(std::vector<LEvent> &ev);
    void nextTurn(std::vector<LEvent> &ev);
    void finishGame(std::vector<LEvent> &ev);
    uint32_t rnd();
    bool stalled() const;

    LState s_{};
    LPhase phase_ = LPhase::OVER;
    bool human_[4] = {true, true, true, true};
    int nPlayers_ = 2, skill_ = 1, turn_ = 0, value_ = 1, sixes_ = 0;
    float t_ = 0, aiDelay_ = 0.7f, chooseDelay_ = 0.5f, settleDur_ = 0.4f, moveDur_ = 0.5f;
    uint32_t mask_ = 0, rng_ = 1;
    bool autoPick_ = false, bonus_ = false, autoSingle_ = true;
    int bounces_ = 0, hops_ = 0;
    int mvTok_ = 0, mvFrom_ = 0, mvTo_ = 0;
    int place_[4] = {0, 0, 0, 0}, rank_[4] = {0, 0, 0, 0}, caps_[4] = {0, 0, 0, 0}, placed_ = 0, winner_ = -1;
    bool moveCaptured_ = false;
};
