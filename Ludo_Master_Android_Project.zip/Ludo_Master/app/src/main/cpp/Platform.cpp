#include "Platform.h"
#include <game-activity/native_app_glue/android_native_app_glue.h>
#include <jni.h>

static android_app *gApp = nullptr;
static jmethodID gHaptic = nullptr, gNames = nullptr;
static bool gHapticFailed = false;

// The JNIEnv in activity->env belongs to the Java UI thread, it must NOT be used from the game thread.
// We get (or attach) the env of the current thread instead.
static JNIEnv *threadEnv() {
    if (!gApp || !gApp->activity || !gApp->activity->vm) return nullptr;
    JavaVM *vm = gApp->activity->vm;
    JNIEnv *env = nullptr;
    jint r = vm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6);
    if (r == JNI_OK) return env;
    if (r == JNI_EDETACHED && vm->AttachCurrentThread(&env, nullptr) == JNI_OK) return env;
    return nullptr;
}

static jmethodID findMethod(JNIEnv *env, jmethodID &cache, const char *name, const char *sig) {
    if (cache) return cache;
    jclass cls = env->GetObjectClass(gApp->activity->javaGameActivity);
    if (cls) {
        cache = env->GetMethodID(cls, name, sig);
        env->DeleteLocalRef(cls);
    }
    if (env->ExceptionCheck()) { env->ExceptionClear(); cache = nullptr; }
    return cache;
}

namespace Platform {
void attach(android_app *app) { gApp = app; gHaptic = gNames = nullptr; gHapticFailed = false; }

void haptic(int kind) {
    if (gHapticFailed || !gApp || !gApp->activity || !gApp->activity->javaGameActivity) return;
    JNIEnv *env = threadEnv();
    if (!env) return;
    if (!findMethod(env, gHaptic, "performHaptic", "(I)V")) { gHapticFailed = true; return; }   // never crash
    env->CallVoidMethod(gApp->activity->javaGameActivity, gHaptic, static_cast<jint>(kind));
    if (env->ExceptionCheck()) { env->ExceptionClear(); gHapticFailed = true; }
}

void quit() {
    if (gApp && gApp->activity) GameActivity_finish(gApp->activity);
}

void openNamesForm(const char *packedNames) {
    if (!gApp || !gApp->activity || !gApp->activity->javaGameActivity) return;
    JNIEnv *env = threadEnv();
    if (!env || !findMethod(env, gNames, "openNamesForm", "(Ljava/lang/String;)V")) return;
    jstring a = env->NewStringUTF(packedNames);
    env->CallVoidMethod(gApp->activity->javaGameActivity, gNames, a);
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(a);
}

}
