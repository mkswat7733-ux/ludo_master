#pragma once
// The whole Ludo app: menu, setup, board, dice, settings. Portable (no Android code).
#include <functional>
#include <string>
#include <vector>
#include "Audio.h"
#include "Gfx.h"
#include "LudoUi.h"
#include "NetQueue.h"
#include "Vec2.h"

class App {
public:
    void init(const std::string &saveFile);
    void resize(float worldW, float worldH) { ww_ = worldW; wh_ = worldH; }
    void update(float dt);
    void draw(Gfx &g);
    // action: 0 down, 1 move, 2 up, 3 cancel.  x,y in world units (y up, origin in screen centre)
    void touch(int action, int pointerId, float x, float y);
    void onBack();
    void onPause();
    void onResume() { audio_.start(); }
    Audio &audio() { return audio_; }
    std::function<void(int)> hapticFn;
    std::function<void()> quitFn;
    std::function<void(const std::string &packedNames)> openNamesFn;   // dialog with 4 name fields (Kotlin)

    enum class Screen { MENU, SETUP, GAME, HOWTO, SETTINGS, STATS };
    Screen screen() const { return screen_; }
    LudoUi &ludoRef() { return lu_; }
    void debugOpen(Screen s) { screen_ = s; }
    void debugStart() { ludoStart(); }

private:
    struct Hit { int id; float x, y, w, h; };
    struct Particle { V2 p, v; float life, max, size; Col c; bool spark; };
    struct Toast { std::string text; Col col; float t, dur, size; };

    // ui helpers
    bool button(Gfx &g, int id, float x, float y, float w, float h, const std::string &label, Col top, Col bot, float textH = 46.f, bool enabled = true);
    void tile(Gfx &g, int id, float x, float y, float w, float h, const std::string &label, const std::string &sub, Col top, Col bot);
    void segment(Gfx &g, int idBase, float cy, const std::vector<std::string> &labels, int selected, float totalW);
    void toggleTile(Gfx &g, int id, float x, float y, float w, float h, const std::string &label, bool on);
    void drawBackground(Gfx &g);
    void toast(const std::string &t, Col c, float dur = 1.6f, float size = 84.f);
    void burst(V2 p, Col c, int n, float speed, bool spark);
    void click() { audio_.play(Snd::CLICK); haptic(0); }
    void haptic(int k) { if (lu_.save.haptics && hapticFn) hapticFn(k); }
    float rnd() { rng_ = rng_ * 1664525u + 1013904223u; return ((rng_ >> 8) & 0xFFFFFF) / float(0x1000000); }
    void action(int id);

    // screens
    void drawMenu(Gfx &g);
    void drawSettings(Gfx &g);
    void drawStats(Gfx &g);
    void drawLudoSetup(Gfx &g);
    void drawLudoHowTo(Gfx &g);
    void drawLudoGame(Gfx &g);
    void drawLudoOverlays(Gfx &g);

    // game flow
    void ludoStart();
    void ludoContinue();
    void ludoAction(int id);
    void ludoUpdate(float dt);
    void ludoEvents();
    void ludoFinish();
    void ludoBack();
    void saveSnapshot();
    void clearSnapshot();
    void persist() { lu_.save.store(lu_.savePath); }
    std::string ludoName(int p) const;

    Audio audio_;
    LudoUi lu_;
    Screen screen_ = Screen::MENU, prev_ = Screen::MENU;
    float ww_ = 1200, wh_ = 2400, time_ = 0, screenT_ = 0;
    uint32_t rng_ = 0xC0FFEEu;
    int pressed_ = -1, activeId_ = -1;
    std::vector<Hit> hits_;
    std::vector<Particle> parts_;
    std::vector<Toast> toasts_;
};
