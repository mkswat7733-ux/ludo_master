#pragma once
// Thin bridge to Android specific things (haptics, closing the activity).
struct android_app;
namespace Platform {
void attach(android_app *app);
void haptic(int kind);   // 0 = light tick, 1 = strong thump
void quit();
void openNamesForm(const char *packedNames);   // names separated by '|'
}
