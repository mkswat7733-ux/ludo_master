#pragma once
#include <cmath>
struct V2 {
    float x = 0, y = 0;
    V2() = default;
    V2(float X, float Y) : x(X), y(Y) {}
    V2 operator+(V2 o) const { return {x + o.x, y + o.y}; }
    V2 operator-(V2 o) const { return {x - o.x, y - o.y}; }
    V2 operator*(float s) const { return {x * s, y * s}; }
    V2 &operator+=(V2 o) { x += o.x; y += o.y; return *this; }
    V2 &operator-=(V2 o) { x -= o.x; y -= o.y; return *this; }
    float dot(V2 o) const { return x * o.x + y * o.y; }
    float len2() const { return x * x + y * y; }
    float len() const { return std::sqrt(x * x + y * y); }
    V2 norm() const { float l = len(); return l > 1e-6f ? V2{x / l, y / l} : V2{0, 1}; }
};
