#pragma once
// Procedurally synthesised sound effects (no audio files needed). Uses AAudio on Android.
#include <atomic>
#include <cstdint>

enum class Snd { CLACK, STRIKE, WALL, POCKET, CLICK, FOUL, WIN, LOSE, QUEEN, TURN };

class Audio {
public:
    ~Audio() { stop(); }
    bool start();
    void stop();
    void play(Snd s, float vol = 1.f, float pitch = 1.f);   // game thread only
    void setEnabled(bool on) { enabled_ = on; }
    bool enabled() const { return enabled_; }
    void render(float *out, int frames);                    // audio thread (also used by tests)
    void setSampleRate(int sr) { sr_ = sr; }
    bool needsRestart() const { return restart_.load(); }
    void clearRestart() { restart_ = false; }

private:
    struct Trig { Snd s; float vol, pitch; };
    struct Voice {
        bool on = false;
        float t = 0, amp = 0, f0 = 0, f1 = 0, decay = 0.1f, noise = 0, dur = 0.5f, delay = 0, ph = 0;
        int wave = 0;   // 0 sine, 1 soft square
    };
    void spawn(const Voice &v);
    void trigger(const Trig &t);
    uint32_t rnd();

    static constexpr int QN = 64;
    Trig q_[QN];
    std::atomic<uint32_t> qHead_{0}, qTail_{0};
    Voice voices_[28];
    uint32_t seed_ = 12345;
    int sr_ = 48000;
    bool enabled_ = true;
    std::atomic<bool> restart_{false};
    void *stream_ = nullptr;
    friend struct AudioCb;
};
