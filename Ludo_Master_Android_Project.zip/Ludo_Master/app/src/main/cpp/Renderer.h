#pragma once
#include <EGL/egl.h>
#include <memory>

struct android_app;
class App;
class Gfx;

// Owns the EGL surface/context for the current window and drives one frame of the game.
class Renderer {
public:
    Renderer(android_app *app, App *game);
    ~Renderer();
    bool ok() const { return ok_; }
    void handleInput();            // drains touch / key events into the App
    void frame(float dt);          // update + draw + swap

private:
    bool initEgl();
    void updateArea();

    android_app *app_;
    App *game_;
    EGLDisplay display_ = EGL_NO_DISPLAY;
    EGLSurface surface_ = EGL_NO_SURFACE;
    EGLContext context_ = EGL_NO_CONTEXT;
    int width_ = 0, height_ = 0;
    float worldW_ = 1200.f, worldH_ = 2400.f;
    bool ok_ = false;
    std::unique_ptr<Gfx> gfx_;
};
