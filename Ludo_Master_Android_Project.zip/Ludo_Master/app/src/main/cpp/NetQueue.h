#pragma once
// Thread-safe mailbox: Kotlin (UI thread) -> game thread.
#include <deque>
#include <mutex>
#include <string>

inline std::mutex &netMutex() { static std::mutex m; return m; }
inline std::deque<std::string> &netQueue() { static std::deque<std::string> q; return q; }
inline void netPush(const std::string &s) { std::lock_guard<std::mutex> l(netMutex()); netQueue().push_back(s); }
inline bool netPop(std::string &s) {
    std::lock_guard<std::mutex> l(netMutex());
    if (netQueue().empty()) return false;
    s = netQueue().front(); netQueue().pop_front(); return true;
}
