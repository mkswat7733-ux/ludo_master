#include "Ludo.h"
#include <cmath>
#include <cstring>

// ------------------------------------------------------------------------------------ board tables
namespace {
struct Tables {
    int loop[LD_LOOP][2];
    Tables() {
        int n = 0;
        auto add = [&](int c, int r) { loop[n][0] = c; loop[n][1] = r; n++; };
        for (int c = 1; c <= 5; c++) add(c, 6);
        for (int r = 5; r >= 0; r--) add(6, r);
        add(7, 0); add(8, 0);
        for (int r = 1; r <= 5; r++) add(8, r);
        for (int c = 9; c <= 14; c++) add(c, 6);
        add(14, 7); add(14, 8);
        for (int c = 13; c >= 9; c--) add(c, 8);
        for (int r = 9; r <= 14; r++) add(8, r);
        add(7, 14); add(6, 14);
        for (int r = 13; r >= 9; r--) add(6, r);
        for (int c = 5; c >= 0; c--) add(c, 8);
        add(0, 7); add(0, 6);
    }
};
const Tables &T() { static Tables t; return t; }
const int kStart[4] = {39, 0, 13, 26};
}

int ldStartIndex(int color) { return kStart[color & 3]; }
int ldLoopIndex(int color, int rel) { return (rel < 0 || rel > 50) ? -1 : (kStart[color & 3] + rel) % LD_LOOP; }
bool ldSafeIndex(int idx) { return idx >= 0 && (idx % 13 == 0 || idx % 13 == 8); }
void ldLoopCell(int idx, int &col, int &row) { idx = ((idx % LD_LOOP) + LD_LOOP) % LD_LOOP; col = T().loop[idx][0]; row = T().loop[idx][1]; }
void ldHomeCell(int color, int k, int &col, int &row) {
    switch (color & 3) {
        case LC_GREEN:  col = 1 + k;  row = 7; break;
        case LC_YELLOW: col = 7;      row = 1 + k; break;
        case LC_BLUE:   col = 13 - k; row = 7; break;
        default:        col = 7;      row = 13 - k; break;   // red
    }
}
void ldYardCenter(int color, float &cx, float &cy) {
    switch (color & 3) {
        case LC_GREEN:  cx = 3.f;  cy = 3.f;  break;
        case LC_YELLOW: cx = 12.f; cy = 3.f;  break;
        case LC_BLUE:   cx = 12.f; cy = 12.f; break;
        default:        cx = 3.f;  cy = 12.f; break;
    }
}

// ------------------------------------------------------------------------------------ rules
bool ldLegal(const LState &s, int p, int tok, int roll) {
    if (tok < 0 || tok >= s.rules.tokens) return false;
    int cur = s.pos[p][tok];
    if (cur >= LD_HOME) return false;
    if (cur < 0) return !s.rules.sixToStart || roll == 6;
    if (ldLocked(s, p) && cur + roll > 50) return false;     // locked home: nobody may pass the last cell of the shared loop
    // with "six to start" a 6 must first free a token: while any token of this player still waits in the yard,
    // the tokens already on the board cannot use that 6
    if (roll == 6 && s.rules.sixToStart)
        for (int u = 0; u < s.rules.tokens; u++) if (s.pos[p][u] < 0) return false;
    return cur + roll <= LD_HOME;
}

LMoveResult ldApply(LState &s, int p, int tok, int roll) {
    LMoveResult r;
    int cur = s.pos[p][tok];
    r.from = cur;
    int np;
    if (cur < 0) { np = 0; r.enter = true; } else np = cur + roll;
    r.to = np;
    s.pos[p][tok] = np;
    if (np == LD_HOME) {
        r.home = true;
        bool all = true;
        for (int t = 0; t < s.rules.tokens; t++) if (s.pos[p][t] != LD_HOME) all = false;
        if (all) s.done[p] = true;
    } else if (np <= 50) {
        int a = ldLoopIndex(p, np);
        r.capIdx = a;
        if (!ldSafeIndex(a)) {
            for (int q = 0; q < 4; q++) {
                if (q == p || !s.active[q]) continue;
                int cnt = 0;
                for (int t = 0; t < s.rules.tokens; t++) if (ldLoopIndex(q, s.pos[q][t]) == a) cnt++;
                if (cnt == 0 || (s.rules.blocksSafe && cnt >= 2)) continue;
                for (int t = 0; t < s.rules.tokens; t++) {
                    if (ldLoopIndex(q, s.pos[q][t]) != a || r.nCap >= 12) continue;
                    r.capP[r.nCap] = q; r.capT[r.nCap] = t; r.capRel[r.nCap] = s.pos[q][t]; r.nCap++;
                    s.pos[q][t] = -1;
                }
            }
            if (r.nCap > 0 && s.rules.captureLock) {
                if (!s.unlocked[p]) { s.unlocked[p] = true; r.unlock = true; }
                for (int i = 0; i < r.nCap; i++) {      // a victim that has no token left on the board / home column is locked again
                    int q = r.capP[i];
                    if (!s.unlocked[q]) continue;
                    bool inPlay = false;
                    for (int t = 0; t < s.rules.tokens; t++) if (s.pos[q][t] >= 0 && s.pos[q][t] < LD_HOME) inPlay = true;
                    if (!inPlay) { s.unlocked[q] = false; r.relockMask |= 1 << q; }
                }
            }
        }
    }
    return r;
}

int ldPips(const LState &s, int p) {
    int sum = 0;
    for (int t = 0; t < s.rules.tokens; t++) sum += s.pos[p][t] < 0 ? LD_HOME + 1 : LD_HOME - s.pos[p][t];
    return sum;
}

// ------------------------------------------------------------------------------------ computer players
namespace {
// chance that some opponent can capture the token `tok` of player p on its next turn
float riskOf(const LState &s, int p, int tok) {
    int rel = s.pos[p][tok];
    int a = ldLoopIndex(p, rel);
    if (a < 0 || ldSafeIndex(a)) return 0.f;
    if (s.rules.blocksSafe)
        for (int t = 0; t < s.rules.tokens; t++) if (t != tok && s.pos[p][t] == rel) return 0.f;
    float survive = 1.f;
    for (int q = 0; q < 4; q++) {
        if (q == p || !s.active[q] || s.done[q]) continue;
        bool small[7] = {false}, big[13] = {false};
        float viaSix = 0.f;
        for (int u = 0; u < s.rules.tokens; u++) {
            int r = s.pos[q][u];
            if (r >= 0 && r <= 50) {
                int d = (a - ldLoopIndex(q, r) + LD_LOOP) % LD_LOOP;
                if (d >= 1 && d <= 12 && r + d <= 50) { if (d <= 6) small[d] = true; else big[d] = true; }
            } else if (r < 0 && s.rules.sixToStart) {
                int d = (a - ldStartIndex(q) + LD_LOOP) % LD_LOOP;
                if (d >= 1 && d <= 6) viaSix = 1.f / 36.f;
            }
        }
        int ns = 0, nb = 0;
        for (int d = 1; d <= 6; d++) if (small[d]) ns++;
        for (int d = 7; d <= 12; d++) if (big[d]) nb++;
        float pq = ns / 6.f + nb / 36.f + viaSix;
        survive *= 1.f - std::min(1.f, pq);
    }
    return 1.f - survive;
}

float tokenValue(int rel) { return 40.f + 2.f * rel; }

float totalRisk(const LState &s, int p) {
    float sum = 0;
    for (int t = 0; t < s.rules.tokens; t++) if (s.pos[p][t] >= 0 && s.pos[p][t] <= 50) sum += riskOf(s, p, t) * tokenValue(s.pos[p][t]);
    return sum;
}

int outCount(const LState &s, int p) {
    int n = 0;
    for (int t = 0; t < s.rules.tokens; t++) if (s.pos[p][t] >= 0 && s.pos[p][t] < LD_HOME) n++;
    return n;
}

}
LTune gLudoTune[4] = {
    {0, 0, 0, 0, 0, 0, 55.f, 2.f, 12.f, 80.f, 30.f, 40.f, 5.f, 1.2f, 14.f, 6.f},
    {0, 0, 0, 0, 3.f, 0, 55.f, 2.f, 12.f, 80.f, 30.f, 40.f, 5.f, 1.2f, 14.f, 6.f},
    {0.7f, 2.f, 10.f, 0, 1.5f, 0, 55.f, 2.f, 12.f, 80.f, 30.f, 40.f, 5.f, 1.2f, 14.f, 6.f},
    {1.0f, 4.1f, 10.f, 0, 0.2f, 0, 71.f, 2.f, 9.5f, 93.7f, 12.f, 40.f, 5.f, 1.55f, 14.f, 6.f},   // tuned by self-play
};
namespace {
float scoreMove(const LState &s, int p, int tok, int roll, int skill, uint32_t &rng) {
    auto rnd01 = [&]() { rng = rng * 1664525u + 1013904223u; return ((rng >> 8) & 0xFFFF) / 65536.f; };
    const LTune &w = gLudoTune[std::max(0, std::min(3, skill))];
    LState after = s;
    LMoveResult r = ldApply(after, p, tok, roll);
    float score = 0.f;
    if (skill <= 0) return rnd01() * 100.f + (r.nCap ? 35.f : 0.f) + (r.home ? 25.f : 0.f);
    for (int i = 0; i < r.nCap; i++) score += w.capBase + w.capRel * r.capRel[i];
    if (r.unlock) score += 45.f;                      // the computer wants its padlock open
    if (r.nCap && s.rules.captureBonus) score += w.capBonus;
    if (r.home) score += w.homeBonus;
    else if (r.to > 50 && r.from <= 50 && !r.enter) score += w.colBonus;
    if (r.enter) score += w.enterBase - w.enterOut * outCount(s, p);
    else score += w.progress * (r.to - r.from);
    bool fromSafe = r.from >= 0 && ldSafeIndex(ldLoopIndex(p, r.from));
    bool toSafe = r.to <= 50 && ldSafeIndex(ldLoopIndex(p, r.to));
    if (toSafe && !fromSafe && !r.enter) score += w.safeLand;
    if (fromSafe && !toSafe) score -= w.safeLeave;
    if (w.wRisk > 0.f) score += w.wRisk * (totalRisk(s, p) - totalRisk(after, p));
    if (w.wBlock > 0.f && s.rules.blocksSafe && r.to >= 0 && r.to <= 50 && !toSafe)
        for (int t = 0; t < s.rules.tokens; t++) if (t != tok && after.pos[p][t] == r.to) { score += w.wBlock; break; }
    if (w.wThreat > 0.f && r.to >= 0 && r.to <= 50) {            // threatening opponent tokens just ahead of us
        int a = ldLoopIndex(p, r.to);
        float threat = 0.f;
        for (int q = 0; q < 4; q++) {
            if (q == p || !after.active[q]) continue;
            for (int u = 0; u < s.rules.tokens; u++) {
                int b = ldLoopIndex(q, after.pos[q][u]);
                if (b < 0 || ldSafeIndex(b)) continue;
                int d = (b - a + LD_LOOP) % LD_LOOP;
                if (d >= 1 && d <= 6 && r.to + d <= 50) threat += 1.f + after.pos[q][u] / 50.f;
            }
        }
        score += w.wThreat * threat;
    }
    return score + (rnd01() - 0.5f) * 2.f * w.noise;
}
}

int ldChooseMove(const LState &s, int p, int roll, int skill, uint32_t &rng) {
    int best = -1;
    float bestScore = -1e9f;
    for (int t = 0; t < s.rules.tokens; t++) {
        if (!ldLegal(s, p, t, roll)) continue;
        float sc = scoreMove(s, p, t, roll, skill, rng);
        if (sc > bestScore) { bestScore = sc; best = t; }
    }
    return best;
}

// ------------------------------------------------------------------------------------ game flow
float Ludo::dieHeight(float tn) {
    if (tn >= 1.f || tn <= 0.f) return 0.f;
    return std::pow(1.f - tn, 1.5f) * std::fabs(std::sin(3.14159265f * 3.5f * std::pow(tn, 0.8f)));
}

uint32_t Ludo::rnd() {
    rng_ ^= rng_ << 13; rng_ ^= rng_ >> 17; rng_ ^= rng_ << 5;
    return rng_;
}

void Ludo::newGame(int nPlayers, const bool human[4], int skill, const LRules &rules, uint32_t seed) {
    s_ = LState();
    s_.rules = rules;
    s_.rules.tokens = std::max(1, std::min(4, rules.tokens));
    nPlayers_ = std::max(2, std::min(4, nPlayers));
    skill_ = std::max(0, std::min(3, skill));
    for (int p = 0; p < 4; p++) {
        s_.active[p] = false; s_.done[p] = false; s_.unlocked[p] = false;
        for (int t = 0; t < 4; t++) s_.pos[p][t] = -1;
        place_[p] = rank_[p] = caps_[p] = 0;
        human_[p] = human ? human[p] : (p == 0);
    }
    static const int seats2[2] = {LC_RED, LC_YELLOW}, seats3[3] = {LC_RED, LC_GREEN, LC_YELLOW};
    if (nPlayers_ == 2) for (int p : seats2) s_.active[p] = true;
    else if (nPlayers_ == 3) for (int p : seats3) s_.active[p] = true;
    else for (int p = 0; p < 4; p++) s_.active[p] = true;
    rng_ = seed ? seed : 0x9E3779B9u;
    for (int i = 0; i < 8; i++) rnd();
    turn_ = LC_RED; sixes_ = 0; bonus_ = false; placed_ = 0; winner_ = -1; mask_ = 0; value_ = 1;
    phase_ = LPhase::ROLL_WAIT; t_ = 0; aiDelay_ = 0.8f;
}

int Ludo::nextActive(int p) const {
    for (int i = 1; i <= 4; i++) {
        int q = (p + i) % 4;
        if (s_.active[q] && !s_.done[q]) return q;
    }
    return -1;
}

float Ludo::moveSteps() const {
    if (phase_ != LPhase::MOVING) return 0.f;
    return mvFrom_ < 0 ? std::min(1.f, t_ / ENTER_T) : t_ / STEP_T;
}

bool Ludo::roll(std::vector<LEvent> &ev) {
    if (phase_ != LPhase::ROLL_WAIT) return false;
    startRoll(ev);
    return true;
}

void Ludo::startRoll(std::vector<LEvent> &ev) {
    value_ = int(rnd() >> 8) % 6 + 1;
    phase_ = LPhase::ROLLING; t_ = 0; bounces_ = 0;
    LEvent e; e.type = LE_ROLL_START; e.player = turn_; e.value = value_; e.aux = int(rnd() >> 4) & 0xFFFFFF;   // aux = seed for the dice animation
    ev.push_back(e);
}

void Ludo::finishRoll(std::vector<LEvent> &ev) {
    sixes_ = value_ == 6 ? sixes_ + 1 : 0;
    { LEvent e; e.type = LE_ROLL_DONE; e.player = turn_; e.value = value_; ev.push_back(e); }
    if (value_ == 6 && s_.rules.threeSixes && sixes_ >= 3) {
        LEvent e; e.type = LE_THREE_SIXES; e.player = turn_; ev.push_back(e);
        sixes_ = 0; bonus_ = false; phase_ = LPhase::SETTLE; t_ = 0; settleDur_ = 1.1f;
        return;
    }
    mask_ = 0;
    int distinct = 0, firstTok = -1;
    for (int t = 0; t < s_.rules.tokens; t++) {
        if (!ldLegal(s_, turn_, t, value_)) continue;
        mask_ |= 1u << t;
        bool dup = false;
        for (int u = 0; u < t; u++) if ((mask_ >> u & 1u) && s_.pos[turn_][u] == s_.pos[turn_][t]) dup = true;
        if (!dup) distinct++;
        if (firstTok < 0) firstTok = t;
    }
    if (!mask_) {
        LEvent e; e.type = LE_NO_MOVE; e.player = turn_; e.value = value_; ev.push_back(e);
        bonus_ = value_ == 6;
        phase_ = LPhase::SETTLE; t_ = 0; settleDur_ = 1.0f;
        return;
    }
    phase_ = LPhase::CHOOSE; t_ = 0;
    autoPick_ = distinct == 1 && ((autoSingle_ && !s_.rules.hardMode) || !human_[turn_]);
    chooseDelay_ = autoPick_ ? 0.5f : (human_[turn_] ? 1e9f : 0.75f);
}

bool Ludo::choose(int tok, std::vector<LEvent> &ev) {
    if (phase_ != LPhase::CHOOSE || !human_[turn_] || !(mask_ >> tok & 1u)) return false;
    beginMove(tok, ev);
    return true;
}

void Ludo::beginMove(int tok, std::vector<LEvent> &ev) {
    (void) ev;
    mvTok_ = tok; mvFrom_ = s_.pos[turn_][tok];
    mvTo_ = mvFrom_ < 0 ? 0 : mvFrom_ + value_;
    phase_ = LPhase::MOVING; t_ = 0; hops_ = 0;
    moveDur_ = mvFrom_ < 0 ? ENTER_T : (mvTo_ - mvFrom_) * STEP_T;
}

void Ludo::endMove(std::vector<LEvent> &ev) {
    int p = turn_;
    LMoveResult r = ldApply(s_, p, mvTok_, value_);
    bool gotBonus = value_ == 6;
    if (r.enter) { LEvent e; e.type = LE_ENTER; e.player = p; e.tok = mvTok_; ev.push_back(e); }
    for (int i = 0; i < r.nCap; i++) {
        LEvent e; e.type = LE_CAPTURE; e.player = r.capP[i]; e.tok = r.capT[i]; e.value = p; e.aux = r.capIdx; e.value = p;
        ev.push_back(e);
        caps_[p]++;
    }
    if (r.unlock) { LEvent e; e.type = LE_UNLOCK; e.player = p; e.tok = mvTok_; e.aux = 0; ev.push_back(e); }
    for (int q = 0; q < 4; q++) if (r.relockMask >> q & 1) { LEvent e; e.type = LE_RELOCK; e.player = q; ev.push_back(e); }
    if (r.nCap && s_.rules.captureBonus) gotBonus = true;
    if (r.home) { LEvent e; e.type = LE_HOME; e.player = p; e.tok = mvTok_; ev.push_back(e); gotBonus = true; }
    bonus_ = gotBonus;
    settleDur_ = r.nCap ? 0.95f : 0.4f;
    phase_ = LPhase::SETTLE; t_ = 0;
    if (s_.done[p]) {
        place_[p] = ++placed_;
        LEvent e; e.type = LE_PLAYER_DONE; e.player = p; e.value = place_[p]; ev.push_back(e);
        bonus_ = false;
        int left = 0;
        for (int q = 0; q < 4; q++) if (s_.active[q] && !s_.done[q]) left++;
        if (!s_.rules.fullRanks || left <= 1) { finishGame(ev); return; }
        settleDur_ = 1.2f;
    }
}

void Ludo::finishGame(std::vector<LEvent> &ev) {
    // everybody who has not finished is ranked by the steps they still need
    std::vector<int> rest;
    for (int q = 0; q < 4; q++) if (s_.active[q] && !place_[q]) rest.push_back(q);
    std::sort(rest.begin(), rest.end(), [&](int a, int b) { return ldPips(s_, a) < ldPips(s_, b); });
    for (int q : rest) rank_[q] = ++placed_;
    for (int q = 0; q < 4; q++) if (place_[q]) rank_[q] = place_[q];
    for (int q = 0; q < 4; q++) if (s_.active[q] && rank_[q] == 1) winner_ = q;
    phase_ = LPhase::OVER;
    LEvent e; e.type = LE_OVER; e.player = winner_; ev.push_back(e);
}

// true when no token of any player could move with any roll (possible with padlocks: every token waits in front of its home)
bool Ludo::stalled() const {
    for (int p = 0; p < 4; p++) {
        if (!s_.active[p] || s_.done[p]) continue;
        for (int t = 0; t < s_.rules.tokens; t++) for (int r = 1; r <= 6; r++) if (ldLegal(s_, p, t, r)) return false;
    }
    return true;
}

void Ludo::nextTurn(std::vector<LEvent> &ev) {
    int prev = turn_;
    if (!(bonus_ && !s_.done[prev])) { turn_ = nextActive(prev); sixes_ = 0; }
    bool extra = turn_ == prev;
    if (turn_ < 0) { turn_ = prev; finishGame(ev); return; }
    bonus_ = false;
    if (s_.rules.captureLock && stalled()) {       // nobody can ever move again: every padlock opens
        for (int q = 0; q < 4; q++) if (s_.active[q] && !s_.done[q] && !s_.unlocked[q]) {
            s_.unlocked[q] = true;
            LEvent u; u.type = LE_UNLOCK; u.player = q; u.aux = 1; ev.push_back(u);
        }
    }
    phase_ = LPhase::ROLL_WAIT; t_ = 0;
    aiDelay_ = extra ? 0.55f : 0.8f;
    LEvent e; e.type = LE_TURN; e.player = turn_; e.aux = extra ? 1 : 0; ev.push_back(e);
}

void Ludo::update(float dt, std::vector<LEvent> &ev) {
    switch (phase_) {
        case LPhase::ROLL_WAIT:
            if (!human_[turn_]) { t_ += dt; if (t_ >= aiDelay_) startRoll(ev); }
            break;
        case LPhase::ROLLING: {
            t_ += dt;
            float tn = t_ / ROLL_T;
            static const float kB[3] = {0.209f, 0.497f, 0.825f};
            while (bounces_ < 3 && tn >= kB[bounces_]) {
                LEvent e; e.type = LE_ROLL_BOUNCE; e.player = turn_; e.value = bounces_; e.aux = int((1.f - kB[bounces_]) * 100.f);
                ev.push_back(e); bounces_++;
            }
            if (t_ >= ROLL_T) finishRoll(ev);
            break;
        }
        case LPhase::CHOOSE:
            t_ += dt;
            if (t_ >= chooseDelay_) {
                int tok = -1;
                if (autoPick_ || human_[turn_]) { for (int t = 0; t < s_.rules.tokens; t++) if (mask_ >> t & 1u) { tok = t; break; } }
                else tok = ldChooseMove(s_, turn_, value_, skill_, rng_);
                if (tok >= 0) beginMove(tok, ev);
            }
            break;
        case LPhase::MOVING: {
            t_ += dt;
            if (mvFrom_ >= 0) {
                int steps = std::min(int(t_ / STEP_T), mvTo_ - mvFrom_);
                while (hops_ < steps) {
                    hops_++;
                    LEvent e; e.type = LE_HOP; e.player = turn_; e.tok = mvTok_; e.value = mvFrom_ + hops_; ev.push_back(e);
                }
            }
            if (t_ >= moveDur_) endMove(ev);
            break;
        }
        case LPhase::SETTLE:
            t_ += dt;
            if (t_ >= settleDur_) nextTurn(ev);
            break;
        case LPhase::OVER: break;
    }
}

// ------------------------------------------------------------------------------------ save / resume
namespace {
struct Snap {
    uint32_t magic;
    LState s;
    bool human[4];
    int nPlayers, skill, turn, sixes, uiMode, place[4], caps[4], placed;
    uint32_t rng;
    bool bonus;
};
const uint32_t kSnapMagic = 0x4C534E31;
}

std::string Ludo::snapshot(int uiMode) const {
    Snap n{};
    n.magic = kSnapMagic; n.s = s_; n.nPlayers = nPlayers_; n.skill = skill_; n.turn = turn_; n.sixes = sixes_; n.uiMode = uiMode;
    n.placed = placed_; n.rng = rng_; n.bonus = false;
    for (int p = 0; p < 4; p++) { n.human[p] = human_[p]; n.place[p] = place_[p]; n.caps[p] = caps_[p]; }
    return std::string(reinterpret_cast<const char *>(&n), sizeof n);
}

bool Ludo::restore(const std::string &data, int &uiMode) {
    if (data.size() != sizeof(Snap)) return false;
    Snap n;
    memcpy(&n, data.data(), sizeof n);
    if (n.magic != kSnapMagic || n.turn < 0 || n.turn > 3 || n.nPlayers < 2 || n.nPlayers > 4 || n.s.rules.tokens < 1 || n.s.rules.tokens > 4) return false;
    for (int p = 0; p < 4; p++) for (int t = 0; t < 4; t++) if (n.s.pos[p][t] < -1 || n.s.pos[p][t] > LD_HOME) return false;
    s_ = n.s; nPlayers_ = n.nPlayers; skill_ = n.skill; turn_ = n.turn; sixes_ = n.sixes; placed_ = n.placed; rng_ = n.rng ? n.rng : 1u;
    for (int p = 0; p < 4; p++) { human_[p] = n.human[p]; place_[p] = n.place[p]; caps_[p] = n.caps[p]; rank_[p] = 0; }
    uiMode = n.uiMode; winner_ = -1; bonus_ = false; mask_ = 0; value_ = 1;
    phase_ = LPhase::ROLL_WAIT; t_ = 0; aiDelay_ = 0.8f;
    return true;
}
