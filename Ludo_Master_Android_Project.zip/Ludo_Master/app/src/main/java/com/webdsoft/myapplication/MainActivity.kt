package com.webdsoft.myapplication

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.View
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import android.view.HapticFeedbackConstants
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import com.google.androidgamesdk.GameActivity

class MainActivity : GameActivity() {
    companion object {
        init {
            System.loadLibrary("myapplication")
        }
    }

    /** Hands the rasterised font atlas (ASCII 32..127) to the native renderer. */
    private external fun nativeSetFontAtlas(bitmap: Bitmap, advances: FloatArray, cell: Int, cols: Int)
    private external fun nativeNames(packed: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30)
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        // must be ready before the native thread starts drawing text
        buildFontAtlas()
        super.onCreate(savedInstanceState)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            hideSystemUi()
        }
    }

    private fun hideSystemUi() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.apply {
                hide(WindowInsets.Type.systemBars())
                systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }
    }

    /** Called from native code (Platform.cpp). kind 0 = light tick, 1 = strong thump. */
    @Suppress("unused")
    fun performHaptic(kind: Int) {
        val constant = if (kind == 0) HapticFeedbackConstants.VIRTUAL_KEY else HapticFeedbackConstants.LONG_PRESS
        runOnUiThread { window.decorView.performHapticFeedback(constant) }
    }

    private fun buildFontAtlas() {
        val cell = 80
        val cols = 16
        val rows = 6
        val bmp = Bitmap.createBitmap(cell * cols, cell * rows, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 56f
            typeface = if (Build.VERSION.SDK_INT >= 28) Typeface.create(Typeface.DEFAULT, 700, false) else Typeface.DEFAULT_BOLD
        }
        val adv = FloatArray(96)
        for (i in 0 until 96) {
            val s = (32 + i).toChar().toString()
            val a = paint.measureText(s)
            adv[i] = a
            val x = (i % cols) * cell + (cell - a) / 2f
            val y = (i / cols) * cell + 58f
            canvas.drawText(s, x, y, paint)
        }
        nativeSetFontAtlas(bmp, adv, cell, cols)
        bmp.recycle()
    }

    // ------------------------------------------------------------------ friend names (4 player mode)

    @Suppress("unused")
    fun openNamesForm(packed: String) {
        runOnUiThread {
            val pad = (20 * resources.displayMetrics.density).toInt()
            val old = packed.split("|")
            val titles = listOf("Red (bottom left)", "Green (top left)", "Yellow (top right)", "Blue (bottom right)")
            val fields = titles.mapIndexed { i, t ->
                EditText(this).apply {
                    hint = t
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                    filters = arrayOf(android.text.InputFilter.LengthFilter(12))
                    setText(old.getOrElse(i) { "" })
                    setSingleLine()
                }
            }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(pad, pad, pad, 0)
                addView(TextView(context).apply { text = "Names shown in FRIENDS mode (leave empty for colour names)"; setPadding(0, 0, 0, pad / 2) })
                fields.forEach { addView(it) }
            }
            AlertDialog.Builder(this)
                .setTitle("Friend names")
                .setView(box)
                .setPositiveButton("SAVE") { _, _ -> nativeNames(fields.joinToString("|") { it.text.toString().trim().replace("|", "") }) }
                .setNegativeButton("CANCEL", null)
                .show()
        }
    }
}
