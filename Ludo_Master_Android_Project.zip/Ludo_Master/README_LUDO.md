# LUDO MASTER (Android, C++ / OpenGL ES 3 / GameActivity)

Open this folder in Android Studio -> Sync -> Run on a device or emulator (API 30+).
Package: com.webdsoft.ludomaster (it installs next to the old Carrom app).

## Game
- 2 / 3 / 4 players, VS COMPUTER (you are Red) or FRIENDS around the phone (each player has a dice tray and card on their own side, the board never turns).
- 4 computer levels EASY / MEDIUM / HARD / MASTER (Master weighs capture risk, safe squares, blocks and threats; tuned by self-play).
- Realistic 3D dice: perspective cube, shading, ellipse pips, tumbling, 3 bounces, lands exactly on the rolled number.
  Shaded pawns hop square by square, captured pawns fly back to the yard, particles and sounds.
- Rules (toggles): six to start, bonus roll after capture / home, three sixes = turn lost, safe blocks, ALL RANKS, 4 / 2 / 1 tokens per player.
  Stars and start squares are safe, exact roll needed to reach home.
- HARD GAME (one switch on the setup screen, every part can also be switched on its own):
  - HOME LOCK: a player must capture an opponent token before a token may pass the last cell of the loop and enter the home column.
    A padlock is drawn in front of the home column (and on the player's card) until the first capture. If all tokens of a player are
    captured the padlock comes back. If nobody can move any more (all tokens wait in front of their homes) every padlock opens.
  - NO HELP: no best-move star, no glowing / lifted tokens, no auto move. Every token can be tapped, a wrong tap does nothing, so
    the player has to think.
  - HARD GAME also switches on six to start, bonus roll and three sixes = turn lost.
  - TOKENS tile (4 -> 2 -> 1) is separate from HARD GAME.
- 3 board styles: Classic wood, Midnight, Marble. Dark / light app theme.
- Best-move hint (gold star), auto-move when there is only one choice (both can be switched off in Settings).
- CONTINUE GAME: the running game is saved at every turn and restored after the app is closed.
- XP and ranks (ROOKIE ... LEGEND), stats (wins, win rate, captures, best streak, wins per level), friend names.
- Fully offline: no internet permission, no ads, no wallet.

## Files (app/src/main/cpp)
- Ludo.h / Ludo.cpp   rules (incl. home lock), turn flow, computer players, save/restore (portable, tested on a PC: ../ludo_tests)
- App.h / App.cpp     menu, setup, game screen, dice + pawn drawing, settings, stats
- LudoUi.h            save data and run-time state
- Gfx.*, Audio.*, Renderer.*, Platform.*, Jni.cpp, main.cpp   OpenGL ES renderer, synthesised sounds, Android glue
