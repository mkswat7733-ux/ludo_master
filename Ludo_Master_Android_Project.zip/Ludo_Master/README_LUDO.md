# LUDO MASTER (Android, C++ / OpenGL ES 3 / GameActivity)

Open this folder in Android Studio -> Sync -> Run on a device or emulator (API 30+).
Package: com.webdsoft.ludomaster (it installs next to the old Carrom app).

## Game
- 2 / 3 / 4 players, VS COMPUTER (you are Red) or FRIENDS around the phone (each player has a dice tray and card on their own side, the board never turns).
- 4 computer levels EASY / MEDIUM / HARD / MASTER (Master weighs capture risk, safe squares, blocks and threats; tuned by self-play).
- Realistic 3D dice: perspective cube, shading, ellipse pips, tumbling, 3 bounces, lands exactly on the rolled number.
  Shaded pawns hop square by square, captured pawns fly back to the yard, particles and sounds.
- Rules (toggles): SIX = REROLL (default), six to start, bonus roll after capture / home, three sixes, safe blocks, ALL RANKS, 4 / 2 / 1 tokens per player, TWO DICE.
- SIX = REROLL: a 6 moves nothing and brings no token out, the same player simply rolls again (a second 6 too). The third 6 in a row: nothing
  happens and the next player rolls. Tokens leave the yard on any other number. (SIX TO START is the old rule and excludes SIX = REROLL.)
- KILL TRAP: after a capture you roll again. If that very next move is made with the token that has just captured, the capture is undone:
  the captured token stands again on the cell where it was captured, the moving token goes back to its yard (and a home lock opened by
  that capture closes again). Moving any other token makes the capture permanent. No warning is shown before the move. The computer avoids it.
- TWO DICE: two dice every turn, each number is played on its own token move, first die first. A token comes out of the yard only when one of
  the dice shows a 6 (that 6 is played and gives another roll), so TWO DICE switches SIX TO START on and SIX = REROLL off.
  A captured token goes back to its yard and needs a 6 again.
- HARD GAME (one switch on the setup screen, every part can also be switched on its own):
  - HOME LOCK: a player must capture an opponent token before a token may pass the last cell of the loop and enter the home column.
    A padlock is drawn in front of the home column (and on the player's card) until the first capture. If all tokens of a player are
    captured the padlock comes back. If nobody can move any more (all tokens wait in front of their homes) every padlock opens.
  - NO HELP: no best-move star, no glowing / lifted tokens, no auto move. Every token can be tapped, a wrong tap does nothing, so
    the player has to think.
  - HARD GAME also switches on KILL TRAP, SIX = REROLL, bonus roll and three sixes = turn lost.
  - TOKENS tile (4 -> 2 -> 1) and TWO DICE are separate from HARD GAME.
- 3 board styles: Classic wood, Midnight, Marble. Dark / light app theme.
- Best-move hint (gold star), auto-move when there is only one choice (both can be switched off in Settings).
- CONTINUE GAME: the running game is saved at every turn and restored after the app is closed.
- XP and ranks (ROOKIE ... LEGEND), stats (wins, win rate, captures, best streak, wins per level), friend names.
- Fully offline: no internet permission, no ads, no wallet.

## Files (app/src/main/cpp)
- Ludo.h / Ludo.cpp   rules (incl. home lock), turn flow, computer players, save/restore (portable, tested on a PC: ../ludo_tests)
- App.h / App.cpp     menu, setup, game screen, dice + pawn drawing, settings, stats
- LudoUi.h            save data and run-time state
- Gfx.*, Audio.*, Renderer.*, Platform.*, Jni.cpp, main.cpp   OpenGL ES renderer, synthesised sounds, Android glue
