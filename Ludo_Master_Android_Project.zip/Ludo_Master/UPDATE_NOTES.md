# Ludo Master - latest update (TWO DICE needs a 6, KILL TRAP, SIX = REROLL, HARD GAME)

- TWO DICE: tokens come out only when at least one die shows a 6. In this mode SIX TO START is always on and SIX = REROLL is off.

- KILL TRAP switch (also part of HARD GAME): after a capture, if the next move is made with the same token that captured, the capture is undone -
  the captured token returns to the cell where it was captured and the moving token goes back to its yard. Only that one next move counts.

- SIX = REROLL (on by default): a 6 never moves or releases a token, it only gives the same player another roll. Third 6 in a row: nothing happens,
  next player. Tokens come out on any other number. HARD GAME uses this rule.
- TWO DICE switch: two dice per turn, the two numbers are played one after the other (first die first). Dice are drawn side by side.

- New app icon: four coloured yards with a white six-dice (adaptive icon, with a themed monochrome version).
- HARD GAME switch (setup screen): HOME LOCK + no hints / highlights + six to start + bonus roll + three sixes.
- HOME LOCK switch: capture an opponent first, otherwise a padlock blocks your home. Padlock comes back when all your tokens are captured.
- TOKENS tile now cycles 4 -> 2 -> 1 and is independent of HARD GAME.
- Computer players know about the padlock and go for captures.
- Old save files still load. A game that was in progress before this update cannot be continued (its format changed).

# Earlier update

- Dice: 3D rounded red / white dice, tumbles out of the tray onto the board, lands straight facing the screen, then flies back.
- Board: new WOODEN traditional board with rosette flowers (default). Board and dice design are chosen in Settings.
- Rules: 6 needed to bring a token out; three 6s = nothing moves, turn passes; while a token is still in the yard a 6 must free it first.
- Settings are stored with a new save version, so old stats reset once.

## Build the APK
- Android Studio: open this folder, then Build > Build Bundle(s) / APK(s) > Build APK(s).
- Or push the folder to GitHub: Actions > "Build APK" > Run workflow; download the APK from "Artifacts".
