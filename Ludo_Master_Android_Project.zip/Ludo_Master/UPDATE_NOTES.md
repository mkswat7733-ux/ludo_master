# Ludo Master - latest update

- Dice: 3D rounded red / white dice, tumbles out of the tray onto the board, lands straight facing the screen, then flies back.
- Board: new WOODEN traditional board with rosette flowers (default). Board and dice design are chosen in Settings.
- Rules: 6 needed to bring a token out; three 6s = nothing moves, turn passes; while a token is still in the yard a 6 must free it first.
- Settings are stored with a new save version, so old stats reset once.

## Build the APK
- Android Studio: open this folder, then Build > Build Bundle(s) / APK(s) > Build APK(s).
- Or push the folder to GitHub: Actions > "Build APK" > Run workflow; download the APK from "Artifacts".
