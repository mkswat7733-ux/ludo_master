# Ludo Master - latest update (HARD GAME)

- New app icon: four coloured yards with a white six-dice (adaptive icon, with a themed monochrome version).
- HARD GAME switch (setup screen): HOME LOCK + no hints / highlights + six to start + bonus roll + three sixes.
- HOME LOCK switch: capture an opponent first, otherwise a padlock blocks your home. Padlock comes back when all your tokens are captured.
- TOKENS tile now cycles 4 -> 2 -> 1 and is independent of HARD GAME.
- Computer players know about the padlock and go for captures.
- Old save files still load. A game that was in progress before this update cannot be continued (its format changed).

# Earlier update

- Dice: 3D rounded red / white dice, tumbles out of the tray onto the board, lands straight facing the screen, then flies back.
- Board: new WOODEN traditional board with rosette flowers (default). Board and dice design are chosen in Settings.
- Rules: 6 needed to bring a token out; three 6s = nothing moves, turn passes; while a token is still in the yard a 6 must free it first.
- Settings are stored with a new save version, so old stats reset once.

## Build the APK
- Android Studio: open this folder, then Build > Build Bundle(s) / APK(s) > Build APK(s).
- Or push the folder to GitHub: Actions > "Build APK" > Run workflow; download the APK from "Artifacts".
